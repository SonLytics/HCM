# HCM Data Location Configuration

## Current Setting: Current Working Directory

HCM is now configured to store case data in the **current working directory** where you run the application.

### What This Means:

✅ **New cases** will be created in the folder where you run `hcmrun` or `python app.py`  
✅ **Previous data** in other locations is **NOT deleted** - it remains accessible  
✅ **Portable usage** - you can run HCM from any folder and it will use that location  
✅ **Easy organization** - each investigation can have its own folder  

### How It Works:

1. **Run HCM from any folder:**
   ```bash
   # Navigate to your investigation folder
   cd C:\Investigations\Case_2024_001
   
   # Run HCM from here
   hcmrun
   # or
   python app.py
   ```

2. **Case data will be stored in that folder:**
   ```
   C:\Investigations\Case_2024_001\
   ├── TEST-CASE-001\          # Case folder
   │   ├── huntcards.json
   │   ├── evidence\
   │   └── ...
   ├── ANOTHER-CASE\           # Another case
   └── ...
   ```

### Previous Data Locations:

If you had HCM configured with a different data directory, your previous cases are still there:

- **Default location:** `./data/` (relative to HCM installation)
- **Custom location:** Check your previous `config.py` settings
- **Environment variable:** Check `HCM_DATA_DIR` environment variable

### To Access Previous Data:

1. **Temporarily change config.py:**
   ```python
   # In config.py, change:
   DATA_DIR = "C:\\Your\\Previous\\Data\\Path"
   ```

2. **Use environment variable:**
   ```bash
   # Set environment variable
   set HCM_DATA_DIR=C:\Your\Previous\Data\Path
   hcmrun
   ```

3. **Copy data to new location:**
   - Copy your previous case folders to the new working directory
   - HCM will automatically detect and use them

### Configuration Options:

In `config.py`, you can choose:

```python
# Option 1: Current working directory (current setting)
DATA_DIR = "."

# Option 2: Environment variable
DATA_DIR = None  # Uses HCM_DATA_DIR environment variable

# Option 3: Fixed path
DATA_DIR = "C:\\HCM_Data"  # Windows
DATA_DIR = "/home/user/HCM_Data"  # Linux/Mac
DATA_DIR = "data"  # Relative to app directory
```

### Benefits of Current Working Directory:

- 🎯 **Project-based organization** - each investigation in its own folder
- 📁 **Easy backup** - entire investigation folder can be backed up
- 🔄 **Portable** - move investigation folders between systems
- 👥 **Team collaboration** - share investigation folders easily
- 🚀 **No configuration needed** - just run from the right folder

### Migration Guide:

If you want to move your existing cases to the new system:

1. **Identify your current data location:**
   ```bash
   python config.py
   ```

2. **Copy cases to new location:**
   ```bash
   # Example: copy from old location to new working directory
   xcopy "C:\Old\HCM\Data\*" "C:\New\Investigation\Folder\" /E /I
   ```

3. **Run HCM from the new location:**
   ```bash
   cd C:\New\Investigation\Folder
   hcmrun
   ```

Your cases will be immediately available in the new location! 