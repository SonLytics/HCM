"""
Command-line interface for Hunt Card Manager
"""

import os
import sys
import click
from pathlib import Path
from .app import create_app
from .config import config


@click.group()
@click.version_option(version="1.0.0", prog_name="Hunt Card Manager")
def cli():
    """Hunt Card Manager - Professional DFIR Tool for Managing Hunt Cards"""
    pass


@cli.command()
@click.option('--host', default='127.0.0.1', help='Host to bind to')
@click.option('--port', default=7997, help='Port to bind to')
@click.option('--debug', is_flag=True, help='Enable debug mode')
@click.option('--data-dir', help='Custom data directory path')
@click.option('--config', default='development', 
              type=click.Choice(['development', 'production', 'testing']),
              help='Configuration to use')
def run(host, port, debug, data_dir, config):
    """Run the Hunt Card Manager web application"""
    
    # Set data directory if provided
    if data_dir:
        os.environ['HCM_DATA_DIR'] = data_dir
    
    # Create and configure the app
    app = create_app(config)
    
    # Override debug setting if specified
    if debug:
        app.config['DEBUG'] = True
    
    click.echo(f"Starting Hunt Card Manager on http://{host}:{port}")
    click.echo(f"Data directory: {app.config['DATA_DIR']}")
    click.echo("Press Ctrl+C to stop the server")
    
    app.run(host=host, port=port, debug=app.config['DEBUG'])


@cli.command()
@click.option('--data-dir', help='Custom data directory path')
def init(data_dir):
    """Initialize the Hunt Card Manager data directory"""
    
    if data_dir:
        os.environ['HCM_DATA_DIR'] = data_dir
    
    # Create app to trigger initialization
    app = create_app('development')
    
    data_path = Path(app.config['DATA_DIR'])
    click.echo(f"Initialized data directory: {data_path}")
    click.echo(f"Created subdirectories:")
    click.echo(f"  - {data_path / 'cases'}")
    click.echo(f"  - {data_path / 'exports'}")
    click.echo(f"  - {data_path / 'logs'}")


@cli.command()
@click.option('--data-dir', help='Data directory to backup')
@click.option('--output', help='Output backup file path')
def backup(data_dir, output):
    """Create a backup of the Hunt Card Manager data"""
    
    if data_dir:
        os.environ['HCM_DATA_DIR'] = data_dir
    
    app = create_app('development')
    data_path = Path(app.config['DATA_DIR'])
    
    if not output:
        output = f"hcm_backup_{data_path.name}.zip"
    
    import zipfile
    import datetime
    
    timestamp = datetime.datetime.now().strftime("%Y%m%d_%H%M%S")
    backup_file = f"hcm_backup_{timestamp}.zip"
    
    with zipfile.ZipFile(backup_file, 'w', zipfile.ZIP_DEFLATED) as zipf:
        for root, dirs, files in os.walk(data_path):
            for file in files:
                file_path = os.path.join(root, file)
                arcname = os.path.relpath(file_path, data_path.parent)
                zipf.write(file_path, arcname)
    
    click.echo(f"Backup created: {backup_file}")


@cli.command()
def info():
    """Show information about the current installation"""
    
    app = create_app('development')
    
    click.echo("Hunt Card Manager Information:")
    click.echo(f"Version: 1.0.0")
    click.echo(f"Data Directory: {app.config['DATA_DIR']}")
    click.echo(f"Configuration: Development")
    
    data_path = Path(app.config['DATA_DIR'])
    if data_path.exists():
        click.echo(f"Data Directory Status: Exists")
        cases_count = len(list((data_path / "cases").glob("*")))
        click.echo(f"Number of Cases: {cases_count}")
    else:
        click.echo(f"Data Directory Status: Not found")


def main():
    """Main entry point for the CLI"""
    cli()


if __name__ == '__main__':
    main() 