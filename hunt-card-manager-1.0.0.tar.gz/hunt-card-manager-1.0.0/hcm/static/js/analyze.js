function suggest(type, idx) {
    const inputSelector = type === 'what' ? `input[name="what_${idx}"]` : `textarea[name="query_${idx}"]`;
    const input = document.querySelector(inputSelector);
    const keywords = encodeURIComponent(input.value.trim());

    if (!keywords || keywords.length < 2) {
        alert("Type at least 2 characters to get suggestions.");
        return;
    }

    fetch(`/case/${caseId}/suggest/${type}?keywords=${keywords}`)
        .then(resp => {
            if (!resp.ok) throw new Error("Server error");
            return resp.json();
        })
        .then(data => showSuggestionPanel(input, data))
        .catch(err => {
            console.error("Suggestion error:", err);
            alert("Failed to get suggestions.");
        });
}

function showSuggestionPanel(anchorInput, suggestions) {
    let panel = document.getElementById('suggestion-floating-panel');
    if (panel) panel.remove();

    panel = document.createElement('div');
    panel.id = 'suggestion-floating-panel';
    panel.style = `
        position: absolute;
        background: white;
        border: 1px solid #ccc;
        border-radius: 4px;
        padding: 8px;
        max-width: 400px;
        z-index: 9999;
        box-shadow: 0 2px 8px rgba(0,0,0,0.2);
    `;

    const rect = anchorInput.getBoundingClientRect();
    panel.style.top = `${window.scrollY + rect.bottom + 4}px`;
    panel.style.left = `${window.scrollX + rect.left}px`;

    if (suggestions.length === 0) {
        panel.innerHTML = "<em>No suggestions found.</em>";
    } else {
        const list = document.createElement('ul');
        list.style = "list-style: none; margin: 0; padding: 0;";
        suggestions.forEach(s => {
            const li = document.createElement('li');
            li.style = "padding:4px; margin-bottom:4px; background:#f0f0f0; border-radius:4px; cursor:pointer;";
            li.textContent = s;
            li.onclick = () => {
                anchorInput.value = s;
                panel.remove();
            };
            list.appendChild(li);
        });
        panel.appendChild(list);
    }

    document.body.appendChild(panel);

    document.addEventListener('click', function dismiss(e) {
        if (!panel.contains(e.target) && e.target !== anchorInput) {
            panel.remove();
            document.removeEventListener('click', dismiss);
        }
    });
}

// Analyze Page JavaScript
const themeToggle = document.getElementById('theme-toggle');
const toggleKnob = document.getElementById('toggle-knob');

function setTheme(theme) {
  document.body.setAttribute('data-theme', theme);
  localStorage.setItem('theme', theme);
  if (theme === 'black-dark') {
    themeToggle.checked = true;
    toggleKnob.style.left = '2px';
  } else {
    themeToggle.checked = false;
    toggleKnob.style.left = '18px';
  }
}

// Theme toggle event listener
if (themeToggle) {
  themeToggle.addEventListener('change', function() {
    setTheme(this.checked ? 'black-dark' : 'white-light');
  });
}

// Initialize theme on page load
document.addEventListener('DOMContentLoaded', function() {
  const savedTheme = localStorage.getItem('theme') || 'white-light';
  setTheme(savedTheme);
});

function toggleDropdown(dropdownId) {
  const dropdown = document.getElementById(dropdownId);
  const allDropdowns = document.querySelectorAll('.dropdown-options');
  
  // Close all other dropdowns
  allDropdowns.forEach(d => {
    if (d.id !== dropdownId) {
      d.classList.remove('show');
    }
  });
  
  // Toggle current dropdown
  dropdown.classList.toggle('show');
}

// Close dropdowns when clicking outside
document.addEventListener('click', function(event) {
  const dropdowns = document.querySelectorAll('.dropdown-options');
  const dropdownButtons = document.querySelectorAll('.filter-dropdown-btn');
  
  let clickedInside = false;
  dropdownButtons.forEach(button => {
    if (button.contains(event.target)) {
      clickedInside = true;
    }
  });
  
  if (!clickedInside) {
    dropdowns.forEach(dropdown => {
      dropdown.classList.remove('show');
    });
  }
});
