// Collapsible Map Page JavaScript
function buildTree(flatNodes, flatLinks) {
  const nodeMap = {};
  flatNodes.forEach(n => nodeMap[n.id] = {...n, children: []});
  flatLinks.forEach(l => {
    if (nodeMap[l.source] && nodeMap[l.target]) {
      nodeMap[l.source].children.push(nodeMap[l.target]);
    }
  });
  return Object.values(nodeMap).find(n => n.type === 'case');
}

function getTextWidth(text, font) {
  const canvas = getTextWidth.canvas || (getTextWidth.canvas = document.createElement("canvas"));
  const context = canvas.getContext("2d");
  context.font = font;
  const metrics = context.measureText(text);
  return metrics.width;
}

// Initialize on page load
document.addEventListener('DOMContentLoaded', function() {
  const data = buildTree(
    window.mindMapNodes,
    window.mindMapLinks
  );
  renderMindMap(data);
});

function renderMindMap(rootData) {
  const margin = {top: 80, right: 80, bottom: 80, left: 80};
  const width = 1800;
  const height = 1000;
  const dx = 90;
  const dy = 320;
  let treeData = d3.hierarchy(rootData);
  treeData.x0 = 0;
  treeData.y0 = 0;
  treeData.children?.forEach(collapse);
  const mindmapLayout = d3.tree().nodeSize([dx, dy]);
  const svg = d3.select('#tree-container').append('svg')
    .attr('class', 'mindmap-svg')
    .attr('viewBox', [0, 0, width, height])
    .attr('preserveAspectRatio', 'xMidYMid meet');
  
  // Define arrowhead marker
  svg.append('defs').append('marker')
    .attr('id', 'arrowhead')
    .attr('viewBox', '0 -5 10 10')
    .attr('refX', 8)
    .attr('refY', 0)
    .attr('markerWidth', 10)
    .attr('markerHeight', 10)
    .attr('orient', 'auto')
    .append('path')
    .attr('d', 'M0,-4L8,0L0,4L2,0Z')
    .attr('fill', '#222');
  
  // Define striped patterns for incomplete analysis
  const defs = svg.append('defs');
  
  // Blue stripes for case
  const bluePattern = defs.append('pattern')
    .attr('id', 'stripes-blue')
    .attr('patternUnits', 'userSpaceOnUse')
    .attr('width', '8')
    .attr('height', '8');
  bluePattern.append('rect')
    .attr('width', '8')
    .attr('height', '8')
    .attr('fill', '#4285F4');
  bluePattern.append('line')
    .attr('x1', '0')
    .attr('y1', '0')
    .attr('x2', '8')
    .attr('y2', '8')
    .attr('stroke', 'white')
    .attr('stroke-width', '2');
  
  // Red stripes for threat actor
  const redPattern = defs.append('pattern')
    .attr('id', 'stripes-red')
    .attr('patternUnits', 'userSpaceOnUse')
    .attr('width', '8')
    .attr('height', '8');
  redPattern.append('rect')
    .attr('width', '8')
    .attr('height', '8')
    .attr('fill', '#EA4335');
  redPattern.append('line')
    .attr('x1', '0')
    .attr('y1', '0')
    .attr('x2', '8')
    .attr('y2', '8')
    .attr('stroke', 'white')
    .attr('stroke-width', '2');
  
  // Yellow stripes for platform
  const yellowPattern = defs.append('pattern')
    .attr('id', 'stripes-yellow')
    .attr('patternUnits', 'userSpaceOnUse')
    .attr('width', '8')
    .attr('height', '8');
  yellowPattern.append('rect')
    .attr('width', '8')
    .attr('height', '8')
    .attr('fill', '#FBBC05');
  yellowPattern.append('line')
    .attr('x1', '0')
    .attr('y1', '0')
    .attr('x2', '8')
    .attr('y2', '8')
    .attr('stroke', 'white')
    .attr('stroke-width', '2');
  
  // Green stripes for tactic
  const greenPattern = defs.append('pattern')
    .attr('id', 'stripes-green')
    .attr('patternUnits', 'userSpaceOnUse')
    .attr('width', '8')
    .attr('height', '8');
  greenPattern.append('rect')
    .attr('width', '8')
    .attr('height', '8')
    .attr('fill', '#34A853');
  greenPattern.append('line')
    .attr('x1', '0')
    .attr('y1', '0')
    .attr('x2', '8')
    .attr('y2', '8')
    .attr('stroke', 'white')
    .attr('stroke-width', '2');
  
  // Purple stripes for technique
  const purplePattern = defs.append('pattern')
    .attr('id', 'stripes-purple')
    .attr('patternUnits', 'userSpaceOnUse')
    .attr('width', '8')
    .attr('height', '8');
  purplePattern.append('rect')
    .attr('width', '8')
    .attr('height', '8')
    .attr('fill', '#8B5CF6');
  purplePattern.append('line')
    .attr('x1', '0')
    .attr('y1', '0')
    .attr('x2', '8')
    .attr('y2', '8')
    .attr('stroke', 'white')
    .attr('stroke-width', '2');
  
  // Gray stripes for huntcard
  const grayPattern = defs.append('pattern')
    .attr('id', 'stripes-gray')
    .attr('patternUnits', 'userSpaceOnUse')
    .attr('width', '8')
    .attr('height', '8');
  grayPattern.append('rect')
    .attr('width', '8')
    .attr('height', '8')
    .attr('fill', '#5F6368');
  grayPattern.append('line')
    .attr('x1', '0')
    .attr('y1', '0')
    .attr('x2', '8')
    .attr('y2', '8')
    .attr('stroke', 'white')
    .attr('stroke-width', '2');
  
  const g = svg.append('g');

  // Function to check if two nodes overlap
  function nodesOverlap(node1, node2) {
    const node1Width = node1.nodeWidth || 140;
    const node2Width = node2.nodeWidth || 140;
    const nodeHeight = 48;
    const padding = 20; // Minimum space between nodes
    
    const x1 = node1.y - node1Width/2;
    const x2 = node1.y + node1Width/2;
    const y1 = node1.x - nodeHeight/2;
    const y2 = node1.x + nodeHeight/2;
    
    const x3 = node2.y - node2Width/2;
    const x4 = node2.y + node2Width/2;
    const y3 = node2.x - nodeHeight/2;
    const y4 = node2.x + nodeHeight/2;
    
    return !(x2 + padding < x3 || x4 + padding < x1 || y2 + padding < y3 || y4 + padding < y1);
  }

  // Function to resolve overlaps by repositioning nodes
  function resolveOverlaps(nodes) {
    let hasOverlaps = true;
    let iterations = 0;
    const maxIterations = 50;
    
    while (hasOverlaps && iterations < maxIterations) {
      hasOverlaps = false;
      iterations++;
      
      for (let i = 0; i < nodes.length; i++) {
        for (let j = i + 1; j < nodes.length; j++) {
          const node1 = nodes[i];
          const node2 = nodes[j];
          
          if (nodesOverlap(node1, node2)) {
            hasOverlaps = true;
            
            // Calculate separation distance
            const node1Width = node1.nodeWidth || 140;
            const node2Width = node2.nodeWidth || 140;
            const totalWidth = (node1Width + node2Width) / 2 + 40; // 40px padding
            
            // Determine which direction to move (prefer vertical separation)
            const dx = Math.abs(node2.y - node1.y);
            const dy = Math.abs(node2.x - node1.x);
            
            if (dx < dy) {
              // Move horizontally (adjust Y position)
              const direction = node2.y > node1.y ? 1 : -1;
              const moveDistance = totalWidth - dx;
              node2.y += direction * moveDistance * 0.5;
              node1.y -= direction * moveDistance * 0.5;
            } else {
              // Move vertically (adjust X position)
              const direction = node2.x > node1.x ? 1 : -1;
              const moveDistance = 60; // Fixed vertical separation
              node2.x += direction * moveDistance * 0.5;
              node1.x -= direction * moveDistance * 0.5;
            }
          }
        }
      }
    }
    
    return nodes;
  }

  // Function to check if all huntcards in a case are complete
  function checkAllHuntcardsComplete(caseNode) {
    const huntcards = [];
    
    // Recursively find all huntcard nodes under this case
    function findHuntcards(node) {
      if (node.data.type === 'huntcard') {
        huntcards.push(node);
      }
      if (node.children) {
        node.children.forEach(findHuntcards);
      }
      if (node._children) {
        node._children.forEach(findHuntcards);
      }
    }
    
    findHuntcards(caseNode);
    
    // Check if all huntcards have complete status
    return huntcards.length > 0 && huntcards.every(hc => hc.data.analysis_status === 'Completed');
  }

  // Function to check if any descendants are incomplete
  function hasIncompleteDescendants(node) {
    // Check if this node itself is incomplete (for huntcards)
    if (node.data.type === 'huntcard' && node.data.analysis_status !== 'Completed') {
      return true;
    }
    
    // Check children
    if (node.children) {
      for (let child of node.children) {
        if (hasIncompleteDescendants(child)) {
          return true;
        }
      }
    }
    
    // Check collapsed children
    if (node._children) {
      for (let child of node._children) {
        if (hasIncompleteDescendants(child)) {
          return true;
        }
      }
    }
    
    return false;
  }

  function update(source) {
    const nodes = mindmapLayout(treeData);
    const nodesArr = nodes.descendants();
    const linksArr = nodes.links();
    
    // Calculate node widths first
    nodesArr.forEach(d => {
      const label = d.data.label || '';
      const textWidth = getTextWidth(label, '600 19px Inter, sans-serif');
      const emojiSpace = 30;
      const padding = 40;
      d.nodeWidth = Math.max(140, textWidth + emojiSpace + padding);
    });
    
    // Resolve overlaps
    const resolvedNodes = resolveOverlaps(nodesArr);
    
    let top = resolvedNodes[0], bottom = resolvedNodes[0], left = resolvedNodes[0], right = resolvedNodes[0];
    resolvedNodes.forEach(d => {
      if (d.x < top.x) top = d;
      if (d.x > bottom.x) bottom = d;
      if (d.y < left.y) left = d;
      if (d.y > right.y) right = d;
    });
    
    // Center the group in the SVG
    const xOffset = (width - (right.y - left.y)) / 2 - left.y;
    const yOffset = (height - (bottom.x - top.x)) / 2 - top.x;
    g.transition().duration(400)
      .attr('transform', `translate(${xOffset},${yOffset})`);
    svg.attr('viewBox', [0, 0, width, height]);
    
    // Draw links
    const link = g.selectAll('.mindmap-link')
      .data(linksArr, d => d.target.data.id);
    link.enter().append('path')
      .attr('class', 'mindmap-link')
      .attr('d', d => {
        const dx = d.target.y - d.source.y;
        const dy = d.target.x - d.source.x;
        const distance = Math.sqrt(dx * dx + dy * dy);
        
        // Calculate start and end points at node edges
        const sourceWidth = d.source.nodeWidth || 140;
        const targetWidth = d.target.nodeWidth || 140;
        
        // Determine start point (from source node edge)
        const sourceStartX = d.source.y + (dx > 0 ? sourceWidth/2 : -sourceWidth/2);
        const sourceStartY = d.source.x;
        
        // Determine end point (to target node edge)
        const targetEndX = d.target.y + (dx < 0 ? targetWidth/2 : -targetWidth/2);
        const targetEndY = d.target.x;
        
        // Calculate curve control points - gentle, less bent curves that avoid button overlap
        const curveOffset = Math.max(40, distance * 0.2); // Gentler, less bent curve
        const extraCurve = distance < 200 ? 30 : 0; // Less extra curve for short connections
        const totalCurve = curveOffset + extraCurve;
        
        // Control points for outside-in curves - bulge outward then come in
        const buttonOffset = 30; // Reduced space to avoid button overlap
        const control1X = sourceStartX + (dx > 0 ? (totalCurve + buttonOffset) : -(totalCurve + buttonOffset));
        const control1Y = sourceStartY;
        const control2X = targetEndX + (dx < 0 ? -(totalCurve + buttonOffset) : (totalCurve + buttonOffset));
        const control2Y = targetEndY;
        
        return `M${sourceStartX},${sourceStartY}C${control1X},${control1Y} ${control2X},${control2Y} ${targetEndX},${targetEndY}`;
      })
      .merge(link)
      .transition().duration(400)
      .attr('d', d => {
        const dx = d.target.y - d.source.y;
        const dy = d.target.x - d.source.x;
        const distance = Math.sqrt(dx * dx + dy * dy);
        
        // Calculate start and end points at node edges
        const sourceWidth = d.source.nodeWidth || 140;
        const targetWidth = d.target.nodeWidth || 140;
        
        // Determine start point (from source node edge)
        const sourceStartX = d.source.y + (dx > 0 ? sourceWidth/2 : -sourceWidth/2);
        const sourceStartY = d.source.x;
        
        // Determine end point (to target node edge)
        const targetEndX = d.target.y + (dx < 0 ? targetWidth/2 : -targetWidth/2);
        const targetEndY = d.target.x;
        
        // Calculate curve control points - gentle, less bent curves that avoid button overlap
        const curveOffset = Math.max(40, distance * 0.2); // Gentler, less bent curve
        const extraCurve = distance < 200 ? 30 : 0; // Less extra curve for short connections
        const totalCurve = curveOffset + extraCurve;
        
        // Control points for outside-in curves - bulge outward then come in
        const buttonOffset = 30; // Reduced space to avoid button overlap
        const control1X = sourceStartX + (dx > 0 ? (totalCurve + buttonOffset) : -(totalCurve + buttonOffset));
        const control1Y = sourceStartY;
        const control2X = targetEndX + (dx < 0 ? -(totalCurve + buttonOffset) : (totalCurve + buttonOffset));
        const control2Y = targetEndY;
        
        return `M${sourceStartX},${sourceStartY}C${control1X},${control1Y} ${control2X},${control2Y} ${targetEndX},${targetEndY}`;
      });
    link.exit().remove();
    
    // Draw nodes
    const node = g.selectAll('.mindmap-node')
      .data(resolvedNodes, d => d.data.id);
    const nodeEnter = node.enter().append('g')
      .attr('class', d => {
        let classes = `mindmap-node mindmap-${d.data.type}`;
        // Check if this node or any of its descendants are incomplete
        if (hasIncompleteDescendants(d)) {
          classes += ' mindmap-incomplete';
        }
        return classes;
      })
      .attr('transform', d => `translate(${source.y0},${source.x0})`)
      .on('click', (event, d) => {
        if (d.children) {
          d._children = d.children;
          d.children = null;
        } else {
          d.children = d._children;
          d._children = null;
        }
        update(d);
      });
    
    nodeEnter.append('rect')
      .attr('class', 'mindmap-bg')
      .attr('x', d => -d.nodeWidth/2)
      .attr('y', -24)
      .attr('width', d => d.nodeWidth)
      .attr('height', 48);
    
    // Add emoji first
    nodeEnter.append('text')
      .attr('class', 'mindmap-emoji')
      .attr('x', d => -d.nodeWidth/2 + 20)
      .attr('y', 4)
      .attr('text-anchor', 'middle')
      .attr('alignment-baseline', 'middle')
      .style('font-size', '1.2rem')
      .text(d => {
        switch(d.data.type) {
          case 'case': return '📋';
          case 'threat_actor': return '👤';
          case 'platform': return '💻';
          case 'tactic': return '🎯';
          case 'technique': return '🔧';
          case 'huntcard': return '🔍';
          default: return '📄';
        }
      });
    
    // Add label text (shifted right to make room for emoji)
    nodeEnter.append('text')
      .attr('class', 'mindmap-label')
      .attr('x', d => -d.nodeWidth/2 + 50)
      .attr('y', 4)
      .attr('text-anchor', 'start')
      .text(d => d.data.label);
    
    nodeEnter.filter(d => d.children || d._children)
      .append('text')
      .attr('class', 'mindmap-toggle')
      .attr('x', d => d.nodeWidth/2 - 18)
      .attr('y', 4)
      .attr('text-anchor', 'middle')
      .attr('alignment-baseline', 'middle')
      .text(d => d._children ? '+' : (d.children ? '−' : ''));
    
    node.merge(nodeEnter)
      .transition().duration(400)
      .attr('transform', d => `translate(${d.y},${d.x})`);
    node.exit().remove();
    
    resolvedNodes.forEach(d => {
      d.x0 = d.x;
      d.y0 = d.y;
    });
  }
  
  function collapse(d) {
    if (d.children) {
      d._children = d.children;
      d._children.forEach(collapse);
      d.children = null;
    }
  }
  
  update(treeData);
} 