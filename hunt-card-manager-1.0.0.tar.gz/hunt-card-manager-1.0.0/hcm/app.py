"""
Hunt Card Manager Flask Application
"""

import os
import json
import re
from datetime import datetime
from pathlib import Path
from flask import Flask, render_template, request, redirect, url_for, flash, jsonify, send_file, make_response
from werkzeug.utils import secure_filename
from .config import config


def create_app(config_name='default'):
    """Application factory function"""
    app = Flask(__name__)
    
    # Load configuration
    app.config.from_object(config[config_name])
    config[config_name].init_app(app)
    
    # Register routes
    register_routes(app)
    
    return app


def register_routes(app):
    """Register all application routes"""
    
    def get_safe_case_path(case_id):
        """Get safe case path with validation"""
        if not validate_case_id(case_id):
            raise ValueError("Invalid case ID")
        
        data_dir = app.config['DATA_DIR']
        case_folder = os.path.join(data_dir, "cases", case_id)
        
        # Ensure the path is within the data directory
        case_path = Path(case_folder).resolve()
        data_path = Path(data_dir).resolve()
        
        if not str(case_path).startswith(str(data_path)):
            raise ValueError("Path traversal attempt detected")
        
        return case_folder
    
    def validate_case_id(case_id):
        """Validate case ID format"""
        if not case_id or not isinstance(case_id, str):
            return False
        # Allow alphanumeric, hyphens, underscores, and dots
        return bool(re.match(r'^[a-zA-Z0-9._-]+$', case_id))
    
    def validate_file_upload(file):
        """Validate uploaded file"""
        if not file or file.filename == '':
            return False, "No file selected"
        
        # Check file size (10MB limit)
        if file.content_length and file.content_length > 10 * 1024 * 1024:
            return False, "File too large (max 10MB)"
        
        # Check file extension
        allowed_extensions = {'.csv', '.json'}
        file_ext = Path(file.filename).suffix.lower()
        if file_ext not in allowed_extensions:
            return False, f"Invalid file type. Allowed: {', '.join(allowed_extensions)}"
        
        return True, "File is valid"
    
    @app.route("/", methods=["GET", "POST"])
    def home():
        """Home page with case management"""
        data_dir = app.config['DATA_DIR']
        cases_dir = os.path.join(data_dir, "cases")
        
        if not os.path.exists(cases_dir):
            os.makedirs(cases_dir)
        
        cases = []
        for case_id in os.listdir(cases_dir):
            case_path = os.path.join(cases_dir, case_id)
            if os.path.isdir(case_path):
                huntcards_file = os.path.join(case_path, "huntcards.json")
                last_updated = None
                
                if os.path.exists(huntcards_file):
                    try:
                        with open(huntcards_file, "r") as f:
                            huntcards = json.load(f)
                            if huntcards:
                                # Get the most recent update
                                updates = [card.get("updated") for card in huntcards if card.get("updated")]
                                if updates:
                                    last_updated = max(updates)
                                    last_updated = datetime.fromisoformat(last_updated.replace('Z', '+00:00'))
                    except (json.JSONDecodeError, ValueError):
                        pass
                
                cases.append({
                    "case_id": case_id,
                    "last_updated": last_updated
                })
        
        # Sort cases by last updated (newest first)
        cases.sort(key=lambda x: x["last_updated"] or datetime.min, reverse=True)
        
        if request.method == "POST":
            case_id = request.form.get("case_id", "").strip()
            
            if not case_id:
                flash("Case ID cannot be empty.", "error")
                return redirect(request.url)
            
            case_folder = get_safe_case_path(case_id)
            
            if os.path.exists(case_folder):
                flash(f"Case '{case_id}' already exists!", "error")
                return redirect(request.url)
            
            try:
                os.makedirs(case_folder)
                with open(os.path.join(case_folder, "huntcards.json"), "w") as f:
                    f.write("[]")
                flash(f"Case '{case_id}' created successfully!", "success")
                return redirect(url_for("home"))
            except Exception as e:
                flash(f"Error creating case: {e}", "error")
                return redirect(request.url)
        
        return render_template("home.html", cases=cases)
    
    @app.route("/case/<case_id>")
    def case_view(case_id):
        """View hunt cards for a specific case"""
        case_folder = get_safe_case_path(case_id)
        huntcards_file = os.path.join(case_folder, "huntcards.json")
        
        huntcards = []
        if os.path.exists(huntcards_file):
            with open(huntcards_file, "r") as f:
                try:
                    huntcards = json.load(f)
                except json.JSONDecodeError:
                    flash("Corrupted huntcards.json.", "error")
        
        # Pagination
        page = request.args.get("page", 1, type=int)
        per_page = 10
        total = len(huntcards)
        total_pages = (total + per_page - 1) // per_page
        start_idx = (page - 1) * per_page
        end_idx = start_idx + per_page
        paginated_huntcards = huntcards[start_idx:end_idx]
        
        return render_template(
            "huntcard_list.html",
            case_id=case_id,
            huntcards=paginated_huntcards,
            page=page,
            total_pages=total_pages,
            per_page=per_page
        )
    
    @app.route("/case/<case_id>/analyze")
    def analyze_case(case_id):
        """Analyze hunt cards for a specific case"""
        case_folder = get_safe_case_path(case_id)
        huntcards_file = os.path.join(case_folder, "huntcards.json")

        if not os.path.exists(case_folder):
            flash(f"Case '{case_id}' does not exist.", "error")
            return redirect(url_for("home"))

        huntcards = []
        analyzed_count = 0

        if os.path.exists(huntcards_file):
            with open(huntcards_file, "r") as f:
                try:
                    huntcards = json.load(f)
                except json.JSONDecodeError:
                    flash(f"Failed to read huntcards.json for case '{case_id}'.", "error")
                    return redirect(url_for("case_view", case_id=case_id))

        # Build list with analysis status
        huntcards_with_status = []
        for idx, card in enumerate(huntcards):
            analysis_file = os.path.join(case_folder, f"analysis_{idx}.json")
            is_analyzed = os.path.exists(analysis_file)
            is_confirmed = False
            status = "Pending"

            if is_analyzed:
                analyzed_count += 1
                with open(analysis_file, "r") as f:
                    try:
                        analysis_data = json.load(f)
                        status = analysis_data.get("status", "Pending")
                        is_confirmed = (status == "Completed" or analysis_data.get("completed", False))
                    except json.JSONDecodeError:
                        pass

            # Extract filtering data
            tactic = ""
            technique = ""
            platform = card.get("platform", "")
            threat_actor = card.get("threat_actor", "")
            
            # Parse tactics_techniques
            tactics_techniques = card.get("tactics_techniques", {})
            if isinstance(tactics_techniques, dict) and tactics_techniques.get("tactic"):
                tactic = tactics_techniques["tactic"]
                if tactics_techniques.get("techniques") and tactics_techniques["techniques"]:
                    technique = tactics_techniques["techniques"][0].get("name", "")
            elif isinstance(tactics_techniques, list) and tactics_techniques:
                if isinstance(tactics_techniques[0], dict) and tactics_techniques[0].get("tactic"):
                    tactic = tactics_techniques[0]["tactic"]
                    if tactics_techniques[0].get("techniques") and tactics_techniques[0]["techniques"]:
                        technique = tactics_techniques[0]["techniques"][0].get("name", "")
            elif isinstance(tactics_techniques, str):
                tactic = tactics_techniques

            huntcards_with_status.append({
                "index": idx,
                "title": card.get("title", "Untitled"),
                "is_analyzed": is_analyzed,
                "is_confirmed": is_confirmed,
                "status": status,
                "tactic": tactic,
                "technique": technique,
                "platform": platform,
                "threat_actor": threat_actor,
                "description": card.get("description", ""),
                "updated": card.get("updated", "")
            })

        # Read filter from query string
        filter_value = request.args.get("filter", "all")
        filter_specific_value = request.args.get("value", "")

        # Apply filter to huntcards list
        filtered_huntcards = []
        filtered_analyzed_count = 0
        filtered_confirmed_count = 0
        
        for card in huntcards_with_status:
            # Apply status filter
            if filter_value == "confirmed" and not card["is_confirmed"]:
                continue
            if filter_value == "draft" and (not card["is_analyzed"] or card["is_confirmed"]):
                continue
            if filter_value == "pending" and card["is_analyzed"]:
                continue
                
            # Apply criteria filter (tactics, threat actor, platform)
            if filter_value == "tactics":
                if not card["tactic"]:
                    continue
                if filter_specific_value and card["tactic"] != filter_specific_value:
                    continue
            if filter_value == "threat_actor":
                if not card["threat_actor"]:
                    continue
                if filter_specific_value and card["threat_actor"] != filter_specific_value:
                    continue
            if filter_value == "platform":
                if not card["platform"]:
                    continue
                if filter_specific_value and card["platform"] != filter_specific_value:
                    continue
                
            filtered_huntcards.append(card)
            
            # Count analyzed and confirmed cards in filtered results
            if card["is_analyzed"]:
                filtered_analyzed_count += 1
            if card["status"] == "Completed":
                filtered_confirmed_count += 1

        # Calculate progress based on filtered results
        total_filtered = len(filtered_huntcards)
        progress_percent = (filtered_confirmed_count / total_filtered * 100) if total_filtered > 0 else 0

        # Get filter criteria name for display
        filter_criteria = "All Hunt Cards"
        if filter_value == "tactics":
            if filter_specific_value:
                filter_criteria = filter_specific_value
            else:
                tactics = [card["tactic"] for card in filtered_huntcards if card["tactic"]]
                if tactics:
                    filter_criteria = max(set(tactics), key=tactics.count)
        elif filter_value == "threat_actor":
            if filter_specific_value:
                filter_criteria = filter_specific_value
            else:
                threat_actors = [card["threat_actor"] for card in filtered_huntcards if card["threat_actor"]]
                if threat_actors:
                    filter_criteria = max(set(threat_actors), key=threat_actors.count)
        elif filter_value == "platform":
            if filter_specific_value:
                filter_criteria = filter_specific_value
            else:
                platforms = [card["platform"] for card in filtered_huntcards if card["platform"]]
                if platforms:
                    filter_criteria = max(set(platforms), key=platforms.count)

        # Get all unique values for dropdown menus
        all_tactics = list(set([card["tactic"] for card in huntcards_with_status if card["tactic"]]))
        all_threat_actors = list(set([card["threat_actor"] for card in huntcards_with_status if card["threat_actor"]]))
        all_platforms = list(set([card["platform"] for card in huntcards_with_status if card["platform"]]))

        return render_template("analyze.html",
                               case_id=case_id,
                               huntcards=filtered_huntcards,
                               analyzed_count=filtered_analyzed_count,
                               confirmed_count=filtered_confirmed_count,
                               total=total_filtered,
                               progress_percent=progress_percent,
                               active_filter=filter_value,
                               filter_criteria=filter_criteria,
                               all_tactics=all_tactics,
                               all_threat_actors=all_threat_actors,
                               all_platforms=all_platforms)
    
    @app.route("/case/<case_id>/analyze/<int:huntcard_idx>", methods=["GET", "POST"])
    def analyze_huntcard(case_id, huntcard_idx):
        """Analyze a specific hunt card"""
        case_folder = get_safe_case_path(case_id)
        huntcards_file = os.path.join(case_folder, "huntcards.json")
        analysis_file = os.path.join(case_folder, f"analysis_{huntcard_idx}.json")

        if not os.path.exists(case_folder):
            flash(f"Case '{case_id}' does not exist.", "error")
            return redirect(url_for("home"))

        if not os.path.exists(huntcards_file):
            flash("Hunt cards file not found.", "error")
            return redirect(url_for("case_view", case_id=case_id))

        with open(huntcards_file, "r") as f:
            try:
                huntcards = json.load(f)
            except json.JSONDecodeError:
                flash("Corrupted huntcards.json.", "error")
                return redirect(url_for("case_view", case_id=case_id))

        if huntcard_idx >= len(huntcards):
            flash("Hunt card not found.", "error")
            return redirect(url_for("case_view", case_id=case_id))

        huntcard = huntcards[huntcard_idx]

        # Load existing analysis if it exists
        analysis_data = {
            "status": "Pending",
            "findings": [],
            "recommendations": [],
            "completed": False,
            "completed_date": None
        }

        if os.path.exists(analysis_file):
            with open(analysis_file, "r") as f:
                try:
                    analysis_data = json.load(f)
                except json.JSONDecodeError:
                    pass

        if request.method == "POST":
            # Update analysis data
            analysis_data.update({
                "status": request.form.get("status", "Pending"),
                "findings": request.form.getlist("findings"),
                "recommendations": request.form.getlist("recommendations"),
                "completed": request.form.get("status") == "Completed",
                "completed_date": datetime.now().isoformat() if request.form.get("status") == "Completed" else None
            })

            # Save analysis
            with open(analysis_file, "w") as f:
                json.dump(analysis_data, f, indent=2)

            flash("Analysis updated successfully!", "success")
            return redirect(url_for("analyze_case", case_id=case_id))

        return render_template("analyze_huntcard.html", 
                               case_id=case_id, 
                               huntcard=huntcard, 
                               huntcard_idx=huntcard_idx,
                               analysis=analysis_data)
    
    # Add other routes here...
    # (I'll add the essential routes, but you can copy the rest from the original app.py)
    
    @app.route("/case/<case_id>/huntcard/new", methods=["GET", "POST"])
    def new_huntcard(case_id):
        """Create a new hunt card"""
        case_folder = get_safe_case_path(case_id)
        
        if request.method == "POST":
            # Process hunt card creation
            title = request.form.get("title", "").strip()
            if not title:
                flash("Title is required.", "error")
                return redirect(request.url)
            
            # Load existing hunt cards
            huntcards_file = os.path.join(case_folder, "huntcards.json")
            huntcards = []
            if os.path.exists(huntcards_file):
                with open(huntcards_file, "r") as f:
                    try:
                        huntcards = json.load(f)
                    except json.JSONDecodeError:
                        huntcards = []
            
            # Create new hunt card
            new_card = {
                "title": title,
                "description": request.form.get("description", ""),
                "platform": request.form.get("platform", "Unknown"),
                "threat_actor": request.form.get("threat_actor", "Unknown"),
                "tactics_techniques": [],  # Will be populated from form
                "investigation_points": [],
                "created": datetime.now().isoformat(),
                "updated": datetime.now().isoformat()
            }
            
            huntcards.append(new_card)
            
            # Save hunt cards
            with open(huntcards_file, "w") as f:
                json.dump(huntcards, f, indent=2)
            
            flash(f"Hunt Card '{title}' created successfully!", "success")
            return redirect(url_for("case_view", case_id=case_id))
        
        return render_template("huntcard_form.html", case_id=case_id)
    
    @app.route("/case/<case_id>/huntcard/<int:huntcard_idx>/edit", methods=["GET", "POST"])
    def edit_huntcard(case_id, huntcard_idx):
        """Edit an existing hunt card"""
        case_folder = get_safe_case_path(case_id)
        huntcards_file = os.path.join(case_folder, "huntcards.json")
        
        if not os.path.exists(huntcards_file):
            flash("Hunt cards file not found.", "error")
            return redirect(url_for("case_view", case_id=case_id))
        
        with open(huntcards_file, "r") as f:
            try:
                huntcards = json.load(f)
            except json.JSONDecodeError:
                flash("Corrupted huntcards.json.", "error")
                return redirect(url_for("case_view", case_id=case_id))
        
        if huntcard_idx >= len(huntcards):
            flash("Hunt card not found.", "error")
            return redirect(url_for("case_view", case_id=case_id))
        
        huntcard = huntcards[huntcard_idx]
        
        if request.method == "POST":
            title = request.form.get("title", "").strip()
            if not title:
                flash("Title is required.", "error")
                return redirect(request.url)
            
            # Update hunt card
            huntcard.update({
                "title": title,
                "description": request.form.get("description", ""),
                "platform": request.form.get("platform", "Unknown"),
                "threat_actor": request.form.get("threat_actor", "Unknown"),
                "updated": datetime.now().isoformat()
            })
            
            # Save hunt cards
            with open(huntcards_file, "w") as f:
                json.dump(huntcards, f, indent=2)
            
            flash(f"Hunt Card '{title}' updated successfully!", "success")
            return redirect(url_for("case_view", case_id=case_id))
        
        return render_template("huntcard_form.html", case_id=case_id, huntcard=huntcard, huntcard_idx=huntcard_idx)
    
    @app.route("/case/<case_id>/huntcard/<int:huntcard_idx>/delete")
    def delete_huntcard(case_id, huntcard_idx):
        """Delete a hunt card"""
        case_folder = get_safe_case_path(case_id)
        huntcards_file = os.path.join(case_folder, "huntcards.json")
        
        if not os.path.exists(huntcards_file):
            flash("Hunt cards file not found.", "error")
            return redirect(url_for("case_view", case_id=case_id))
        
        with open(huntcards_file, "r") as f:
            try:
                huntcards = json.load(f)
            except json.JSONDecodeError:
                flash("Corrupted huntcards.json.", "error")
                return redirect(url_for("case_view", case_id=case_id))
        
        if huntcard_idx >= len(huntcards):
            flash("Hunt card not found.", "error")
            return redirect(url_for("case_view", case_id=case_id))
        
        deleted_title = huntcards[huntcard_idx]["title"]
        del huntcards[huntcard_idx]
        
        with open(huntcards_file, "w") as f:
            json.dump(huntcards, f, indent=2)
        
        flash(f"Hunt Card '{deleted_title}' deleted successfully!", "success")
        return redirect(url_for("case_view", case_id=case_id))
    
    @app.route("/case/<case_id>/collapsible")
    def collapsible_map(case_id):
        """Display collapsible mind map for a case"""
        case_folder = get_safe_case_path(case_id)
        huntcards_file = os.path.join(case_folder, "huntcards.json")

        if not os.path.exists(case_folder):
            flash(f"Case '{case_id}' does not exist.", "error")
            return redirect(url_for("home"))

        huntcards = []
        if os.path.exists(huntcards_file):
            with open(huntcards_file, "r") as f:
                try:
                    huntcards = json.load(f)
                except json.JSONDecodeError:
                    flash("Corrupted huntcards.json.", "error")

        # Process hunt cards for mind map
        mind_map_data = []
        for idx, card in enumerate(huntcards):
            tactics_techniques = card.get("tactics_techniques", {})
            tactic = ""
            techniques = []
            
            if isinstance(tactics_techniques, dict) and tactics_techniques.get("tactic"):
                tactic = tactics_techniques["tactic"]
                if tactics_techniques.get("techniques"):
                    techniques = [tech.get("name", "") for tech in tactics_techniques["techniques"]]
            elif isinstance(tactics_techniques, list) and tactics_techniques:
                if isinstance(tactics_techniques[0], dict) and tactics_techniques[0].get("tactic"):
                    tactic = tactics_techniques[0]["tactic"]
                    if tactics_techniques[0].get("techniques"):
                        techniques = [tech.get("name", "") for tech in tactics_techniques[0]["techniques"]]
            elif isinstance(tactics_techniques, str):
                tactic = tactics_techniques

            mind_map_data.append({
                "id": idx,
                "title": card.get("title", "Untitled"),
                "tactic": tactic,
                "techniques": techniques,
                "platform": card.get("platform", ""),
                "threat_actor": card.get("threat_actor", ""),
                "description": card.get("description", "")
            })

        return render_template("collapsible_map.html", 
                               case_id=case_id, 
                               mind_map_data=mind_map_data)
    
    @app.route("/case/<case_id>/export")
    def export_huntcards(case_id):
        """Export hunt cards for a case"""
        case_folder = get_safe_case_path(case_id)
        huntcards_file = os.path.join(case_folder, "huntcards.json")
        format_type = request.args.get("format", "json")

        if not os.path.exists(case_folder):
            flash(f"Case '{case_id}' does not exist.", "error")
            return redirect(url_for("home"))

        if not os.path.exists(huntcards_file):
            flash("No hunt cards found to export.", "error")
            return redirect(url_for("case_view", case_id=case_id))

        with open(huntcards_file, "r") as f:
            try:
                huntcards = json.load(f)
            except json.JSONDecodeError:
                flash("Corrupted huntcards.json.", "error")
                return redirect(url_for("case_view", case_id=case_id))

        if format_type == "json":
            response = make_response(json.dumps(huntcards, indent=2))
            response.headers["Content-Type"] = "application/json"
            response.headers["Content-Disposition"] = f"attachment; filename={case_id}_huntcards.json"
            return response
        elif format_type == "csv":
            import csv
            from io import StringIO
            
            output = StringIO()
            writer = csv.writer(output)
            
            # Write header
            writer.writerow(["Title", "Description", "Platform", "Threat Actor", "Tactic", "Techniques", "Created", "Updated"])
            
            # Write data
            for card in huntcards:
                tactics_techniques = card.get("tactics_techniques", {})
                tactic = ""
                techniques = ""
                
                if isinstance(tactics_techniques, dict) and tactics_techniques.get("tactic"):
                    tactic = tactics_techniques["tactic"]
                    if tactics_techniques.get("techniques"):
                        techniques = ", ".join([tech.get("name", "") for tech in tactics_techniques["techniques"]])
                elif isinstance(tactics_techniques, list) and tactics_techniques:
                    if isinstance(tactics_techniques[0], dict) and tactics_techniques[0].get("tactic"):
                        tactic = tactics_techniques[0]["tactic"]
                        if tactics_techniques[0].get("techniques"):
                            techniques = ", ".join([tech.get("name", "") for tech in tactics_techniques[0]["techniques"]])
                elif isinstance(tactics_techniques, str):
                    tactic = tactics_techniques
                
                writer.writerow([
                    card.get("title", ""),
                    card.get("description", ""),
                    card.get("platform", ""),
                    card.get("threat_actor", ""),
                    tactic,
                    techniques,
                    card.get("created", ""),
                    card.get("updated", "")
                ])
            
            response = make_response(output.getvalue())
            response.headers["Content-Type"] = "text/csv"
            response.headers["Content-Disposition"] = f"attachment; filename={case_id}_huntcards.csv"
            return response
        else:
            flash("Unsupported export format.", "error")
            return redirect(url_for("case_view", case_id=case_id))
    
    @app.route('/case/<case_id>/import_huntcards', methods=['POST'])
    def import_huntcards(case_id):
        """Import hunt cards from file"""
        case_folder = get_safe_case_path(case_id)
        huntcards_file = os.path.join(case_folder, "huntcards.json")

        if not os.path.exists(case_folder):
            flash(f"Case '{case_id}' does not exist.", "error")
            return redirect(url_for("home"))

        if 'csv_file' not in request.files:
            flash("No file selected.", "error")
            return redirect(url_for("case_view", case_id=case_id))

        file = request.files['csv_file']
        if file.filename == '':
            flash("No file selected.", "error")
            return redirect(url_for("case_view", case_id=case_id))

        # Validate file
        is_valid, message = validate_file_upload(file)
        if not is_valid:
            flash(message, "error")
            return redirect(url_for("case_view", case_id=case_id))

        try:
            # Load existing hunt cards
            existing_huntcards = []
            if os.path.exists(huntcards_file):
                with open(huntcards_file, "r") as f:
                    try:
                        existing_huntcards = json.load(f)
                    except json.JSONDecodeError:
                        existing_huntcards = []

            # Parse uploaded file
            file_ext = Path(file.filename or "").suffix.lower()
            imported_huntcards = []

            if file_ext == '.json':
                content = file.read().decode('utf-8')
                imported_data = json.loads(content)
                if isinstance(imported_data, list):
                    imported_huntcards = imported_data
                else:
                    flash("Invalid JSON format. Expected a list of hunt cards.", "error")
                    return redirect(url_for("case_view", case_id=case_id))
            
            elif file_ext == '.csv':
                import csv
                from io import StringIO
                
                content = file.read().decode('utf-8')
                csv_reader = csv.DictReader(StringIO(content))
                
                for row in csv_reader:
                    huntcard = {
                        "title": row.get("Title", ""),
                        "description": row.get("Description", ""),
                        "platform": row.get("Platform", ""),
                        "threat_actor": row.get("Threat Actor", ""),
                        "tactics_techniques": {
                            "tactic": row.get("Tactic", ""),
                            "techniques": [{"name": tech.strip()} for tech in row.get("Techniques", "").split(",") if tech.strip()]
                        },
                        "created": row.get("Created", datetime.now().isoformat()),
                        "updated": row.get("Updated", datetime.now().isoformat())
                    }
                    imported_huntcards.append(huntcard)

            # Merge with existing hunt cards
            existing_huntcards.extend(imported_huntcards)

            # Save updated hunt cards
            with open(huntcards_file, "w") as f:
                json.dump(existing_huntcards, f, indent=2)

            flash(f"Successfully imported {len(imported_huntcards)} hunt cards!", "success")
            return redirect(url_for("case_view", case_id=case_id))

        except Exception as e:
            flash(f"Error importing hunt cards: {str(e)}", "error")
            return redirect(url_for("case_view", case_id=case_id))
    
    @app.route("/case/<case_id>/tree")
    def tree_view(case_id):
        """Display tree view for a case"""
        case_folder = get_safe_case_path(case_id)
        huntcards_file = os.path.join(case_folder, "huntcards.json")

        if not os.path.exists(case_folder):
            flash(f"Case '{case_id}' does not exist.", "error")
            return redirect(url_for("home"))

        huntcards = []
        if os.path.exists(huntcards_file):
            with open(huntcards_file, "r") as f:
                try:
                    huntcards = json.load(f)
                except json.JSONDecodeError:
                    flash("Corrupted huntcards.json.", "error")

        # Process hunt cards for tree view
        tree_data = []
        for idx, card in enumerate(huntcards):
            tactics_techniques = card.get("tactics_techniques", {})
            tactic = ""
            techniques = []
            
            if isinstance(tactics_techniques, dict) and tactics_techniques.get("tactic"):
                tactic = tactics_techniques["tactic"]
                if tactics_techniques.get("techniques"):
                    techniques = [tech.get("name", "") for tech in tactics_techniques["techniques"]]
            elif isinstance(tactics_techniques, list) and tactics_techniques:
                if isinstance(tactics_techniques[0], dict) and tactics_techniques[0].get("tactic"):
                    tactic = tactics_techniques[0]["tactic"]
                    if tactics_techniques[0].get("techniques"):
                        techniques = [tech.get("name", "") for tech in tactics_techniques[0]["techniques"]]
            elif isinstance(tactics_techniques, str):
                tactic = tactics_techniques

            tree_data.append({
                "id": idx,
                "title": card.get("title", "Untitled"),
                "tactic": tactic,
                "techniques": techniques,
                "platform": card.get("platform", ""),
                "threat_actor": card.get("threat_actor", ""),
                "description": card.get("description", "")
            })

        return render_template("tree_view.html", 
                               case_id=case_id, 
                               tree_data=tree_data)
    
    # Add other routes here...
    # (I'll add the essential routes, but you can copy the rest from the original app.py)
    
    # Add more routes as needed...
    # You can copy the remaining routes from the original app.py file 