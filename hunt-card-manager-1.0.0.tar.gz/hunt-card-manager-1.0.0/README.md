# Hunt Card Manager (HCM)

A professional DFIR (Digital Forensics and Incident Response) tool for managing hunt cards and investigation cases with MITRE ATT&CK framework integration.

## Features

- **Case Management**: Create and manage investigation cases
- **Hunt Card Creation**: Build detailed hunt cards with MITRE ATT&CK tactics and techniques
- **Investigation Tracking**: Track investigation progress and findings
- **Analysis Tools**: Built-in analysis capabilities for hunt cards
- **Export/Import**: Support for CSV and JSON formats
- **Professional UI**: Modern, responsive web interface
- **Theme Support**: Light and dark themes
- **Security**: Input validation and path traversal protection

## Future Features

- **Multi-User File Sharing**: Collaborative threat hunting with team file sharing capabilities

## Installation

### Option 1: Install from PyPI (Recommended)

```bash
pip install hunt-card-manager
```

### Option 2: Install from Source

```bash
git clone https://github.com/your-org/hunt-card-manager.git
cd hunt-card-manager
pip install -e .
```

## Quick Start

### 1. Initialize the Application

```bash
# Initialize with default data directory (~/HCM_Data)
hcm init

# Or specify a custom data directory
hcm init --data-dir /path/to/your/data
```

### 2. Run the Application

```bash
# Run with default settings
hcm run

# Run with custom settings
hcm run --host 0.0.0.0 --port 7997 --data-dir /path/to/data
```

### 3. Access the Web Interface

Open your browser and navigate to `http://localhost:7997`

## Configuration

### Environment Variables

- `HCM_DATA_DIR`: Custom data directory path
- `HCM_SECRET_KEY`: Secret key for Flask sessions (production only)

### Data Directory Structure

```
HCM_Data/
├── cases/           # Investigation cases
│   ├── case-001/
│   │   └── huntcards.json
│   └── case-002/
│       └── huntcards.json
├── exports/         # Export files
└── logs/           # Application logs
```

## Usage

### Command Line Interface

```bash
# Show help
hcm --help

# Show application information
hcm info

# Create backup
hcm backup --data-dir /path/to/data

# Run in production mode
hcm run --config production --host 0.0.0.0 --port 7997
```

### Web Interface

1. **Create a Case**: Enter a case ID and click "Create Case"
2. **Add Hunt Cards**: Click "New Hunt Card" to create hunt cards
3. **Configure MITRE ATT&CK**: Select tactics and techniques
4. **Add Investigation Points**: Define investigation vectors
5. **Analyze**: Use the analysis tools to track progress
6. **Export**: Export data in CSV or JSON format

## Security Considerations

- **Input Validation**: All user inputs are validated
- **Path Traversal Protection**: Prevents directory traversal attacks
- **File Upload Security**: Validates file types and sizes
- **Environment-based Configuration**: Uses environment variables for sensitive data

## Changelog

### Version 1.0.0
- Initial release
- Basic hunt card management
- MITRE ATT&CK integration
- Web-based interface
- Export/Import functionality 