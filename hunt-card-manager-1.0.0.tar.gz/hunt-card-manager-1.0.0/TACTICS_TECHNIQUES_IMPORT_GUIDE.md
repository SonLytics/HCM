# Tactics and Techniques Import Handling Guide

This document explains how MITRE ATT&CK tactics and techniques are processed during the import functionality in Hunt Card Manager.

## 🎯 Overview

The import system handles tactics and techniques through a sophisticated validation and mapping process that ensures data integrity and consistency with the MITRE ATT&CK framework.

## 📋 Data Structure

### Hunt Card Tactics/Techniques Format
```json
{
  "tactics_techniques": [
    {
      "tactic": "Defense Evasion",
      "techniques": [
        {
          "id": "T1055",
          "name": "Process Injection"
        },
        {
          "id": "T1055.001",
          "name": "Dynamic-link Library Injection"
        }
      ]
    },
    {
      "tactic": "Persistence",
      "techniques": [
        {
          "id": "T1547.001",
          "name": "Registry Run Keys / Startup Folder"
        }
      ]
    }
  ]
}
```

## 🔧 Import Processing Steps

### 1. MITRE ATT&CK Data Loading
```python
# Load MITRE ATT&CK data for validation
mitre_data = []
mitre_file = os.path.join(app.static_folder or '', 'data', 'mitre_attack.json')
if os.path.exists(mitre_file):
    with open(mitre_file, 'r') as f:
        mitre_data = json.load(f)
```

### 2. Validation Maps Creation
```python
# Create validation maps
valid_tactics = {item['tactic'] for item in mitre_data}
valid_techniques = {}
for item in mitre_data:
    for tech in item.get('techniques', []):
        valid_techniques[tech['id']] = tech['name']
```

### 3. Technique-to-Tactics Mapping
```python
# Build a mapping from technique ID to all tactics it belongs to
technique_to_tactics = {}
technique_id_to_name = {}
for item in mitre_data:
    tactic = item['tactic']
    for tech in item.get('techniques', []):
        tid = tech['id']
        technique_id_to_name[tid] = tech['name']
        if tid not in technique_to_tactics:
            technique_to_tactics[tid] = set()
        technique_to_tactics[tid].add(tactic)
```

## 📥 JSON Import Processing

### Step-by-Step Process

#### 1. **Extract Imported Techniques**
```python
# Gather all unique technique IDs from the card
imported_techniques = []
if 'tactics_techniques' in card_data and isinstance(card_data['tactics_techniques'], list):
    for tactic_data in card_data['tactics_techniques']:
        for tech in tactic_data.get('techniques', []):
            if isinstance(tech, dict):
                imported_techniques.append(tech)
```

#### 2. **Technique Normalization**
```python
for tech in imported_techniques:
    raw_tid = tech.get('id', '').strip()
    tech_name = tech.get('name', '').strip()
    # Normalize to parent (e.g., T1055.001 -> T1055)
    parent_tid = raw_tid.split('.')[0] if '.' in raw_tid else raw_tid
```

#### 3. **Validation and Mapping**
```python
if parent_tid not in technique_to_tactics:
    import_warnings.append(f"Invalid technique ID: {raw_tid}")
    continue
# Use all tactics for the parent technique
for tactic in technique_to_tactics[parent_tid]:
    if tactic not in tactic_map:
        tactic_map[tactic] = []
    # Use the imported ID and name
    tactic_map[tactic].append({"id": raw_tid, "name": tech_name})
```

#### 4. **Final Structure Creation**
```python
# Compose the tactics_techniques structure
valid_tactics_techniques = [
    {"tactic": tactic, "techniques": techs}
    for tactic, techs in tactic_map.items()
]
```

## 📊 CSV Import Processing

### CSV Format Expected
```csv
title,description,threat_actor,platform,tactic,technique_id,technique_name,...
"Windows Process Injection","Detect process injection","APT29","Windows","Defense Evasion","T1055","Process Injection",...
```

### Processing Logic
```python
raw_tid = row.get('technique_id', '').strip()
tech_name = row.get('technique_name', '').strip()

# Normalize to parent (e.g., T1055.001 -> T1055)
parent_tid = raw_tid.split('.')[0] if '.' in raw_tid else raw_tid

if parent_tid not in technique_to_tactics:
    import_warnings.append(f"Invalid technique ID: {raw_tid}")
    tactics_techniques = []
else:
    tactics_techniques = []
    for tactic in technique_to_tactics[parent_tid]:
        tactics_techniques.append({
            "tactic": tactic,
            "techniques": [{"id": raw_tid, "name": tech_name}]
        })
```

## 🔄 Merge Operations

### Tactics and Techniques Merging
```python
def merge_tactics_techniques(existing_tactics, imported_tactics):
    """Merge tactics and techniques arrays"""
    merged = existing_tactics.copy()
    
    for imported_tactic in imported_tactics:
        # Check if tactic already exists
        tactic_exists = False
        for existing_tactic in merged:
            if existing_tactic.get("tactic") == imported_tactic.get("tactic"):
                # Merge techniques
                existing_techniques = existing_tactic.get("techniques", [])
                imported_techniques = imported_tactic.get("techniques", [])
                
                # Add new techniques that don't exist
                for imported_tech in imported_techniques:
                    tech_exists = any(tech.get("id") == imported_tech.get("id") 
                                    for tech in existing_techniques)
                    if not tech_exists:
                        existing_techniques.append(imported_tech)
                
                existing_tactic["techniques"] = existing_techniques
                tactic_exists = True
                break
        
        if not tactic_exists:
            merged.append(imported_tactic)
    
    return merged
```

## ⚠️ Validation and Error Handling

### 1. **Invalid Technique IDs**
- Technique IDs not found in MITRE ATT&CK data are flagged
- Import warnings are added to the hunt card
- Invalid techniques are skipped during processing

### 2. **Technique Normalization**
- Sub-techniques (e.g., T1055.001) are normalized to parent techniques (T1055)
- This ensures proper tactic mapping even if sub-techniques aren't in the MITRE data

### 3. **Duplicate Prevention**
- During merge operations, duplicate techniques are prevented
- Techniques are compared by ID to avoid duplicates

## 📈 Key Features

### ✅ **Automatic Tactic Mapping**
- Techniques are automatically mapped to their correct tactics
- Even if the imported data has incorrect tactic assignments, they're corrected

### ✅ **Sub-technique Support**
- Sub-techniques (e.g., T1055.001) are properly handled
- Normalized to parent techniques for validation

### ✅ **Import Warnings**
- Invalid technique IDs generate warnings
- Warnings are stored in the hunt card for review

### ✅ **Merge Intelligence**
- Smart merging prevents duplicate techniques
- Maintains existing tactic structure while adding new techniques

### ✅ **Data Integrity**
- All techniques are validated against MITRE ATT&CK framework
- Ensures consistency across the application

## 🔍 Example Processing

### Input JSON
```json
{
  "title": "Process Injection Detection",
  "tactics_techniques": [
    {
      "tactic": "Wrong Tactic",
      "techniques": [
        {
          "id": "T1055.001",
          "name": "Dynamic-link Library Injection"
        }
      ]
    }
  ]
}
```

### Processed Output
```json
{
  "title": "Process Injection Detection",
  "tactics_techniques": [
    {
      "tactic": "Defense Evasion",
      "techniques": [
        {
          "id": "T1055.001",
          "name": "Dynamic-link Library Injection"
        }
      ]
    }
  ],
  "import_warnings": []
}
```

## 🎯 Benefits

### **Data Quality**
- Ensures all techniques are valid MITRE ATT&CK techniques
- Corrects incorrect tactic assignments automatically

### **Consistency**
- Maintains consistent data structure across all hunt cards
- Prevents duplicate techniques during merge operations

### **Flexibility**
- Supports both JSON and CSV import formats
- Handles various technique ID formats (parent and sub-techniques)

### **Error Recovery**
- Graceful handling of invalid data
- Detailed warnings for data quality issues

## 📝 Best Practices

### **For JSON Imports**
- Use the exact MITRE ATT&CK technique IDs
- Include both `id` and `name` fields for techniques
- Structure tactics_techniques as an array of tactic objects

### **For CSV Imports**
- Use the expected column names: `tactic`, `technique_id`, `technique_name`
- Ensure technique IDs match MITRE ATT&CK framework
- Include all required fields

### **For Merge Operations**
- Review import warnings after merge
- Verify that techniques are properly mapped to tactics
- Check for any data quality issues

This sophisticated tactics and techniques handling ensures that all imported hunt cards maintain data integrity and consistency with the MITRE ATT&CK framework! 