#!/usr/bin/env python3
"""
Setup script for HCM (Hunt Card Manager)
Digital Forensics and Incident Response tool with MITRE ATT&CK framework integration
"""

from setuptools import setup, find_packages
import os
from pathlib import Path

# Read the README file for long description
def read_readme():
    readme_path = Path(__file__).parent / "README.md"
    if readme_path.exists():
        return readme_path.read_text(encoding='utf-8')
    return "HCM (Hunt Card Manager) - Digital Forensics and Incident Response tool"

# Read requirements file
def read_requirements():
    requirements_path = Path(__file__).parent / "requirements.txt"
    if requirements_path.exists():
        return [line.strip() for line in requirements_path.read_text().splitlines() 
                if line.strip() and not line.startswith('#')]
    return [
        'flask>=2.3.0',
        'werkzeug>=2.3.0',
        'requests>=2.28.0'
    ]

# Get version from app.py or use default
def get_version():
    app_path = Path(__file__).parent / "app.py"
    if app_path.exists():
        content = app_path.read_text()
        # Look for version in app.py
        for line in content.splitlines():
            if 'VERSION' in line and '=' in line:
                version = line.split('=')[1].strip().strip('"\'')
                return version
    return "1.0.0"

# Package data files
def get_package_data():
    return {
        'hcm': [
            'templates/*.html',
            'static/css/*.css',
            'static/js/*.js',
            'static/themes/*.css',
            'static/themes/*.js',
            'static/themes/*.json',
            'static/themes/*.md',
            'static/data/*.json',
            'static/*.csv',
            'static/*.json',
            'static/*.md',
        ]
    }

setup(
    name="hunt-card-manager",
    version=get_version(),
    author="HCM Development Team",
    author_email="hcm@example.com",
    description="Digital Forensics and Incident Response tool with MITRE ATT&CK framework integration",
    long_description=read_readme(),
    long_description_content_type="text/markdown",
    url="https://github.com/your-org/hunt-card-manager",
    project_urls={
        "Bug Tracker": "https://github.com/your-org/hunt-card-manager/issues",
        "Documentation": "https://github.com/your-org/hunt-card-manager/wiki",
    },
    classifiers=[
        "Development Status :: 4 - Beta",
        "Intended Audience :: Information Technology",
        "Intended Audience :: System Administrators",
        "License :: OSI Approved :: MIT License",
        "Operating System :: OS Independent",
        "Programming Language :: Python :: 3",
        "Programming Language :: Python :: 3.8",
        "Programming Language :: Python :: 3.9",
        "Programming Language :: Python :: 3.10",
        "Programming Language :: Python :: 3.11",
        "Programming Language :: Python :: 3.12",
        "Topic :: Security",
        "Topic :: System :: Systems Administration",
        "Topic :: Internet :: WWW/HTTP :: WSGI :: Application",
        "Framework :: Flask",
    ],
    keywords="digital forensics, incident response, mitre att&ck, cybersecurity, threat hunting",
    packages=find_packages(),
    package_data=get_package_data(),
    include_package_data=True,
    python_requires=">=3.8",
    install_requires=read_requirements(),
    extras_require={
        "dev": [
            "pytest>=7.0.0",
            "pytest-cov>=4.0.0",
            "black>=22.0.0",
            "flake8>=5.0.0",
            "mypy>=1.0.0",
        ],
        "production": [
            "gunicorn>=20.0.0",
            "waitress>=2.0.0",
        ],
    },
    entry_points={
        "console_scripts": [
            "hcm=hcm.cli:main",
            "hunt-card-manager=hcm.cli:main",
        ],
    },
    zip_safe=False,
    platforms=["any"],
    license="MIT",
    maintainer="HCM Development Team",
    maintainer_email="hcm@example.com",
) 