# Hunt Card Manager - Installation Guide

This guide provides step-by-step instructions for installing Hunt Card Manager on different platforms.

## Prerequisites

- **Python 3.8 or higher**
- **pip** (Python package installer)
- **Git** (for source installation)

## Installation Options

### Option 1: Quick Install (Recommended)

#### Windows
1. Download the latest release from GitHub
2. Run `install.bat` as administrator
3. Follow the prompts to choose installation and data directories
4. Launch from desktop shortcut

#### Linux/macOS
```bash
# Install from PyPI
pip install hunt-card-manager

# Initialize with default settings
hcm init

# Run the application
hcm run
```

### Option 2: Source Installation

#### Windows
```powershell
# Clone the repository
git clone https://github.com/your-org/hunt-card-manager.git
cd hunt-card-manager

# Run PowerShell installer
powershell -ExecutionPolicy Bypass -File install.ps1
```

#### Linux/macOS
```bash
# Clone the repository
git clone https://github.com/your-org/hunt-card-manager.git
cd hunt-card-manager

# Install in development mode
pip install -e .

# Initialize the application
hcm init

# Run the application
hcm run
```

### Option 3: Portable Installation

1. Download the portable ZIP file
2. Extract to any location
3. Install Python dependencies: `pip install -r requirements.txt`
4. Run: `python -m hcm.cli run`

## Configuration

### Data Directory

The data directory contains all your investigation cases and hunt cards. You can specify a custom location:

#### Environment Variable
```bash
# Windows
set HCM_DATA_DIR=C:\MyData\HCM

# Linux/macOS
export HCM_DATA_DIR=/path/to/data
```

#### Command Line
```bash
hcm run --data-dir /path/to/data
```

### Default Data Structure
```
HCM_Data/
├── cases/           # Investigation cases
│   ├── case-001/
│   │   └── huntcards.json
│   └── case-002/
│       └── huntcards.json
├── exports/         # Export files
└── logs/           # Application logs
```

## Command Line Interface

### Basic Commands
```bash
# Show help
hcm --help

# Initialize data directory
hcm init --data-dir /path/to/data

# Run the application
hcm run --host 0.0.0.0 --port 7997

# Show application info
hcm info

# Create backup
hcm backup --data-dir /path/to/data
```

### Advanced Options
```bash
# Run in production mode
hcm run --config production --host 0.0.0.0 --port 7997

# Run with debug mode
hcm run --debug

# Run with custom data directory
hcm run --data-dir /custom/data/path
```

## Troubleshooting

### Common Issues

#### 1. Port Already in Use
```bash
# Use a different port
hcm run --port 7998
```

#### 2. Permission Denied
```bash
# On Linux/macOS, check permissions
sudo chown -R $USER:$USER /path/to/data

# On Windows, run as administrator
```

#### 3. Python Not Found
```bash
# Ensure Python is in PATH
python --version

# Or use python3
python3 --version
```

#### 4. Dependencies Missing
```bash
# Install dependencies manually
pip install -r requirements.txt

# Or upgrade pip first
python -m pip install --upgrade pip
```

### Logs

Check the logs directory for error messages:
```
HCM_Data/logs/
```

### Environment Variables

| Variable | Description | Default |
|----------|-------------|---------|
| `HCM_DATA_DIR` | Data directory path | `~/HCM_Data` |
| `HCM_SECRET_KEY` | Flask secret key | Auto-generated |

## Security Considerations

### Production Deployment

1. **Set a strong secret key**:
   ```bash
   export HCM_SECRET_KEY="your-very-secure-secret-key"
   ```

2. **Use HTTPS**:
   - Configure a reverse proxy (nginx, Apache)
   - Use SSL certificates

3. **Restrict access**:
   - Use firewall rules
   - Configure authentication if needed

4. **Regular backups**:
   ```bash
   hcm backup --data-dir /path/to/data
   ```

### Data Protection

- Store data in a secure location
- Use appropriate file permissions
- Consider encryption for sensitive data
- Regular backups

## Uninstallation

### Windows
1. Use Control Panel > Programs > Uninstall
2. Or run the uninstaller from the installation directory

### Linux/macOS
```bash
# Remove package
pip uninstall hunt-card-manager

# Remove data (optional)
rm -rf ~/HCM_Data
```

## Support

If you encounter issues:

1. Check the troubleshooting section above
2. Review the logs in `HCM_Data/logs/`
3. Create an issue on GitHub
4. Contact support: support@hcm-tool.com

## Development Installation

For developers who want to contribute:

```bash
# Clone repository
git clone https://github.com/your-org/hunt-card-manager.git
cd hunt-card-manager

# Create virtual environment
python -m venv venv
source venv/bin/activate  # On Windows: venv\Scripts\activate

# Install in development mode
pip install -e ".[dev]"

# Run tests
pytest

# Run the application
hcm run --debug
``` 