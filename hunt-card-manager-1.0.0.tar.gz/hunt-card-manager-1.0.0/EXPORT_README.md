# HCM (Hunt Card Manager) - Clean Export

## 📦 What's Included

This is a clean export of the HCM application without test data, build artifacts, or development files.

### ✅ Core Application Files:
- **Flask Application** (`app.py`) - Main application server
- **Configuration** (`config.py`) - Application settings and data directory configuration
- **Templates** (`templates/`) - HTML templates for all pages
- **Static Files** (`static/`) - CSS, JavaScript, and theme files
- **MITRE ATT&CK Data** (`static/data/mitre_attack.json`) - MITRE framework data
- **Requirements** (`requirements.txt`) - Python dependencies

### ✅ Documentation:
- **README.md** - Main project documentation
- **INSTALLATION_GUIDE.md** - Installation instructions
- **TACTICS_TECHNIQUES_IMPORT_GUIDE.md** - Import guide for MITRE data
- **DATA_LOCATION_INFO.md** - Information about data storage configuration

### ✅ Templates and Assets:
- **Hunt Card Templates** - CSV and JSON templates for importing data
- **Theme System** - Light/dark theme support with customizable CSS
- **JavaScript Modules** - Interactive functionality for all pages

## 🚀 Quick Start

1. **Extract the archive:**
   ```bash
   tar -xzf HCM_Hunt_Card_Manager_*.tar.gz
   cd HCM_Hunt_Card_Manager_*
   ```

2. **Install dependencies:**
   ```bash
   pip install -r requirements.txt
   ```

3. **Run the application:**
   ```bash
   python app.py
   ```

4. **Access the application:**
   - Open your browser to `http://127.0.0.1:5000`
   - The application will use the current working directory for storing case data

## 🔧 Configuration

### Data Storage
The application is configured to store case data in the **current working directory** where you run the application. This means:

- Each investigation can have its own folder
- Case data is stored alongside the application
- Easy to backup entire investigation folders
- Portable - move investigation folders between systems

### Customizing Data Location
To change the data storage location, edit `config.py`:

```python
# Use current working directory (default)
DATA_DIR = "."

# Use a specific path
DATA_DIR = "C:\\HCM_Data"

# Use environment variable
DATA_DIR = None  # Uses HCM_DATA_DIR environment variable
```

## 📁 Application Structure

```
HCM_Hunt_Card_Manager/
├── app.py                 # Main Flask application
├── config.py              # Configuration settings
├── requirements.txt       # Python dependencies
├── templates/             # HTML templates
│   ├── home.html         # Home page
│   ├── analyze.html      # Case analysis page
│   ├── report.html       # Reporting page
│   └── ...
├── static/               # Static assets
│   ├── css/             # Stylesheets
│   ├── js/              # JavaScript files
│   ├── themes/          # Theme system
│   └── data/            # MITRE ATT&CK data
└── documentation/        # User guides and documentation
```

## 🎯 Key Features

- **MITRE ATT&CK Integration** - Full framework support with technique mapping
- **Evidence Management** - File upload and organization per investigation point
- **Advanced Filtering** - Filter by tactics, threat actors, platforms, conclusions
- **Reporting System** - Generate detailed CSV and text reports
- **Link Management** - Add and manage links per investigation point
- **Theme System** - Light and dark themes with customizable styling
- **Import/Export** - Support for CSV and JSON data formats

## 🔒 Security Notes

- This is a development server - not recommended for production use
- Change the `SECRET_KEY` in `config.py` for production deployments
- Consider using a production WSGI server like Gunicorn or uWSGI

## 📞 Support

For issues, questions, or contributions:
- Check the documentation files included in this export
- Review the configuration options in `config.py`
- The application includes comprehensive error handling and user feedback

## 🗓️ Export Information

- **Export Date:** Generated on build
- **Version:** Latest development version
- **Size:** ~4.7 MB (compressed)
- **Clean Build:** No test data, build artifacts, or development files included

---

**HCM (Hunt Card Manager)** - Digital Forensics and Incident Response tool with MITRE ATT&CK framework integration. 