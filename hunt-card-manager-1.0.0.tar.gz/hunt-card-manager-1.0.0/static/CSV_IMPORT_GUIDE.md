# Hunt Card Import Guide

## Overview

The application supports importing hunt cards in two formats:
1. **CSV Format** - Pure CSV data without embedded JSON, ideal for spreadsheet applications
2. **JSON Format** - Structured JSON data, ideal for programmatic imports and complex data

Both formats support up to 3 investigation points per hunt card, each with "what", "query", and "notes" fields.

## CSV Format

### CSV Template Structure

#### Required Columns
- `title` - The hunt card title
- `description` - Description of the hunt card
- `threat_actor` - The threat actor (can be empty)
- `platform` - Target platform (Windows, Linux, macOS, etc.)

#### Tactics & Techniques Columns
- `tactic` - MITRE ATT&CK tactic (e.g., "Persistence", "Execution", "Privilege Escalation")
- `technique_id` - MITRE ATT&CK technique ID (e.g., "T1547", "T1055")
- `technique_name` - MITRE ATT&CK technique name (e.g., "Boot or Logon Autostart Execution")

#### Investigation Points Columns (Up to 3 points per hunt card)
For each investigation point (1, 2, or 3), you can specify:
- `investigation_point_X_what` - What to investigate
- `investigation_point_X_query` - The query or command to run
- `investigation_point_X_notes` - Additional notes or context

### CSV Example
```csv
title,description,threat_actor,platform,tactic,technique_id,technique_name,investigation_point_1_what,investigation_point_1_query,investigation_point_1_notes,investigation_point_2_what,investigation_point_2_query,investigation_point_2_notes,investigation_point_3_what,investigation_point_3_query,investigation_point_3_notes
Registry Persistence Hunt,Detect registry-based persistence mechanisms,APT28,Windows,Persistence,T1547,Boot or Logon Autostart Execution,Check registry autostart locations,reg query "HKLM\SOFTWARE\Microsoft\Windows\CurrentVersion\Run" /s,Look for suspicious entries in Run keys,Monitor process creation,Get-Process | Where-Object {$_.ProcessName -like "*suspicious*"},Focus on processes with unusual names or paths,Check scheduled tasks,schtasks /query /fo csv,Review tasks for unauthorized persistence mechanisms
```

## JSON Format

### JSON Template Structure

Each hunt card in the JSON array should have the following structure:

```json
{
  "title": "Hunt Card Title",
  "description": "Description of the hunt card",
  "threat_actor": "APT28",
  "platform": "Windows",
  "tactics_techniques": [
    {
      "tactic": "Persistence",
      "techniques": [
        {
          "id": "T1547",
          "name": "Boot or Logon Autostart Execution"
        }
      ]
    }
  ],
  "investigation_points": [
    {
      "what": "Check registry autostart locations",
      "query": "reg query \"HKLM\\SOFTWARE\\Microsoft\\Windows\\CurrentVersion\\Run\" /s",
      "notes": "Look for suspicious entries in Run keys"
    }
  ]
}
```

### JSON Example
```json
[
  {
    "title": "Registry Persistence Hunt",
    "description": "Detect registry-based persistence mechanisms",
    "threat_actor": "APT28",
    "platform": "Windows",
    "tactics_techniques": [
      {
        "tactic": "Persistence",
        "techniques": [
          {
            "id": "T1547",
            "name": "Boot or Logon Autostart Execution"
          }
        ]
      }
    ],
    "investigation_points": [
      {
        "what": "Check registry autostart locations",
        "query": "reg query \"HKLM\\SOFTWARE\\Microsoft\\Windows\\CurrentVersion\\Run\" /s",
        "notes": "Look for suspicious entries in Run keys"
      },
      {
        "what": "Monitor process creation",
        "query": "Get-Process | Where-Object {$_.ProcessName -like \"*suspicious*\"}",
        "notes": "Focus on processes with unusual names or paths"
      }
    ]
  }
]
```

## Format Comparison

| Feature | CSV Format | JSON Format |
|---------|------------|-------------|
| **Ease of Use** | ✅ Easy in spreadsheets | ⚠️ Requires JSON knowledge |
| **Complex Data** | ⚠️ Limited to 3 investigation points | ✅ Unlimited investigation points |
| **Multiple Techniques** | ⚠️ One technique per card | ✅ Multiple techniques per card |
| **Programmatic Use** | ⚠️ Requires parsing | ✅ Native structure |
| **Spreadsheet Integration** | ✅ Excellent | ❌ Poor |
| **Data Validation** | ⚠️ Manual | ✅ Schema validation possible |

## Best Practices

### 1. Investigation Points Structure
- **What**: Describe what you're looking for (e.g., "Check registry autostart locations")
- **Query**: Provide the actual command or query to run (e.g., `reg query "HKLM\SOFTWARE\Microsoft\Windows\CurrentVersion\Run" /s`)
- **Notes**: Add context about what to look for or how to interpret results (e.g., "Look for suspicious entries in Run keys")

### 2. MITRE ATT&CK Integration
- Use official MITRE ATT&CK tactic and technique names
- Include both technique ID and name for better tracking
- Common tactics: Persistence, Execution, Privilege Escalation, Defense Evasion, Credential Access, Discovery, Lateral Movement, Collection, Command and Control, Exfiltration, Impact

### 3. Platform-Specific Queries
- **Windows**: Use PowerShell commands, registry queries, WMI queries
- **Linux**: Use shell commands, file system checks, process monitoring
- **macOS**: Use system_profiler, launchctl, plist analysis

### 4. Query Examples by Category

#### Registry Analysis (Windows)
```
investigation_point_1_what: Check registry autostart locations
investigation_point_1_query: reg query "HKLM\SOFTWARE\Microsoft\Windows\CurrentVersion\Run" /s
investigation_point_1_notes: Look for suspicious entries in Run keys
```

#### Process Analysis
```
investigation_point_1_what: Monitor process creation
investigation_point_1_query: Get-Process | Where-Object {$_.ProcessName -like "*suspicious*"}
investigation_point_1_notes: Focus on processes with unusual names or paths
```

#### Network Analysis
```
investigation_point_1_what: Monitor network connections
investigation_point_1_query: netstat -tuln | grep :443
investigation_point_1_notes: Look for unusual outbound connections
```

#### File System Analysis
```
investigation_point_1_what: Check for suspicious files
investigation_point_1_query: ls -la /tmp/ | grep -E "\.(zip|tar|gz)$"
investigation_point_1_notes: Identify suspicious archive files
```

## Import Process

1. **Download the template**: Choose CSV or JSON template based on your needs
2. **Fill in your data**: Use the examples above as a guide
3. **Save the file**: Ensure proper encoding (UTF-8)
4. **Upload**: Use the import panel to upload your file
5. **Verify**: Check that your hunt cards appear in the case view

## Tips for Large Imports

- **Batch your imports**: Import related hunt cards together
- **Use consistent naming**: Follow a naming convention for titles
- **Validate your data**: Check that all required fields are filled
- **Test with small batches**: Import a few cards first to verify the format
- **Choose the right format**: Use CSV for spreadsheet-based work, JSON for programmatic imports

## Troubleshooting

### Common Issues
1. **Encoding problems**: Ensure files are saved as UTF-8
2. **Missing commas/quotes**: Check CSV formatting
3. **Invalid JSON**: Validate JSON syntax before importing
4. **Empty required fields**: Title and description are required
5. **Special characters**: Escape quotes and special characters properly

### Error Messages
- "Import failed": Check file format and encoding
- "No file uploaded": Ensure file is selected before clicking import
- "Case not found": Verify you're importing to the correct case
- "Invalid JSON format": Check JSON syntax and structure
- "JSON file must contain an array": Ensure JSON file contains a list of hunt cards

## Custom Fields
The system supports additional fields that will be preserved during import/export cycles.

### Integration with Other Tools
Both formats are compatible with:
- SIEM systems
- Threat intelligence platforms
- Security orchestration tools
- Custom automation scripts 