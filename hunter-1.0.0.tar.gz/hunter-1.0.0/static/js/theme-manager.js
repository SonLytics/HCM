// Centralized Theme Manager for HCM Project
// This ensures theme changes are synchronized across all pages

class ThemeManager {
    constructor() {
        this.themeKey = 'hcm-theme';
        this.defaultTheme = 'white-light';
        this.init();
    }

    init() {
        // Load saved theme on page load
        this.loadTheme();
        
        // Set up theme toggle event listeners
        this.setupThemeToggle();
        
        // Apply theme to body
        this.applyTheme();
        
        // Listen for theme changes from other tabs/windows
        this.setupCrossTabSync();
    }

    loadTheme() {
        this.currentTheme = localStorage.getItem(this.themeKey) || this.defaultTheme;
    }

    saveTheme(theme) {
        this.currentTheme = theme;
        localStorage.setItem(this.themeKey, theme);
        
        // Broadcast theme change to other tabs
        this.broadcastThemeChange(theme);
    }

    applyTheme() {
        document.body.setAttribute('data-theme', this.currentTheme);
        console.log('Applied theme:', this.currentTheme);
        
        // Update theme toggle state if it exists
        const themeToggle = document.getElementById('theme-toggle');
        if (themeToggle) {
            themeToggle.checked = this.currentTheme === 'black-dark';
            console.log('Updated toggle state:', themeToggle.checked);
        }
    }

    setupThemeToggle() {
        const themeToggle = document.getElementById('theme-toggle');
        console.log('Theme toggle found:', themeToggle);
        if (themeToggle) {
            themeToggle.addEventListener('change', (e) => {
                console.log('Theme toggle changed:', e.target.checked);
                const newTheme = e.target.checked ? 'black-dark' : 'white-light';
                this.switchTheme(newTheme);
            });
        } else {
            console.warn('Theme toggle not found on page');
        }
    }

    switchTheme(newTheme) {
        this.saveTheme(newTheme);
        this.applyTheme();
        
        // Trigger custom event for other components
        document.dispatchEvent(new CustomEvent('themeChanged', {
            detail: { theme: newTheme }
        }));
    }

    setupCrossTabSync() {
        // Listen for storage events (theme changes from other tabs)
        window.addEventListener('storage', (e) => {
            if (e.key === this.themeKey && e.newValue) {
                this.currentTheme = e.newValue;
                this.applyTheme();
            }
        });

        // Listen for custom theme change events
        document.addEventListener('themeChanged', (e) => {
            this.currentTheme = e.detail.theme;
            this.applyTheme();
        });
    }

    broadcastThemeChange(theme) {
        // Broadcast to other tabs via localStorage
        localStorage.setItem(this.themeKey, theme);
        
        // Also dispatch custom event
        document.dispatchEvent(new CustomEvent('themeChanged', {
            detail: { theme: theme }
        }));
    }

    // Public method to get current theme
    getCurrentTheme() {
        return this.currentTheme;
    }

    // Public method to check if dark theme is active
    isDarkTheme() {
        return this.currentTheme === 'black-dark';
    }
}

// Initialize theme manager when DOM is loaded
document.addEventListener('DOMContentLoaded', () => {
    window.themeManager = new ThemeManager();
});

// Also initialize immediately if DOM is already loaded
if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', () => {
        window.themeManager = new ThemeManager();
    });
} else {
    window.themeManager = new ThemeManager();
} 