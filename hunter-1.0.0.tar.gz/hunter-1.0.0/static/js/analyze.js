function suggest(type, idx) {
    const inputSelector = type === 'what' ? `input[name="what_${idx}"]` : `textarea[name="query_${idx}"]`;
    const input = document.querySelector(inputSelector);
    const keywords = encodeURIComponent(input.value.trim());

    if (!keywords || keywords.length < 2) {
        alert("Type at least 2 characters to get suggestions.");
        return;
    }

    fetch(`/case/${caseId}/suggest/${type}?keywords=${keywords}`)
        .then(resp => {
            if (!resp.ok) throw new Error("Server error");
            return resp.json();
        })
        .then(data => showSuggestionPanel(input, data))
        .catch(err => {
            console.error("Suggestion error:", err);
            alert("Failed to get suggestions.");
        });
}

function showSuggestionPanel(anchorInput, suggestions) {
    let panel = document.getElementById('suggestion-floating-panel');
    if (panel) panel.remove();

    panel = document.createElement('div');
    panel.id = 'suggestion-floating-panel';
    panel.style = `
        position: absolute;
        background: white;
        border: 1px solid #ccc;
        border-radius: 4px;
        padding: 8px;
        max-width: 400px;
        z-index: 9999;
        box-shadow: 0 2px 8px rgba(0,0,0,0.2);
    `;

    const rect = anchorInput.getBoundingClientRect();
    panel.style.top = `${window.scrollY + rect.bottom + 4}px`;
    panel.style.left = `${window.scrollX + rect.left}px`;

    if (suggestions.length === 0) {
        panel.innerHTML = "<em>No suggestions found.</em>";
    } else {
        const list = document.createElement('ul');
        list.style = "list-style: none; margin: 0; padding: 0;";
        suggestions.forEach(s => {
            const li = document.createElement('li');
            li.style = "padding:4px; margin-bottom:4px; background:#f0f0f0; border-radius:4px; cursor:pointer;";
            li.textContent = s;
            li.onclick = () => {
                anchorInput.value = s;
                panel.remove();
            };
            list.appendChild(li);
        });
        panel.appendChild(list);
    }

    document.body.appendChild(panel);

    document.addEventListener('click', function dismiss(e) {
        if (!panel.contains(e.target) && e.target !== anchorInput) {
            panel.remove();
            document.removeEventListener('click', dismiss);
        }
    });
}

// Analyze Page JavaScript
const themeToggle = document.getElementById('theme-toggle');
const toggleKnob = document.getElementById('toggle-knob');

function setTheme(theme) {
  document.body.setAttribute('data-theme', theme);
  localStorage.setItem('theme', theme);
  if (theme === 'black-dark') {
    themeToggle.checked = true;
    toggleKnob.style.left = '2px';
  } else {
    themeToggle.checked = false;
    toggleKnob.style.left = '18px';
  }
}

// Theme toggle event listener
if (themeToggle) {
  themeToggle.addEventListener('change', function() {
    setTheme(this.checked ? 'black-dark' : 'white-light');
  });
}

// Initialize theme on page load
document.addEventListener('DOMContentLoaded', function() {
  const savedTheme = localStorage.getItem('theme') || 'white-light';
  setTheme(savedTheme);
});

function toggleDropdown(dropdownId) {
  const dropdown = document.getElementById(dropdownId);
  const allDropdowns = document.querySelectorAll('.dropdown-options');
  
  // Close all other dropdowns
  allDropdowns.forEach(d => {
    if (d.id !== dropdownId) {
      d.classList.remove('show');
    }
  });
  
  // Toggle current dropdown
  dropdown.classList.toggle('show');
}

// Close dropdowns when clicking outside
document.addEventListener('click', function(event) {
  const dropdowns = document.querySelectorAll('.dropdown-options');
  const dropdownButtons = document.querySelectorAll('.filter-dropdown-btn');
  
  let clickedInside = false;
  dropdownButtons.forEach(button => {
    if (button.contains(event.target)) {
      clickedInside = true;
    }
  });
  
  if (!clickedInside) {
    dropdowns.forEach(dropdown => {
      dropdown.classList.remove('show');
    });
  }
});

// Platform selection handler
function handlePlatformChange() {
    const platformSelect = document.getElementById("platform");
    const customContainer = document.getElementById("custom-platform-container");
    if (platformSelect && customContainer) {
        customContainer.style.display = platformSelect.value === "Other" ? "block" : "none";
    }
}

// Add event listener for platform selection on page load
document.addEventListener('DOMContentLoaded', function() {
    const platformSelect = document.getElementById("platform");
    if (platformSelect) {
        platformSelect.addEventListener("change", handlePlatformChange);
    }
});

// --- Filter Persistence and Clear Button ---
document.addEventListener('DOMContentLoaded', function() {
  // Save filter selection to localStorage on filter click
  document.querySelectorAll('.dropdown-option').forEach(function(option) {
    option.addEventListener('click', function(e) {
      // Only save if not 'All Hunt Cards'
      if (!option.href.includes('filter=all')) {
        localStorage.setItem('analyze_filter', option.href);
      } else {
        localStorage.removeItem('analyze_filter');
      }
    });
  });

  // On page load, apply saved filter if present and not already on that filter
  const savedFilter = localStorage.getItem('analyze_filter');
  if (savedFilter && window.location.href !== savedFilter) {
    window.location.href = savedFilter;
  }

  // Clear button logic
  const clearBtn = document.getElementById('clear-filter-btn');
  if (clearBtn) {
    clearBtn.addEventListener('click', function() {
      localStorage.removeItem('analyze_filter');
      // Go to the base analyze page (no filter)
      const baseUrl = window.location.href.split('?')[0];
      window.location.href = baseUrl;
    });
  }
});

// Query Management Functions
let currentInvestigationPoint = null;

function openQueryModal(pointIndex) {
    console.log('openQueryModal called with pointIndex:', pointIndex);
    console.log('caseId:', caseId, 'huntcardIdx:', huntcardIdx);
    
    currentInvestigationPoint = pointIndex;
    const modal = document.getElementById('query-modal');
    if (modal) {
        modal.style.display = 'block';
        switchTab('new');
    } else {
        console.error('Query modal not found!');
        alert('Query modal not found. Please refresh the page.');
    }
}

function closeQueryModal() {
    document.getElementById('query-modal').style.display = 'none';
    currentInvestigationPoint = null;
    // Clear form
    document.getElementById('new-query-form').reset();
    document.getElementById('queries-suggestions').innerHTML = '<div class="no-suggestions">Type to search for existing queries</div>';
}

function switchTab(tabName) {
    console.log('switchTab called with tabName:', tabName);
    
    // Update tab buttons
    document.querySelectorAll('.tab-btn').forEach(btn => btn.classList.remove('active'));
    if (event && event.target) {
        event.target.classList.add('active');
    }
    
    // Update tab content
    document.querySelectorAll('.tab-content').forEach(content => content.classList.remove('active'));
    const targetTab = document.getElementById(tabName + '-query-tab');
    if (targetTab) {
        targetTab.classList.add('active');
    } else {
        console.error('Tab content not found:', tabName + '-query-tab');
    }
}

function suggestQueries(fieldId) {
    const queryName = document.getElementById(fieldId).value.trim();
    if (!queryName) {
        alert('Please enter a query name first');
        return;
    }
    
    // Get suggestions from backend
    fetch(`/case/${caseId}/suggest_queries?keywords=${encodeURIComponent(queryName)}`)
        .then(response => response.json())
        .then(suggestions => {
            displayQuerySuggestions(suggestions);
        })
        .catch(error => {
            console.error('Error fetching query suggestions:', error);
            alert('Error fetching suggestions');
        });
}

function displayQuerySuggestions(suggestions) {
    const container = document.getElementById('queries-suggestions');
    
    if (suggestions.length === 0) {
        container.innerHTML = '<div class="no-suggestions">No matching queries found</div>';
        return;
    }
    
    container.innerHTML = suggestions.map(suggestion => `
        <div class="query-suggestion-item">
            <div class="query-suggestion-info">
                <div class="query-suggestion-name">${suggestion.name}</div>
                <div class="query-suggestion-text">${suggestion.query}</div>
                ${suggestion.link ? `<div class="query-suggestion-link">${suggestion.link}</div>` : ''}
            </div>
            <div class="query-suggestion-actions">
                <button class="query-suggestion-btn" onclick="linkQuery('${suggestion.id}')">Link</button>
            </div>
        </div>
    `).join('');
}

function searchQueries(keywords) {
    if (!keywords.trim()) {
        document.getElementById('queries-suggestions').innerHTML = '<div class="no-suggestions">Type to search for existing queries</div>';
        return;
    }
    
    fetch(`/case/${caseId}/suggest_queries?keywords=${encodeURIComponent(keywords)}`)
        .then(response => response.json())
        .then(suggestions => {
            displayQuerySuggestions(suggestions);
        })
        .catch(error => {
            console.error('Error searching queries:', error);
        });
}

function saveNewQuery() {
    const form = document.getElementById('new-query-form');
    const formData = new FormData(form);
    
    const queryData = {
        name: formData.get('query-name'),
        query: formData.get('query-text'),
        link: formData.get('query-link'),
        username: formData.get('query-username')
    };
    
    if (!queryData.name || !queryData.query || !queryData.username) {
        alert('Please fill in all required fields');
        return;
    }
    
    fetch(`/case/${caseId}/huntcard/${huntcardIdx}/investigation/${currentInvestigationPoint}/add_query`, {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json'
        },
        body: JSON.stringify(queryData)
    })
    .then(response => response.json())
    .then(data => {
        if (data.success) {
            closeQueryModal();
            refreshQueriesList(currentInvestigationPoint);
            alert('Query added successfully');
        } else {
            alert('Error: ' + data.error);
        }
    })
    .catch(error => {
        console.error('Error adding query:', error);
        alert('Error adding query');
    });
}

function linkQuery(queryId) {
    fetch(`/case/${caseId}/huntcard/${huntcardIdx}/investigation/${currentInvestigationPoint}/link_query`, {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json'
        },
        body: JSON.stringify({ query_id: queryId })
    })
    .then(response => response.json())
    .then(data => {
        if (data.success) {
            closeQueryModal();
            refreshQueriesList(currentInvestigationPoint);
            alert('Query linked successfully');
        } else {
            alert('Error: ' + data.error);
        }
    })
    .catch(error => {
        console.error('Error linking query:', error);
        alert('Error linking query');
    });
}

function refreshQueriesList(pointIndex) {
    // Reload the page to refresh the queries list
    // In a more sophisticated implementation, you could update the DOM directly
    location.reload();
}

function uploadQueryOutput(caseId, huntcardIdx, pointIdx, queryId) {
    // Create a file input element
    const fileInput = document.createElement('input');
    fileInput.type = 'file';
    fileInput.multiple = true;
    fileInput.accept = '*/*';
    
    fileInput.onchange = function() {
        const files = fileInput.files;
        if (files.length === 0) return;
        
        const formData = new FormData();
        for (let i = 0; i < files.length; i++) {
            formData.append('files', files[i]);
        }
        
        fetch(`/case/${caseId}/huntcard/${huntcardIdx}/investigation/${pointIdx}/upload_output/${queryId}`, {
            method: 'POST',
            body: formData
        })
        .then(response => response.json())
        .then(data => {
            if (data.success) {
                alert(`Successfully uploaded ${data.files.length} files`);
                refreshQueriesList(pointIdx);
            } else {
                alert('Error: ' + data.error);
            }
        })
        .catch(error => {
            console.error('Error uploading files:', error);
            alert('Error uploading files');
        });
    };
    
    fileInput.click();
}

function openQueryOutput(caseId, huntcardIdx, pointIdx, queryId) {
    fetch(`/case/${caseId}/huntcard/${huntcardIdx}/investigation/${pointIdx}/open_output/${queryId}`)
        .then(response => response.json())
        .then(data => {
            if (data.success) {
                // For Windows, we can't directly open the folder from the browser
                // But we can show the path to the user
                alert(`Output folder: ${data.folder_path}\n\nPlease open this folder manually in your file explorer.`);
            } else {
                alert('Error: ' + data.error);
            }
        })
        .catch(error => {
            console.error('Error opening output folder:', error);
            alert('Error opening output folder');
        });
}

function deleteQuery(pointIndex, queryId) {
    if (!confirm('Are you sure you want to delete this query?')) {
        return;
    }
    
    // This would need a backend endpoint to delete queries
    // For now, we'll just show an alert
    alert('Delete query functionality will be implemented in the backend');
}
