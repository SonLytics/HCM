// Home Page JavaScript
const themeToggle = document.getElementById('theme-toggle');
const toggleKnob = document.getElementById('toggle-knob');
const sidebar = document.getElementById('sidebar');
const mainContent = document.getElementById('main-content');
const sidebarOverlay = document.getElementById('sidebar-overlay');

function setTheme(theme) {
  document.body.setAttribute('data-theme', theme);
  localStorage.setItem('theme', theme);
  if (theme === 'black-dark') {
    themeToggle.checked = true;
    toggleKnob.style.left = '2px';
  } else {
    themeToggle.checked = false;
    toggleKnob.style.left = '18px';
  }
}

function submitNewCase(event) {
  event.preventDefault();
  const formData = new FormData(event.target);
  const caseId = formData.get('case_id');
  
  if (!caseId.trim()) {
    alert('Please enter a Case ID');
    return;
  }
  
  // Validate case ID format (optional)
  if (caseId.length < 3) {
    alert('Case ID must be at least 3 characters long');
    return;
  }
  
  // Submit the form
  event.target.submit();
}

function toggleSidebar() {
  const isOpen = sidebar.classList.contains('show');
  
  if (isOpen) {
    sidebar.classList.remove('show');
    mainContent.classList.remove('sidebar-open');
    sidebarOverlay.classList.remove('show');
  } else {
    sidebar.classList.add('show');
    mainContent.classList.add('sidebar-open');
    sidebarOverlay.classList.add('show');
  }
}

// Theme toggle event listener
if (themeToggle) {
  themeToggle.addEventListener('change', function() {
    setTheme(this.checked ? 'black-dark' : 'white-light');
  });
}

// Initialize on page load
document.addEventListener('DOMContentLoaded', function() {
  const savedTheme = localStorage.getItem('theme') || 'white-light';
  setTheme(savedTheme);
  
  // Handle Enter key in case ID input
  const caseIdInput = document.getElementById('case_id');
  if (caseIdInput) {
    caseIdInput.addEventListener('keypress', function(event) {
      if (event.key === 'Enter') {
        event.preventDefault();
        const form = this.closest('form');
        submitNewCase({ target: form, preventDefault: () => {} });
      }
    });
  }
  
  // Hide form if there are success messages (case was created successfully)
  const flashMessages = document.querySelector('.flash-messages');
  if (flashMessages && !flashMessages.classList.contains('error')) {
    // Success message - clear form
    const caseIdField = document.getElementById('case_id');
    if (caseIdField) {
      caseIdField.value = '';
    }
  }
});

// Close sidebar when clicking outside on mobile
document.addEventListener('click', function(event) {
  if (window.innerWidth <= 768) {
    const isClickInsideSidebar = sidebar && sidebar.contains(event.target);
    const isClickOnToggle = event.target.closest('.sidebar-toggle');
    
    if (!isClickInsideSidebar && !isClickOnToggle && sidebar && sidebar.classList.contains('show')) {
      toggleSidebar();
    }
  }
}); 