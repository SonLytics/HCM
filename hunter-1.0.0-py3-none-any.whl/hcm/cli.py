#!/usr/bin/env python3
"""
Command Line Interface for Hunt Card Manager (HCM)
"""

import argparse
import os
import sys
from pathlib import Path

def main():
    """Main CLI entry point"""
    parser = argparse.ArgumentParser(
        description="Hunt Card Manager (HCM) - A professional DFIR tool for managing hunt cards and investigation cases",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
Examples:
  hcm run                    # Run on default port 7997
  hcm run --port 8080       # Run on port 8080
  hcm run --data-dir /path/to/data  # Use custom data directory
  hcm run --host 0.0.0.0 --port 7997  # Run on all interfaces
        """
    )
    
    subparsers = parser.add_subparsers(dest='command', help='Available commands')
    
    # Run command
    run_parser = subparsers.add_parser('run', help='Start the HCM web server')
    run_parser.add_argument(
        '--host', 
        default='127.0.0.1',
        help='Host to bind to (default: 127.0.0.1)'
    )
    run_parser.add_argument(
        '--port', 
        type=int,
        default=7997,
        help='Port to bind to (default: 7997)'
    )
    run_parser.add_argument(
        '--data-dir',
        help='Custom data directory path'
    )
    run_parser.add_argument(
        '--debug',
        action='store_true',
        help='Enable debug mode'
    )
    
    args = parser.parse_args()
    
    if not args.command:
        parser.print_help()
        return 1
    
    if args.command == 'run':
        return run_server(args)
    
    return 0

def run_server(args):
    """Run the HCM web server"""
    try:
        # Import app here to avoid circular imports
        from hcm.app import app
        
        # Set custom data directory if provided
        if args.data_dir:
            data_dir = Path(args.data_dir)
            if not data_dir.exists():
                print(f"Creating data directory: {data_dir}")
                data_dir.mkdir(parents=True, exist_ok=True)
            app.config['DATA_DIR'] = str(data_dir)
        else:
            # Use config file, environment variable, or default
            try:
                from config import ensure_data_dir
                data_dir = ensure_data_dir()
                app.config['DATA_DIR'] = data_dir
            except ImportError:
                # Fallback to environment variable or default
                env_data_dir = os.environ.get('HCM_DATA_DIR')
                if env_data_dir:
                    data_dir = Path(env_data_dir)
                    if not data_dir.exists():
                        print(f"Creating data directory from environment variable: {data_dir}")
                        data_dir.mkdir(parents=True, exist_ok=True)
                    app.config['DATA_DIR'] = str(data_dir)
        
        print(f"Starting HCM server on {args.host}:{args.port}")
        print(f"Data directory: {app.config.get('DATA_DIR', 'data')}")
        print(f"Debug mode: {args.debug}")
        print(f"Access the application at: http://{args.host}:{args.port}")
        print("Press Ctrl+C to stop the server")
        
        app.run(
            host=args.host,
            port=args.port,
            debug=args.debug
        )
        
    except KeyboardInterrupt:
        print("\nServer stopped by user")
        return 0
    except Exception as e:
        print(f"Error starting server: {e}")
        return 1

if __name__ == '__main__':
    sys.exit(main()) 