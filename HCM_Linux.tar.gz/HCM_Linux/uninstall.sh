#!/bin/bash
# Hunt Card Manager Linux Uninstallation Script

set -e

echo "Uninstalling Hunt Card Manager..."

# Check if running as root
if [ "$EUID" -ne 0 ]; then
    echo "Please run as root (use sudo)"
    exit 1
fi

# Stop and disable service
systemctl stop hunt-card-manager.service || true
systemctl disable hunt-card-manager.service || true

# Remove files
rm -f /usr/local/bin/hcm
rm -rf /usr/share/hunt-card-manager
rm -f /etc/systemd/system/hunt-card-manager.service
rm -f /usr/share/applications/hunt-card-manager.desktop
rm -rf /etc/hunt-card-manager

# Remove user and group (optional - comment out if you want to keep them)
# userdel hcm || true
# groupdel hcm || true

# Remove data (optional - comment out if you want to keep the data)
# rm -rf /var/lib/hunt-card-manager
# rm -rf /var/log/hunt-card-manager

systemctl daemon-reload

echo "Hunt Card Manager uninstalled successfully!"
