#!/bin/bash
# Hunt Card Manager Linux Installation Script

set -e

echo "Installing Hunt Card Manager..."

# Check if running as root
if [ "$EUID" -ne 0 ]; then
    echo "Please run as root (use sudo)"
    exit 1
fi

# Create user and group
if ! id "hcm" &>/dev/null; then
    useradd -r -s /bin/false -d /var/lib/hunt-card-manager hcm
fi

# Copy files
cp -r usr/* /usr/
cp -r var/* /var/
cp -r etc/* /etc/

# Set permissions
chown -R hcm:hcm /var/lib/hunt-card-manager
chown -R hcm:hcm /etc/hunt-card-manager
chmod 755 /usr/local/bin/hcm
chmod 644 /etc/systemd/system/hunt-card-manager.service
chmod 644 /usr/share/applications/hunt-card-manager.desktop

# Create log directory
mkdir -p /var/log/hunt-card-manager
chown hcm:hcm /var/log/hunt-card-manager

# Install Python dependencies
pip3 install -r /usr/share/hunt-card-manager/app/requirements.txt

# Enable and start service
systemctl daemon-reload
systemctl enable hunt-card-manager.service
systemctl start hunt-card-manager.service

echo "Hunt Card Manager installed successfully!"
echo "Access the web interface at: http://localhost:7997"
echo "Service status: systemctl status hunt-card-manager"
