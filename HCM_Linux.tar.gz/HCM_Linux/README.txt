Hunt Card Manager - Linux Package

This package provides a complete Linux installation of Hunt Card Manager.

Installation:
1. Extract this package
2. Run: sudo ./install.sh

Uninstallation:
1. Run: sudo ./uninstall.sh

Features:
- Systemd service for automatic startup
- Desktop integration
- Proper file permissions
- Dedicated user account
- Logging support

Service Management:
- Start: sudo systemctl start hunt-card-manager
- Stop: sudo systemctl stop hunt-card-manager
- Status: sudo systemctl status hunt-card-manager
- Enable: sudo systemctl enable hunt-card-manager
- Disable: sudo systemctl disable hunt-card-manager

Access the web interface at: http://localhost:7997
