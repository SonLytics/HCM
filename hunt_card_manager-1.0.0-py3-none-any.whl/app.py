import json
from flask import Flask, render_template, redirect, url_for, flash, request, jsonify, send_file
import os
from datetime import datetime
import csv
import io
import re
import shutil
import tempfile
import zipfile
import logging

# Always use absolute paths for template and static folders
BASE_DIR = os.path.dirname(os.path.abspath(__file__))
TEMPLATE_DIR = os.path.join(BASE_DIR, 'templates')
STATIC_DIR = os.path.join(BASE_DIR, 'static')

app = Flask(__name__, template_folder=TEMPLATE_DIR, static_folder=STATIC_DIR)
app.secret_key = 'super_secret_key'  # required for flashing messages

# Data directory configuration
# Can be set via environment variable HCM_DATA_DIR, CLI argument --data-dir, or config.py
try:
    from config import get_data_dir
    app.config['DATA_DIR'] = get_data_dir()
except ImportError:
    app.config['DATA_DIR'] = os.environ.get('HCM_DATA_DIR', 'data')  # fallback

# Security validation functions
def validate_case_id(case_id):
    """Validate case_id to prevent path traversal attacks"""
    if not case_id or not isinstance(case_id, str):
        return False
    
    # Remove any path traversal attempts and normalize
    sanitized = case_id.replace('..', '').replace('/', '').replace('\\', '').strip()
    
    # Check if sanitization changed the input (indicates attack attempt)
    if sanitized != case_id.strip():
        return False
    
    # Validate format: alphanumeric, hyphens, underscores only
    if not re.match(r'^[a-zA-Z0-9_-]+$', sanitized):
        return False
    
    # Check length limits
    if len(sanitized) < 1 or len(sanitized) > 100:
        return False
    
    return sanitized

def validate_file_upload(file):
    """Validate file upload for security"""
    print(f"DEBUG: validate_file_upload called for file: {file.filename if file else 'None'}")
    if not file or file.filename == '':
        print("DEBUG: No file or empty filename")
        raise ValueError("No file selected")
    
    # Check file size (10MB limit)
    file.seek(0, 2)  # Seek to end
    file_size = file.tell()
    file.seek(0)  # Reset to beginning
    
    if file_size > 10 * 1024 * 1024:  # 10MB
        raise ValueError("File too large. Maximum size is 10MB")
    
    # Validate file extension
    allowed_extensions = {'.csv', '.json', '.zip'}
    file_extension = os.path.splitext(file.filename.lower())[1]
    
    if file_extension not in allowed_extensions:
        raise ValueError("Invalid file type. Only CSV, JSON, and ZIP files are allowed")
    
    # Additional validation for JSON files
    if file_extension == '.json':
        print("DEBUG: Validating JSON file")
        try:
            content = file.read().decode('utf-8')
            print("DEBUG: Successfully decoded JSON file with UTF-8")
            file.seek(0)  # Reset for later use
            json.loads(content)  # Validate JSON structure
            print("DEBUG: Successfully parsed JSON structure")
        except UnicodeDecodeError as e:
            print(f"DEBUG: UTF-8 decode error in JSON validation: {e}")
            raise ValueError("Invalid JSON file format")
        except json.JSONDecodeError as e:
            print(f"DEBUG: JSON decode error in validation: {e}")
            raise ValueError("Invalid JSON file format")
    elif file_extension == '.zip':
        # For ZIP files, we'll validate during extraction
        pass
    
    return True

def get_safe_case_path(case_id):
    """Get safe case path after validation"""
    validated_id = validate_case_id(case_id)
    if not validated_id:
        raise ValueError("Invalid case ID")
    return os.path.join(app.config['DATA_DIR'], validated_id)

@app.route("/", methods=["GET", "POST"])
def home():
    if request.method == "POST":
        case_id = request.form.get("case_id", "").strip()

        if not case_id:
            flash("Case ID cannot be empty.", "error")
            return redirect(url_for("home"))

        case_folder = get_safe_case_path(case_id)

        # Check if case folder already exists
        if os.path.exists(case_folder):
            flash(f"Case '{case_id}' already exists!", "error")
            return redirect(url_for("home"))

        try:
            os.makedirs(case_folder)
            # Initialize empty huntcards.json
            with open(os.path.join(case_folder, "huntcards.json"), "w") as f:
                f.write("[]")
            
            # Enable evidence management by default
            evidence_config_file = os.path.join(case_folder, "evidence_config.json")
            config = {
                "enabled": True,
                "created": datetime.now().isoformat(),
                "folder_structure": "huntcard_evidence/point_"
            }
            with open(evidence_config_file, "w") as f:
                json.dump(config, f, indent=2)
            
            # Create evidence folder structure
            evidence_root = os.path.join(case_folder, "evidence")
            if not os.path.exists(evidence_root):
                os.makedirs(evidence_root)
            
            # Create evidence mapping file
            evidence_mapping_file = os.path.join(case_folder, "evidence_mapping.json")
            with open(evidence_mapping_file, "w") as f:
                json.dump({}, f, indent=2)
            
            flash(f"Case '{case_id}' created successfully!", "success")
            return redirect(url_for("home"))
        except Exception as e:
            flash(f"Error creating case: {e}", "error")
            return redirect(url_for("home"))

    # GET request - display cases
    cases = []

    if os.path.exists(app.config['DATA_DIR']):
        for case_folder in os.listdir(app.config['DATA_DIR']):
            try:
                case_path = get_safe_case_path(case_folder)
                if os.path.isdir(case_path):
                    huntcards_file = os.path.join(case_path, "huntcards.json")
                    if os.path.exists(huntcards_file):
                        last_updated = datetime.fromtimestamp(os.path.getmtime(huntcards_file))
                    else:
                        last_updated = None

                    cases.append({
                        "case_id": case_folder,
                        "last_updated": last_updated
                    })
            except ValueError:
                # Skip invalid case folder names
                continue

    # Sort cases by last_updated (most recent first), handle None values last
    cases.sort(key=lambda x: x["last_updated"] or datetime.min, reverse=True)

    return render_template("home.html", cases=cases)

@app.route("/case/<case_id>")
def case_view(case_id):
    case_folder = get_safe_case_path(case_id)
    huntcards_file = os.path.join(case_folder, "huntcards.json")

    huntcards = []
    if os.path.exists(huntcards_file):
        with open(huntcards_file, "r") as f:
            try:
                huntcards = json.load(f)
            except json.JSONDecodeError:
                flash("Corrupted huntcards.json.", "error")

    # Gather all unique tactics, threat actors, and platforms
    all_tactics = set()
    all_threat_actors = set()
    all_platforms = set()
    for card in huntcards:
        # Extract tactic(s)
        tactic = ''
        tactics_techniques = card.get('tactics_techniques', [])
        if isinstance(tactics_techniques, dict) and tactics_techniques.get('tactic'):
            tactic = tactics_techniques['tactic']
        elif isinstance(tactics_techniques, list) and tactics_techniques:
            if isinstance(tactics_techniques[0], dict) and tactics_techniques[0].get('tactic'):
                tactic = tactics_techniques[0]['tactic']
        elif isinstance(tactics_techniques, str):
            tactic = tactics_techniques
        if tactic:
            all_tactics.add(tactic)
        # Threat actor
        threat_actor = card.get('threat_actor', '').strip()
        if threat_actor:
            all_threat_actors.add(threat_actor)
        # Platform
        platform = card.get('platform', '').strip()
        if platform:
            all_platforms.add(platform)

    all_tactics = sorted(list(all_tactics))
    all_threat_actors = sorted(list(all_threat_actors))
    all_platforms = sorted(list(all_platforms))

    # Filtering logic
    filter_type = request.args.get('filter')
    filter_value = request.args.get('value')
    filtered_huntcards = huntcards
    filter_criteria = None
    active_filter = None
    if filter_type and filter_value and filter_type in ['tactics', 'threat_actor', 'platform']:
        active_filter = filter_type
        filter_criteria = filter_value
        if filter_type == 'tactics':
            filtered_huntcards = [card for card in huntcards if (
                (isinstance(card.get('tactics_techniques', []), dict) and card['tactics_techniques'].get('tactic') == filter_value) or
                (isinstance(card.get('tactics_techniques', []), list) and card['tactics_techniques'] and isinstance(card['tactics_techniques'][0], dict) and card['tactics_techniques'][0].get('tactic') == filter_value) or
                (isinstance(card.get('tactics_techniques', ''), str) and card['tactics_techniques'] == filter_value)
            )]
        elif filter_type == 'threat_actor':
            filtered_huntcards = [card for card in huntcards if card.get('threat_actor', '').strip() == filter_value]
        elif filter_type == 'platform':
            filtered_huntcards = [card for card in huntcards if card.get('platform', '').strip() == filter_value]
    else:
        filter_criteria = 'All'
        active_filter = None

    # Optional: Add pagination (apply after filtering)
    page = request.args.get("page", 1, type=int)
    per_page = 10
    total = len(filtered_huntcards)
    total_pages = (total + per_page - 1) // per_page
    start_idx = (page - 1) * per_page
    end_idx = start_idx + per_page
    paginated_huntcards = filtered_huntcards[start_idx:end_idx]

    return render_template(
        "huntcard_list.html",
        case_id=case_id,
        huntcards=paginated_huntcards,  # Pass only paginated cards
        page=page,
        total_pages=total_pages,
        per_page=per_page,
        all_tactics=all_tactics,
        all_threat_actors=all_threat_actors,
        all_platforms=all_platforms,
        active_filter=active_filter,
        filter_criteria=filter_criteria
    )

@app.route("/case/<case_id>/suggest/<suggest_type>")
def suggest_investigation(case_id, suggest_type):
    keywords = request.args.get("keywords", "").strip().lower()
    if not keywords or len(keywords) < 2:
        return jsonify([])  # Return empty for too-short or empty keywords

    case_folder = get_safe_case_path(case_id)
    huntcards_file = os.path.join(case_folder, "huntcards.json")

    suggestions = set()

    if os.path.exists(huntcards_file):
        with open(huntcards_file, "r") as f:
            try:
                huntcards = json.load(f)
            except json.JSONDecodeError:
                huntcards = []

        for card in huntcards:
            for point in card.get("investigation_points", []):
                field_value = point.get("what" if suggest_type == "what" else "query", "")
                if field_value and keywords in field_value.lower():
                    suggestions.add(field_value.strip())

    return jsonify(sorted(suggestions))

@app.route("/case/new", methods=["GET", "POST"])
def new_case():
    from flask import request

    if request.method == "POST":
        case_id = request.form.get("case_id", "").strip()

        if not case_id:
            flash("Case ID cannot be empty.", "error")
            return redirect(url_for("new_case"))

        case_folder = get_safe_case_path(case_id)

        # Check if case folder already exists
        if os.path.exists(case_folder):
            flash(f"Case '{case_id}' already exists!", "error")
            return redirect(url_for("new_case"))

        try:
            os.makedirs(case_folder)
            # Initialize empty huntcards.json
            with open(os.path.join(case_folder, "huntcards.json"), "w") as f:
                f.write("[]")
            
            # Enable evidence management by default
            evidence_config_file = os.path.join(case_folder, "evidence_config.json")
            config = {
                "enabled": True,
                "created": datetime.now().isoformat(),
                "folder_structure": "huntcard_evidence/point_"
            }
            with open(evidence_config_file, "w") as f:
                json.dump(config, f, indent=2)
            
            # Create evidence folder structure
            evidence_root = os.path.join(case_folder, "evidence")
            if not os.path.exists(evidence_root):
                os.makedirs(evidence_root)
            
            # Create evidence mapping file
            evidence_mapping_file = os.path.join(case_folder, "evidence_mapping.json")
            with open(evidence_mapping_file, "w") as f:
                json.dump({}, f, indent=2)
            
            flash(f"Case '{case_id}' created successfully!", "success")
            return redirect(url_for("home"))
        except Exception as e:
            flash(f"Error creating case: {e}", "error")
            return redirect(url_for("new_case"))

    return render_template("new_case.html")

@app.route("/case/<case_id>/tree")
def tree_view(case_id):
    case_folder = get_safe_case_path(case_id)
    huntcards_file = os.path.join(case_folder, "huntcards.json")

    if not os.path.exists(case_folder):
        flash(f"Case '{case_id}' does not exist.", "error")
        return redirect(url_for("home"))

    huntcards = []
    if os.path.exists(huntcards_file):
        with open(huntcards_file, "r") as f:
            try:
                huntcards = json.load(f)
            except json.JSONDecodeError:
                flash(f"Failed to read huntcards.json for case '{case_id}'.", "error")
                return redirect(url_for("case_view", case_id=case_id))

    # Build mind map data structure
    mind_map_data = {
        "nodes": [],
        "links": []
    }
    
    node_ids = set()
    node_counter = 0
    
    # Add case node as root
    case_node_id = f"case_{case_id}"
    mind_map_data["nodes"].append({
        "id": case_node_id,
        "label": case_id,
        "type": "case",
        "level": 0
    })
    node_ids.add(case_node_id)
    
    for idx, card in enumerate(huntcards):
        # Extract data from hunt card
        threat_actor = card.get("threat_actor", "Unknown")
        platform = card.get("platform", "Unknown")
        tactic = ""
        technique = ""
        title = card.get("title", "Untitled")
        
        # Parse tactics_techniques
        tactics_techniques = card.get("tactics_techniques", {})
        if isinstance(tactics_techniques, dict) and tactics_techniques.get("tactic"):
            tactic = tactics_techniques["tactic"]
            if tactics_techniques.get("techniques") and tactics_techniques["techniques"]:
                technique = tactics_techniques["techniques"][0].get("name", "")
        elif isinstance(tactics_techniques, list) and tactics_techniques:
            if isinstance(tactics_techniques[0], dict) and tactics_techniques[0].get("tactic"):
                tactic = tactics_techniques[0]["tactic"]
                if tactics_techniques[0].get("techniques") and tactics_techniques[0]["techniques"]:
                    technique = tactics_techniques[0]["techniques"][0].get("name", "")
        elif isinstance(tactics_techniques, str):
            tactic = tactics_techniques
        
        # Create node IDs
        threat_actor_id = f"threat_actor_{threat_actor.replace(' ', '_')}"
        platform_id = f"platform_{platform.replace(' ', '_')}"
        tactic_id = f"tactic_{tactic.replace(' ', '_')}"
        technique_id = f"technique_{technique.replace(' ', '_')}"
        huntcard_id = f"huntcard_{idx}"
        
        # Add threat actor node
        if threat_actor_id not in node_ids:
            mind_map_data["nodes"].append({
                "id": threat_actor_id,
                "label": threat_actor,
                "type": "threat_actor",
                "level": 1
            })
            node_ids.add(threat_actor_id)
            mind_map_data["links"].append({
                "source": case_node_id,
                "target": threat_actor_id,
                "type": "case_to_threat"
            })
        
        # Add platform node
        if platform_id not in node_ids:
            mind_map_data["nodes"].append({
                "id": platform_id,
                "label": platform,
                "type": "platform",
                "level": 2
            })
            node_ids.add(platform_id)
            mind_map_data["links"].append({
                "source": threat_actor_id,
                "target": platform_id,
                "type": "threat_to_platform"
            })
        
        # Add tactic node
        if tactic and tactic_id not in node_ids:
            mind_map_data["nodes"].append({
                "id": tactic_id,
                "label": tactic,
                "type": "tactic",
                "level": 3
            })
            node_ids.add(tactic_id)
            mind_map_data["links"].append({
                "source": platform_id,
                "target": tactic_id,
                "type": "platform_to_tactic"
            })
        
        # Add technique node
        if technique and technique_id not in node_ids:
            mind_map_data["nodes"].append({
                "id": technique_id,
                "label": technique,
                "type": "technique",
                "level": 4
            })
            node_ids.add(technique_id)
            if tactic:
                mind_map_data["links"].append({
                    "source": tactic_id,
                    "target": technique_id,
                    "type": "tactic_to_technique"
                })
            else:
                mind_map_data["links"].append({
                    "source": platform_id,
                    "target": technique_id,
                    "type": "platform_to_technique"
                })
        
        # Add hunt card node
        mind_map_data["nodes"].append({
            "id": huntcard_id,
            "label": title,
            "type": "huntcard",
            "level": 5,
            "huntcard_idx": idx,
            "case_id": case_id
        })
        
        # Connect hunt card to appropriate parent
        if technique:
            mind_map_data["links"].append({
                "source": technique_id,
                "target": huntcard_id,
                "type": "technique_to_huntcard"
            })
        elif tactic:
            mind_map_data["links"].append({
                "source": tactic_id,
                "target": huntcard_id,
                "type": "tactic_to_huntcard"
            })
        else:
            mind_map_data["links"].append({
                "source": platform_id,
                "target": huntcard_id,
                "type": "platform_to_huntcard"
            })

    return render_template("tree_view.html", 
                         case_id=case_id, 
                         mind_map_data=mind_map_data)

@app.route("/case/<case_id>/analyze")
def analyze_case(case_id):
    case_folder = get_safe_case_path(case_id)
    huntcards_file = os.path.join(case_folder, "huntcards.json")

    if not os.path.exists(case_folder):
        flash(f"Case '{case_id}' does not exist.", "error")
        return redirect(url_for("home"))

    huntcards = []
    analyzed_count = 0  # Track how many huntcards have analysis files

    if os.path.exists(huntcards_file):
        with open(huntcards_file, "r") as f:
            try:
                huntcards = json.load(f)
            except json.JSONDecodeError:
                flash(f"Failed to read huntcards.json for case '{case_id}'.", "error")
                return redirect(url_for("case_view", case_id=case_id))

    # Build list with analysis status
    huntcards_with_status = []
    for idx, card in enumerate(huntcards):
        analysis_file = os.path.join(case_folder, f"analysis_{idx}.json")
        is_analyzed = os.path.exists(analysis_file)
        is_confirmed = False
        status = "Pending"

        if is_analyzed:
            analyzed_count += 1
            with open(analysis_file, "r") as f:
                try:
                    analysis_data = json.load(f)
                    # Check for new status structure
                    status = analysis_data.get("status", "Pending")
                    is_confirmed = (status == "Completed" or analysis_data.get("completed", False))
                except json.JSONDecodeError:
                    pass

        # Extract filtering data
        tactic = ""
        technique = ""
        platform = card.get("platform", "")
        threat_actor = card.get("threat_actor", "")
        
        # Parse tactics_techniques
        tactics_techniques = card.get("tactics_techniques", {})
        if isinstance(tactics_techniques, dict) and tactics_techniques.get("tactic"):
            tactic = tactics_techniques["tactic"]
            if tactics_techniques.get("techniques") and tactics_techniques["techniques"]:
                technique = tactics_techniques["techniques"][0].get("name", "")
        elif isinstance(tactics_techniques, list) and tactics_techniques:
            if isinstance(tactics_techniques[0], dict) and tactics_techniques[0].get("tactic"):
                tactic = tactics_techniques[0]["tactic"]
                if tactics_techniques[0].get("techniques") and tactics_techniques[0]["techniques"]:
                    technique = tactics_techniques[0]["techniques"][0].get("name", "")
        elif isinstance(tactics_techniques, str):
            tactic = tactics_techniques

        huntcards_with_status.append({
            "index": idx,
            "title": card.get("title", "Untitled"),
            "is_analyzed": is_analyzed,
            "is_confirmed": is_confirmed,
            "status": status,
            "tactic": tactic,
            "technique": technique,
            "platform": platform,
            "threat_actor": threat_actor,
            "description": card.get("description", ""),
            "updated": card.get("updated", "")
        })

    # Read filter from query string (?filter=confirmed)
    filter_value = request.args.get("filter", "all")
    filter_specific_value = request.args.get("value", "")

    # Apply filter to huntcards list
    filtered_huntcards = []
    filtered_analyzed_count = 0
    filtered_confirmed_count = 0
    
    for card in huntcards_with_status:
        # Apply status filter
        if filter_value == "confirmed" and not card["is_confirmed"]:
            continue
        if filter_value == "draft" and (not card["is_analyzed"] or card["is_confirmed"]):
            continue
        if filter_value == "pending" and card["is_analyzed"]:
            continue
            
        # Apply criteria filter (tactics, threat actor, platform)
        if filter_value == "tactics":
            if not card["tactic"]:
                continue
            if filter_specific_value:
                # Handle comma-separated tactics
                card_tactics = [t.strip() for t in card["tactic"].split(",") if t.strip()]
                filter_tactics = [t.strip() for t in filter_specific_value.split(",") if t.strip()]
                if not any(tactic in filter_tactics for tactic in card_tactics):
                    continue
        if filter_value == "threat_actor":
            if not card["threat_actor"]:
                continue
            if filter_specific_value:
                # Handle comma-separated threat actors
                card_threat_actors = [ta.strip() for ta in card["threat_actor"].split(",") if ta.strip()]
                filter_threat_actors = [ta.strip() for ta in filter_specific_value.split(",") if ta.strip()]
                if not any(threat_actor in filter_threat_actors for threat_actor in card_threat_actors):
                    continue
        if filter_value == "platform":
            if not card["platform"]:
                continue
            if filter_specific_value:
                # Handle comma-separated platforms
                card_platforms = [p.strip() for p in card["platform"].split(",") if p.strip()]
                filter_platforms = [p.strip() for p in filter_specific_value.split(",") if p.strip()]
                if not any(platform in filter_platforms for platform in card_platforms):
                    continue
            
        filtered_huntcards.append(card)
        
        # Count analyzed and confirmed cards in filtered results
        if card["is_analyzed"]:
            filtered_analyzed_count += 1
        if card["status"] == "Completed":
            filtered_confirmed_count += 1

    # Calculate progress based on filtered results
    total_filtered = len(filtered_huntcards)
    progress_percent = (filtered_confirmed_count / total_filtered * 100) if total_filtered > 0 else 0

    # Get filter criteria name for display
    filter_criteria = "All Hunt Cards"
    if filter_value == "tactics":
        if filter_specific_value:
            # Format comma-separated values nicely
            tactics_list = [t.strip() for t in filter_specific_value.split(",") if t.strip()]
            if len(tactics_list) == 1:
                filter_criteria = tactics_list[0]
            else:
                filter_criteria = f"Multiple Tactics ({', '.join(tactics_list)})"
        else:
            # Get the most common tactic in filtered results
            all_card_tactics = []
            for card in filtered_huntcards:
                if card["tactic"]:
                    tactics = [t.strip() for t in card["tactic"].split(",") if t.strip()]
                    all_card_tactics.extend(tactics)
            if all_card_tactics:
                filter_criteria = max(set(all_card_tactics), key=all_card_tactics.count)
    elif filter_value == "threat_actor":
        if filter_specific_value:
            # Format comma-separated values nicely
            threat_actors_list = [ta.strip() for ta in filter_specific_value.split(",") if ta.strip()]
            if len(threat_actors_list) == 1:
                filter_criteria = threat_actors_list[0]
            else:
                filter_criteria = f"Multiple Threat Actors ({', '.join(threat_actors_list)})"
        else:
            # Get the most common threat actor in filtered results
            all_card_threat_actors = []
            for card in filtered_huntcards:
                if card["threat_actor"]:
                    threat_actors = [ta.strip() for ta in card["threat_actor"].split(",") if ta.strip()]
                    all_card_threat_actors.extend(threat_actors)
            if all_card_threat_actors:
                filter_criteria = max(set(all_card_threat_actors), key=all_card_threat_actors.count)
    elif filter_value == "platform":
        if filter_specific_value:
            # Format comma-separated values nicely
            platforms_list = [p.strip() for p in filter_specific_value.split(",") if p.strip()]
            if len(platforms_list) == 1:
                filter_criteria = platforms_list[0]
            else:
                filter_criteria = f"Multiple Platforms ({', '.join(platforms_list)})"
        else:
            # Get the most common platform in filtered results
            all_card_platforms = []
            for card in filtered_huntcards:
                if card["platform"]:
                    platforms = [p.strip() for p in card["platform"].split(",") if p.strip()]
                    all_card_platforms.extend(platforms)
            if all_card_platforms:
                filter_criteria = max(set(all_card_platforms), key=all_card_platforms.count)

    # Get all unique values for dropdown menus
    all_tactics = set()
    all_threat_actors = set()
    all_platforms = set()
    
    for card in huntcards_with_status:
        # Extract individual tactics from comma-separated values
        if card["tactic"]:
            tactics = [t.strip() for t in card["tactic"].split(",") if t.strip()]
            all_tactics.update(tactics)
        
        # Extract individual threat actors from comma-separated values
        if card["threat_actor"]:
            threat_actors = [ta.strip() for ta in card["threat_actor"].split(",") if ta.strip()]
            all_threat_actors.update(threat_actors)
        
        # Extract individual platforms from comma-separated values
        if card["platform"]:
            platforms = [p.strip() for p in card["platform"].split(",") if p.strip()]
            all_platforms.update(platforms)
    
    # Convert to sorted lists
    all_tactics = sorted(list(all_tactics))
    all_threat_actors = sorted(list(all_threat_actors))
    all_platforms = sorted(list(all_platforms))

    return render_template("analyze.html",
                           case_id=case_id,
                           huntcards=filtered_huntcards,
                           analyzed_count=filtered_analyzed_count,
                           confirmed_count=filtered_confirmed_count,
                           total=total_filtered,
                           progress_percent=progress_percent,
                           active_filter=filter_value,
                           filter_criteria=filter_criteria,
                           all_tactics=all_tactics,
                           all_threat_actors=all_threat_actors,
                           all_platforms=all_platforms)

@app.route("/case/<case_id>/huntcard/new", methods=["GET", "POST"])
def new_huntcard(case_id):
    from flask import request

    case_folder = get_safe_case_path(case_id)
    huntcards_file = os.path.join(case_folder, "huntcards.json")
    platforms_file = os.path.join(case_folder, "platforms.json")

    if not os.path.exists(case_folder):
        flash(f"Case '{case_id}' does not exist.", "error")
        return redirect(url_for("home"))

    # Load or initialize platform list
    default_platforms = ["Windows", "Linux", "macOS"]
    if os.path.exists(platforms_file):
        with open(platforms_file, "r") as f:
            platforms = json.load(f)
    else:
        platforms = default_platforms

    if request.method == "POST":
        title = request.form.get("title", "").strip()
        description = request.form.get("description", "").strip()
        tactics_techniques_raw = request.form.get("tactics_techniques", "").strip()
        threat_actor = request.form.get("threat_actor", "").strip()

        if not title or not tactics_techniques_raw:
            flash("Title and Tactics/Techniques are required.", "error")
            return redirect(url_for("new_huntcard", case_id=case_id))

        # Parse tactics & techniques JSON (from hidden input)
        try:
            tactics_techniques = json.loads(tactics_techniques_raw)
        except json.JSONDecodeError:
            flash("Invalid tactics/techniques data.", "error")
            return redirect(url_for("new_huntcard", case_id=case_id))

        # Handle platform selection
        platform = request.form.get("platform", "").strip()
        if platform == "Other":
            custom_platform = request.form.get("custom_platform", "").strip()
            platform = custom_platform
            if custom_platform and custom_platform not in platforms:
                platforms.append(custom_platform)
                with open(platforms_file, "w") as f:
                    json.dump(platforms, f, indent=2)

        # Parse investigation points
        investigation_points = []
        for key in request.form.keys():
            if key.startswith("point_what_"):
                index = key.split("_")[-1]
                what = request.form.get(f"point_what_{index}", "").strip()
                query = request.form.get(f"point_query_{index}", "").strip()
                if what or query:
                    investigation_points.append({
                        "what": what,
                        "query": query
                    })

        # Add created & updated timestamps
        from datetime import datetime
        now = datetime.utcnow().isoformat()

        new_card = {
            "title": title,
            "description": description,
            "tactics_techniques": tactics_techniques,
            "threat_actor": threat_actor,
            "platform": platform,
            "investigation_points": investigation_points,
            "created": now,
            "updated": now
        }

        # Load existing huntcards
        huntcards = []
        if os.path.exists(huntcards_file):
            with open(huntcards_file, "r") as f:
                try:
                    huntcards = json.load(f)
                except json.JSONDecodeError:
                    flash("Corrupted huntcards.json; starting fresh.", "error")

        # Append new huntcard
        huntcards.append(new_card)

        # Save updated huntcards
        with open(huntcards_file, "w") as f:
            json.dump(huntcards, f, indent=2)

        flash(f"Hunt Card '{title}' created successfully!", "success")
        return redirect(url_for("case_view", case_id=case_id))

    return render_template("huntcard_form.html",
                           case_id=case_id,
                           huntcard=None,
                           edit_mode=False,
                           platforms=platforms)

@app.route("/case/<case_id>/analyze/<int:huntcard_idx>", methods=["GET", "POST"])
def analyze_huntcard(case_id, huntcard_idx):
    case_folder = get_safe_case_path(case_id)
    huntcards_file = os.path.join(case_folder, "huntcards.json")
    analysis_file = os.path.join(case_folder, f"analysis_{huntcard_idx}.json")
    platforms_file = os.path.join(case_folder, "platforms.json")

    if not os.path.exists(huntcards_file):
        flash(f"Case '{case_id}' does not exist or has no Hunt Cards.", "error")
        return redirect(url_for("analyze_case", case_id=case_id))

    # Load or initialize platform list
    default_platforms = ["Windows", "Linux", "macOS"]
    if os.path.exists(platforms_file):
        with open(platforms_file, "r") as f:
            platforms = json.load(f)
    else:
        platforms = default_platforms

    # Load huntcards list
    with open(huntcards_file, "r") as f:
        try:
            huntcards = json.load(f)
        except json.JSONDecodeError:
            flash("Corrupted huntcards.json.", "error")
            return redirect(url_for("analyze_case", case_id=case_id))

    if huntcard_idx < 0 or huntcard_idx >= len(huntcards):
        flash("Invalid Hunt Card index.", "error")
        return redirect(url_for("analyze_case", case_id=case_id))

    huntcard = huntcards[huntcard_idx]

    if request.method == "POST":
        # Get status from completion checkbox
        status = request.form.get("status", "Pending")
        analysis_summary = request.form.get("analysis_summary", "").strip()
        
        # Get title and threat actor from form
        title = request.form.get("title", "").strip()
        threat_actor = request.form.get("threat_actor", "").strip()
        
        # Get platform from form
        platform = request.form.get("platform", "").strip()
        if platform == "Other":
            custom_platform = request.form.get("custom_platform", "").strip()
            platform = custom_platform
            if custom_platform and custom_platform not in platforms:
                platforms.append(custom_platform)
                with open(platforms_file, "w") as f:
                    json.dump(platforms, f, indent=2)
        
        # Update huntcard with new title, threat actor, and platform
        if title:
            huntcard["title"] = title
        if threat_actor is not None:  # Allow empty string to clear threat actor
            huntcard["threat_actor"] = threat_actor
        if platform is not None:  # Allow empty string to clear platform
            huntcard["platform"] = platform
        
        # Validate that completed status requires a proper summary
        if status == "Completed":
            # Check if summary has at least one word
            summary_words = [word for word in analysis_summary.split() if word.strip()]
            if len(summary_words) == 0:
                flash("Cannot save as 'Completed' - Analysis Summary must contain at least one word.", "error")
                return redirect(url_for("analyze_huntcard", case_id=case_id, huntcard_idx=huntcard_idx))
        
        # Debug: Print all form keys to see what's being submitted
        print("=== FORM DEBUG ===")
        print("All form keys:", list(request.form.keys()))
        print("Form data:", dict(request.form))
        print(f"Status: {status}")
        print(f"Summary length: {len(analysis_summary)}")
        
        # Process all investigation points from form data
        updated_points = []
        
        # Get the number of existing investigation points from the huntcard
        existing_points_count = len(huntcard.get("investigation_points", []))
        print(f"Existing points count: {existing_points_count}")
        
        # Process all existing points (0 to existing_points_count - 1)
        for point_index in range(existing_points_count):
            what_key = f"point_what_{point_index}"
            query_key = f"point_query_{point_index}"
            notes_key = f"notes_{point_index}"
            
            what = request.form.get(what_key, "").strip()
            query = request.form.get(query_key, "").strip()
            notes = request.form.get(notes_key, "").strip()
            
            print(f"Point {point_index}:")
            print(f"  - Looking for keys: {what_key}, {query_key}, {notes_key}")
            print(f"  - Found values: what='{what}', query='{query}', notes='{notes}'")
            
            # Always add the point (even if empty) to preserve the structure
            updated_points.append({
                "what": what,
                "query": query,
                "notes": notes
            })

        print(f"Total points to save: {len(updated_points)}")
        print("=== END DEBUG ===")

        # Save tactics & techniques if present
        tactics_techniques_raw = request.form.get("tactics_techniques", None)
        if tactics_techniques_raw is not None:
            try:
                def merge_tactics(existing, incoming):
                    # Build a map of tactic name to set of (id, name) for techniques
                    tactic_map = {t['tactic']: set((tech['id'], tech['name']) for tech in t.get('techniques', [])) for t in existing if 'tactic' in t}
                    for t in incoming:
                        t_name = t.get('tactic')
                        t_techs = set((tech['id'], tech['name']) for tech in t.get('techniques', []))
                        if t_name in tactic_map:
                            tactic_map[t_name].update(t_techs)
                        else:
                            tactic_map[t_name] = t_techs
                    # Convert back to list of dicts
                    merged = []
                    for t_name, techs in tactic_map.items():
                        merged.append({
                            'tactic': t_name,
                            'techniques': [{'id': tid, 'name': tname} for tid, tname in techs]
                        })
                    return merged

                tactics_techniques = json.loads(tactics_techniques_raw)
                existing = huntcard.get("tactics_techniques", [])
                if not isinstance(existing, list):
                    existing = []
                huntcard["tactics_techniques"] = merge_tactics(existing, tactics_techniques)
                # Save updated huntcards
                with open(huntcards_file, "w") as f:
                    json.dump(huntcards, f, indent=2)
            except Exception as e:
                flash(f"Error saving tactics & techniques: {str(e)}", "error")

        # Handle import warnings
        import_warnings_raw = request.form.get("import_warnings", "").strip()
        if import_warnings_raw:
            # Split by newlines and filter out empty lines
            import_warnings = [line.strip() for line in import_warnings_raw.split('\n') if line.strip()]
            huntcard["import_warnings"] = import_warnings
        else:
            # Remove import_warnings field if cleared
            huntcard.pop("import_warnings", None)
        
        # Save updated huntcard
        with open(huntcards_file, "w") as f:
            json.dump(huntcards, f, indent=2)

        # Save updated analysis data
        analysis_data = {
            "hunt_card_title": huntcard["title"],
            "investigation_points": updated_points,
            "summary": analysis_summary,
            "status": status,
            "updated_at": datetime.utcnow().isoformat()
        }

        with open(analysis_file, "w") as f:
            json.dump(analysis_data, f, indent=2)

        flash("Analysis saved successfully!", "success")
        # return redirect(url_for("analyze_case", case_id=case_id))

    # Load existing analysis data if present
    analysis_data = None
    if os.path.exists(analysis_file):
        with open(analysis_file, "r") as f:
            try:
                analysis_data = json.load(f)
            except json.JSONDecodeError:
                pass

    return render_template("analyze_huntcard.html",
                           case_id=case_id,
                           huntcard=huntcard,
                           huntcard_idx=huntcard_idx,
                           analysis=analysis_data,
                           platforms=platforms)

@app.route("/case/<case_id>/huntcard/<int:huntcard_idx>/edit", methods=["GET", "POST"])
def edit_huntcard(case_id, huntcard_idx):
    from flask import request

    case_folder = get_safe_case_path(case_id)
    huntcards_file = os.path.join(case_folder, "huntcards.json")
    platforms_file = os.path.join(case_folder, "platforms.json")

    if not os.path.exists(case_folder):
        flash(f"Case '{case_id}' does not exist.", "error")
        return redirect(url_for("home"))

    # Load or initialize platform list
    default_platforms = ["Windows", "Linux", "macOS"]
    if os.path.exists(platforms_file):
        with open(platforms_file, "r") as f:
            platforms = json.load(f)
    else:
        platforms = default_platforms

    # Load existing huntcards
    huntcards = []
    if os.path.exists(huntcards_file):
        with open(huntcards_file, "r") as f:
            try:
                huntcards = json.load(f)
            except json.JSONDecodeError:
                flash("Corrupted huntcards.json; cannot edit.", "error")
                return redirect(url_for("case_view", case_id=case_id))

    if huntcard_idx < 0 or huntcard_idx >= len(huntcards):
        flash("Invalid Hunt Card index.", "error")
        return redirect(url_for("case_view", case_id=case_id))

    if request.method == "POST":
        title = request.form.get("title", "").strip()
        description = request.form.get("description", "").strip()
        tactics_techniques_raw = request.form.get("tactics_techniques", "").strip()
        threat_actor = request.form.get("threat_actor", "").strip()

        if not title or not tactics_techniques_raw:
            flash("Title and Tactics/Techniques are required.", "error")
            return redirect(url_for("edit_huntcard", case_id=case_id, huntcard_idx=huntcard_idx))

        try:
            tactics_techniques = json.loads(tactics_techniques_raw)
        except json.JSONDecodeError:
            flash("Invalid tactics/techniques data.", "error")
            return redirect(url_for("edit_huntcard", case_id=case_id, huntcard_idx=huntcard_idx))

        # Handle platform selection
        platform = request.form.get("platform", "").strip()
        if platform == "Other":
            custom_platform = request.form.get("custom_platform", "").strip()
            platform = custom_platform
            if custom_platform and custom_platform not in platforms:
                platforms.append(custom_platform)
                with open(platforms_file, "w") as f:
                    json.dump(platforms, f, indent=2)

        # Parse investigation points
        investigation_points = []
        for key in request.form.keys():
            if key.startswith("point_what_"):
                index = key.split("_")[-1]
                what = request.form.get(f"point_what_{index}", "").strip()
                query = request.form.get(f"point_query_{index}", "").strip()
                if what or query:
                    investigation_points.append({
                        "what": what,
                        "query": query
                    })

        # Update huntcard fields
        huntcards[huntcard_idx].update({
            "title": title,
            "description": description,
            "tactics_techniques": tactics_techniques,
            "threat_actor": threat_actor,
            "platform": platform,
            "investigation_points": investigation_points,
            "updated": datetime.utcnow().isoformat()
        })

        # Save import_warnings if present
        import_warnings_raw = request.form.get("import_warnings", None)
        if import_warnings_raw is not None:
            warnings_list = [w.strip() for w in import_warnings_raw.splitlines() if w.strip()]
            if warnings_list:
                huntcards[huntcard_idx]["import_warnings"] = warnings_list
            else:
                huntcards[huntcard_idx].pop("import_warnings", None)
        # Save updated huntcards
        with open(huntcards_file, "w") as f:
            json.dump(huntcards, f, indent=2)

        flash(f"Hunt Card '{title}' updated successfully!", "success")
        return redirect(url_for("case_view", case_id=case_id))

    huntcard = huntcards[huntcard_idx]

    return render_template("huntcard_form.html",
                           case_id=case_id,
                           huntcard=huntcard,
                           edit_mode=True,
                           platforms=platforms)

@app.route("/case/<case_id>/huntcard/<int:huntcard_idx>/delete")
def delete_huntcard(case_id, huntcard_idx):
    case_folder = get_safe_case_path(case_id)
    huntcards_file = os.path.join(case_folder, "huntcards.json")

    if not os.path.exists(case_folder):
        flash(f"Case '{case_id}' does not exist.", "error")
        return redirect(url_for("home"))

    huntcards = []
    if os.path.exists(huntcards_file):
        with open(huntcards_file, "r") as f:
            try:
                huntcards = json.load(f)
            except json.JSONDecodeError:
                flash("Corrupted huntcards.json; cannot delete.", "error")
                return redirect(url_for("case_view", case_id=case_id))

    if huntcard_idx < 0 or huntcard_idx >= len(huntcards):
        flash("Invalid Hunt Card index.", "error")
        return redirect(url_for("case_view", case_id=case_id))

    deleted_card = huntcards.pop(huntcard_idx)
    
    # Save updated huntcards
    with open(huntcards_file, "w") as f:
        json.dump(huntcards, f, indent=2)
    
    # Delete associated analysis file if it exists
    analysis_file = os.path.join(case_folder, f"analysis_{huntcard_idx}.json")
    if os.path.exists(analysis_file):
        try:
            os.remove(analysis_file)
        except Exception:
            pass  # Ignore errors if file can't be deleted
    
    flash(f"Hunt Card '{deleted_card.get('title', 'Untitled')}' deleted successfully!", "success")
    return redirect(url_for("case_view", case_id=case_id))

@app.route("/case/<case_id>/delete_all_huntcards")
def delete_all_huntcards(case_id):
    case_folder = get_safe_case_path(case_id)
    huntcards_file = os.path.join(case_folder, "huntcards.json")

    if not os.path.exists(case_folder):
        flash(f"Case '{case_id}' does not exist.", "error")
        return redirect(url_for("home"))

    if not os.path.exists(huntcards_file):
        flash("No hunt cards found to delete.", "info")
        return redirect(url_for("case_view", case_id=case_id))

    # Load huntcards to get count
    huntcards = []
    try:
        with open(huntcards_file, "r") as f:
            huntcards = json.load(f)
    except json.JSONDecodeError:
        flash("Corrupted huntcards.json; cannot delete.", "error")
        return redirect(url_for("case_view", case_id=case_id))

    if not huntcards:
        flash("No hunt cards found to delete.", "info")
        return redirect(url_for("case_view", case_id=case_id))

    # Delete all hunt cards
    with open(huntcards_file, "w") as f:
        json.dump([], f, indent=2)
    
    # Delete all associated analysis files
    for i in range(len(huntcards)):
        analysis_file = os.path.join(case_folder, f"analysis_{i}.json")
        if os.path.exists(analysis_file):
            try:
                os.remove(analysis_file)
            except Exception:
                pass  # Ignore errors if file can't be deleted
    
    flash(f"💥 Nuclear Clear completed! Deleted {len(huntcards)} hunt cards and all associated analysis files.", "success")
    return redirect(url_for("case_view", case_id=case_id))

@app.route("/case/<case_id>/suggest/<field>")
def suggest_text(case_id, field):
    keywords = request.args.get("keywords", "").strip().lower()
    exclude_idx = request.args.get("exclude_idx", type=int)  # new line

    if not keywords or len(keywords) < 2:
        return jsonify([])  # Return empty for too-short or empty keywords

    try:
        case_folder = get_safe_case_path(case_id)
        huntcards_file = os.path.join(case_folder, "huntcards.json")

        suggestions = set()

        if os.path.exists(huntcards_file):
            with open(huntcards_file, "r") as f:
                try:
                    huntcards = json.load(f)
                except json.JSONDecodeError:
                    huntcards = []

            for idx, card in enumerate(huntcards):
                if exclude_idx is not None and idx == exclude_idx:
                    continue  # Skip the current card being edited

                if field == "title":
                    text = card.get("title", "")
                elif field == "threat_actor":
                    text = card.get("threat_actor", "")
                elif field == "platform":
                    text = card.get("platform", "")
                else:
                    continue

                if text and keywords in text.lower():
                    suggestions.add(text.strip())

        return jsonify(sorted(suggestions))

    except ValueError as e:
        return jsonify({"error": f"Invalid case ID: {str(e)}"}), 400
    except Exception as e:
        return jsonify({"error": "An error occurred"}), 500

@app.route("/suggest/global/<field>")
def suggest_global(field):
    keywords = request.args.get("keywords", "").strip().lower()
    if not keywords or len(keywords) < 2:
        return jsonify([])  # Return empty for too-short or empty keywords

    suggestions = set()
    
    if os.path.exists(app.config['DATA_DIR']):
        for case_folder in os.listdir(app.config['DATA_DIR']):
            try:
                case_path = get_safe_case_path(case_folder)
                if os.path.isdir(case_path):
                    huntcards_file = os.path.join(case_path, "huntcards.json")
                    if os.path.exists(huntcards_file):
                        try:
                            with open(huntcards_file, "r") as f:
                                huntcards = json.load(f)
                                
                            for card in huntcards:
                                if field == "title":
                                    text = card.get("title", "")
                                elif field == "threat_actor":
                                    text = card.get("threat_actor", "")
                                elif field == "platform":
                                    text = card.get("platform", "")
                                else:
                                    continue
                                
                                if text and keywords in text.lower():
                                    suggestions.add(text.strip())
                        except Exception as e:
                            continue  # Skip corrupted files
            except ValueError:
                # Skip invalid case folder names
                continue
    
    return jsonify(list(suggestions))

@app.route("/case/<case_id>/export")
def export_huntcards(case_id):
    case_folder = get_safe_case_path(case_id)
    huntcards_file = os.path.join(case_folder, "huntcards.json")
    
    if not os.path.exists(huntcards_file):
        flash(f"Case '{case_id}' does not exist.", "error")
        return redirect(url_for("case_view", case_id=case_id))
    
    format_type = request.args.get("format", "json").lower()
    
    with open(huntcards_file, "r") as f:
        try:
            huntcards = json.load(f)
        except json.JSONDecodeError:
            flash("Corrupted huntcards.json.", "error")
            return redirect(url_for("case_view", case_id=case_id))
    
    if format_type == "csv":
        # Create CSV export
        output = io.StringIO()
        writer = csv.writer(output)
        
        # Write header
        writer.writerow([
            "title", "description", "threat_actor", "platform", "tactic", "technique_id", "technique_name",
            "investigation_point_1_what", "investigation_point_1_query", "investigation_point_1_notes",
            "investigation_point_2_what", "investigation_point_2_query", "investigation_point_2_notes",
            "investigation_point_3_what", "investigation_point_3_query", "investigation_point_3_notes"
        ])
        
        # Write data
        for card in huntcards:
            # Extract tactics and techniques
            tactic = ""
            technique_id = ""
            technique_name = ""
            
            tactics_techniques = card.get("tactics_techniques", [])
            if isinstance(tactics_techniques, list) and tactics_techniques:
                if isinstance(tactics_techniques[0], dict) and tactics_techniques[0].get("tactic"):
                    tactic = tactics_techniques[0]["tactic"]
                    if tactics_techniques[0].get("techniques") and tactics_techniques[0]["techniques"]:
                        technique_id = tactics_techniques[0]["techniques"][0].get("id", "")
                        technique_name = tactics_techniques[0]["techniques"][0].get("name", "")
            
            # Extract investigation points
            investigation_points = card.get("investigation_points", [])
            point_1_what = investigation_points[0].get("what", "") if len(investigation_points) > 0 else ""
            point_1_query = investigation_points[0].get("query", "") if len(investigation_points) > 0 else ""
            point_1_notes = investigation_points[0].get("notes", "") if len(investigation_points) > 0 else ""
            
            point_2_what = investigation_points[1].get("what", "") if len(investigation_points) > 1 else ""
            point_2_query = investigation_points[1].get("query", "") if len(investigation_points) > 1 else ""
            point_2_notes = investigation_points[1].get("notes", "") if len(investigation_points) > 1 else ""
            
            point_3_what = investigation_points[2].get("what", "") if len(investigation_points) > 2 else ""
            point_3_query = investigation_points[2].get("query", "") if len(investigation_points) > 2 else ""
            point_3_notes = investigation_points[2].get("notes", "") if len(investigation_points) > 2 else ""
            
            writer.writerow([
                card.get("title", ""),
                card.get("description", ""),
                card.get("threat_actor", ""),
                card.get("platform", ""),
                tactic,
                technique_id,
                technique_name,
                point_1_what,
                point_1_query,
                point_1_notes,
                point_2_what,
                point_2_query,
                point_2_notes,
                point_3_what,
                point_3_query,
                point_3_notes
            ])
        
        output.seek(0)
        return send_file(
            io.BytesIO(output.getvalue().encode('utf-8')),
            mimetype='text/csv',
            as_attachment=True,
            download_name=f"huntcards_case_{case_id}.csv"
        )
    
    else:
        # Default JSON export
        export_data = {
            "case_id": case_id,
            "export_date": datetime.utcnow().isoformat(),
            "total_huntcards": len(huntcards),
            "huntcards": huntcards
        }
        
        return send_file(
            io.BytesIO(json.dumps(export_data, indent=2).encode('utf-8')),
            mimetype='application/json',
            as_attachment=True,
            download_name=f"huntcards_case_{case_id}.json"
        )

@app.route("/case/<case_id>/huntcard/<int:huntcard_idx>/add_investigation_point", methods=["POST"])
def add_investigation_point(case_id, huntcard_idx):
    try:
        case_folder = get_safe_case_path(case_id)
        huntcards_file = os.path.join(case_folder, "huntcards.json")
        
        if not os.path.exists(case_folder):
            return jsonify({"error": "Case not found"}), 404
        
        huntcards = []
        if os.path.exists(huntcards_file):
            with open(huntcards_file, "r") as f:
                try:
                    huntcards = json.load(f)
                except json.JSONDecodeError:
                    return jsonify({"error": "Corrupted huntcards file"}), 500
        
        if huntcard_idx >= len(huntcards):
            return jsonify({"error": "Invalid hunt card index"}), 404
        
        huntcard = huntcards[huntcard_idx]
        
        # Validate JSON request
        if not request.is_json:
            return jsonify({"error": "Content-Type must be application/json"}), 400
        
        data = request.get_json()
        if not data:
            return jsonify({"error": "Invalid JSON data"}), 400
        
        # Get the new investigation point data
        what = data.get("what", "").strip()
        query = data.get("query", "").strip()
        
        if not what or not query:
            return jsonify({"error": "What and Query fields are required"}), 400
        
        # Add the new investigation point
        new_point = {
            "what": what,
            "query": query
        }
        
        # Initialize investigation_points if it doesn't exist
        if "investigation_points" not in huntcard:
            huntcard["investigation_points"] = []
        
        huntcard["investigation_points"].append(new_point)
        huntcard["updated"] = datetime.utcnow().isoformat()
        
        # Save the updated huntcard
        with open(huntcards_file, "w") as f:
            json.dump(huntcards, f, indent=2)
        
        return jsonify({
            "success": True,
            "message": "Investigation point added successfully",
            "point_index": len(huntcard["investigation_points"]) - 1,
            "point": new_point
        })
        
    except ValueError as e:
        return jsonify({"error": f"Invalid case ID: {str(e)}"}), 400
    except Exception as e:
        return jsonify({"error": "An error occurred"}), 500

@app.route("/debug/form", methods=["GET", "POST"])
def debug_form():
    if request.method == "POST":
        return jsonify({
            "form_keys": list(request.form.keys()),
            "form_data": dict(request.form)
        })
    return "Debug form endpoint - use POST to test"

@app.route("/case/<case_id>/collapsible_map")
def collapsible_map(case_id):
    case_folder = get_safe_case_path(case_id)
    huntcards_file = os.path.join(case_folder, "huntcards.json")

    if not os.path.exists(case_folder):
        flash(f"Case '{case_id}' does not exist.", "error")
        return redirect(url_for("home"))

    huntcards = []
    if os.path.exists(huntcards_file):
        with open(huntcards_file, "r") as f:
            try:
                huntcards = json.load(f)
            except json.JSONDecodeError:
                flash(f"Failed to read huntcards.json for case '{case_id}'.", "error")
                return redirect(url_for("case_view", case_id=case_id))

    # Build flat graph structure for improved mind map
    mind_map_data = {
        "nodes": [],
        "links": []
    }
    
    node_ids = set()
    node_counter = 0
    
    # Add case node as root
    case_node_id = f"case_{case_id}"
    mind_map_data["nodes"].append({
        "id": case_node_id,
        "label": case_id,
        "type": "case",
        "level": 0
    })
    node_ids.add(case_node_id)
    
    for idx, card in enumerate(huntcards):
        threat_actor = card.get("threat_actor", "").strip() or "Unknown"
        platform = card.get("platform", "").strip() or "Unknown"
        title = card.get("title", "Untitled")
        tactics_techniques = card.get("tactics_techniques", [])
        if isinstance(tactics_techniques, dict):
            tactics_techniques = [tactics_techniques]
        elif not isinstance(tactics_techniques, list):
            tactics_techniques = []
        
        threat_actor_id = f"threat_actor_{threat_actor.replace(' ', '_').replace('/', '_')}"
        platform_id = f"platform_{platform.replace(' ', '_').replace('/', '_')}"
        
        # Add threat actor node
        if threat_actor_id not in node_ids:
            mind_map_data["nodes"].append({
                "id": threat_actor_id,
                "label": threat_actor,
                "type": "threat_actor",
                "level": 1
            })
            node_ids.add(threat_actor_id)
            mind_map_data["links"].append({
                "source": case_node_id,
                "target": threat_actor_id,
                "type": "case_to_threat"
            })
        
        # Add platform node
        if platform_id not in node_ids:
            mind_map_data["nodes"].append({
                "id": platform_id,
                "label": platform,
                "type": "platform",
                "level": 2
            })
            node_ids.add(platform_id)
            mind_map_data["links"].append({
                "source": threat_actor_id,
                "target": platform_id,
                "type": "threat_to_platform"
            })
        
        # Check analysis status for this huntcard
        analysis_file = os.path.join(case_folder, f"analysis_{idx}.json")
        analysis_status = "Pending"  # Default status
        if os.path.exists(analysis_file):
            with open(analysis_file, "r") as f:
                try:
                    analysis_data = json.load(f)
                    analysis_status = analysis_data.get("status", "Pending")
                except json.JSONDecodeError:
                    pass
        
        # Process tactics and techniques
        for tactic_data in tactics_techniques:
            if isinstance(tactic_data, dict):
                tactic = tactic_data.get("tactic", "")
                if tactic:
                    tactic_id = f"tactic_{tactic.replace(' ', '_').replace('/', '_')}"
                    if tactic_id not in node_ids:
                        mind_map_data["nodes"].append({
                            "id": tactic_id,
                            "label": tactic,
                            "type": "tactic",
                            "level": 3
                        })
                        node_ids.add(tactic_id)
                        mind_map_data["links"].append({
                            "source": platform_id,
                            "target": tactic_id,
                            "type": "platform_to_tactic"
                        })
                    
                    # Process techniques
                    techniques = tactic_data.get("techniques", [])
                    for technique_data in techniques:
                        if isinstance(technique_data, dict):
                            technique_id_str = technique_data.get("id", "")
                            technique_name = technique_data.get("name", "")
                            
                            if technique_name:
                                technique_id = f"technique_{technique_id_str}_{technique_name.replace(' ', '_').replace('/', '_')}"
                                
                                # Add technique node
                                if technique_id not in node_ids:
                                    mind_map_data["nodes"].append({
                                        "id": technique_id,
                                        "label": f"{technique_id_str}: {technique_name}",
                                        "type": "technique",
                                        "level": 4
                                    })
                                    node_ids.add(technique_id)
                                    mind_map_data["links"].append({
                                        "source": tactic_id,
                                        "target": technique_id,
                                        "type": "tactic_to_technique"
                                    })
                                
                                # Add hunt card node with analysis status
                                huntcard_id = f"huntcard_{idx}_{technique_id_str}"
                                mind_map_data["nodes"].append({
                                    "id": huntcard_id,
                                    "label": title,
                                    "type": "huntcard",
                                    "level": 5,
                                    "huntcard_idx": idx,
                                    "case_id": case_id,
                                    "threat_actor": threat_actor,
                                    "platform": platform,
                                    "tactic": tactic,
                                    "analysis_status": analysis_status
                                })
                                mind_map_data["links"].append({
                                    "source": technique_id,
                                    "target": huntcard_id,
                                    "type": "technique_to_huntcard"
                                })

    return render_template("collapsible_map.html", case_id=case_id, mind_map_data=mind_map_data)

@app.route('/case/<case_id>/import_huntcards', methods=['POST'])
def import_huntcards(case_id):
    print(f"DEBUG: import_huntcards called for case: {case_id}")
    try:
        case_folder = get_safe_case_path(case_id)
        huntcards_file = os.path.join(case_folder, 'huntcards.json')
        
        if not os.path.exists(case_folder):
            print(f"DEBUG: Case folder does not exist: {case_folder}")
            flash(f"Case '{case_id}' does not exist.", "error")
            return redirect(url_for('home'))
        
        print(f"DEBUG: Files in request: {list(request.files.keys())}")
        if 'csv_file' not in request.files:
            print("DEBUG: No csv_file in request")
            flash('No file uploaded.', 'error')
            return redirect(url_for('case_view', case_id=case_id))
        
        file = request.files['csv_file']
        print(f"DEBUG: Received file: {file.filename}")
        
        # Validate file upload
        try:
            validate_file_upload(file)
        except ValueError as e:
            flash(f'File validation failed: {str(e)}', 'error')
            return redirect(url_for('case_view', case_id=case_id))
        
        # Load MITRE ATT&CK data for validation
        mitre_data = []
        mitre_file = os.path.join(app.static_folder or '', 'data', 'mitre_attack.json')
        if os.path.exists(mitre_file):
            try:
                with open(mitre_file, 'r') as f:
                    mitre_data = json.load(f)
            except Exception:
                pass
        
        # Create validation maps
        valid_tactics = {item['tactic'] for item in mitre_data}
        valid_techniques = {}
        for item in mitre_data:
            for tech in item.get('techniques', []):
                valid_techniques[tech['id']] = tech['name']
        
        try:
            print("DEBUG: Attempting to read file content")
            file.stream.seek(0)
            try:
                file_content = file.read().decode('utf-8')
                print("DEBUG: Successfully decoded file with UTF-8")
            except UnicodeDecodeError as e:
                print(f"DEBUG: UTF-8 decode failed, trying latin-1: {e}")
                file.stream.seek(0)
                file_content = file.read().decode('latin-1')
                print("DEBUG: Successfully decoded file with latin-1")
            file.stream.seek(0)
            
            new_cards = []
            
            # Determine file type based on extension and content
            is_json = (file.filename and file.filename.lower().endswith('.json')) or file_content.strip().startswith('[')
            
            # --- BEGIN: New MITRE ATT&CK mapping for technique-to-tactics ---
            # Build a mapping from technique ID to all tactics it belongs to
            technique_to_tactics = {}
            technique_id_to_name = {}
            for item in mitre_data:
                tactic = item['tactic']
                for tech in item.get('techniques', []):
                    tid = tech['id']
                    technique_id_to_name[tid] = tech['name']
                    if tid not in technique_to_tactics:
                        technique_to_tactics[tid] = set()
                    technique_to_tactics[tid].add(tactic)
            # --- END: New MITRE ATT&CK mapping ---
            
            if is_json:
                # Parse JSON format
                try:
                    json_data = json.loads(file_content)
                    if isinstance(json_data, list):
                        for card_data in json_data:
                            if not card_data.get('title'):
                                continue
                            import_warnings = []
                            # New logic: gather all unique technique IDs from the card
                            imported_techniques = []
                            if 'tactics_techniques' in card_data and isinstance(card_data['tactics_techniques'], list):
                                for tactic_data in card_data['tactics_techniques']:
                                    for tech in tactic_data.get('techniques', []):
                                        if isinstance(tech, dict):
                                            imported_techniques.append(tech)
                            # Build a mapping: tactic -> [techniques] for this card
                            tactic_map = {}
                            for tech in imported_techniques:
                                raw_tid = tech.get('id', '').strip()
                                tech_name = tech.get('name', '').strip()
                                # Normalize to parent (e.g., T1055.001 -> T1055)
                                parent_tid = raw_tid.split('.')[0] if '.' in raw_tid else raw_tid
                                if parent_tid not in technique_to_tactics:
                                    import_warnings.append(f"Invalid technique ID: {raw_tid}")
                                    continue
                                # Use all tactics for the parent technique
                                for tactic in technique_to_tactics[parent_tid]:
                                    if tactic not in tactic_map:
                                        tactic_map[tactic] = []
                                    # Use the imported ID and name
                                    tactic_map[tactic].append({"id": raw_tid, "name": tech_name})
                            # Compose the tactics_techniques structure
                            valid_tactics_techniques = [
                                {"tactic": tactic, "techniques": techs}
                                for tactic, techs in tactic_map.items()
                            ]
                            from datetime import datetime
                            now = datetime.utcnow().isoformat()
                            new_card = {
                                'title': card_data.get('title', '').strip(),
                                'description': card_data.get('description', '').strip(),
                                'threat_actor': card_data.get('threat_actor', '').strip(),
                                'platform': card_data.get('platform', '').strip(),
                                'tactics_techniques': valid_tactics_techniques,
                                'investigation_points': card_data.get('investigation_points', []),
                                'created': card_data.get('created', now),
                                'updated': card_data.get('updated', now)
                            }
                            if import_warnings:
                                new_card['import_warnings'] = import_warnings
                            new_cards.append(new_card)
                    else:
                        flash('JSON file must contain an array of hunt cards.', 'error')
                        return redirect(url_for('case_view', case_id=case_id))
                except json.JSONDecodeError as e:
                    flash(f'Invalid JSON format: {e}', 'error')
                    return redirect(url_for('case_view', case_id=case_id))
            else:
                # Parse CSV format
                print("DEBUG: Parsing as CSV format")
                try:
                    csv_reader = csv.DictReader((line.decode('utf-8') for line in file), skipinitialspace=True)
                    print("DEBUG: Successfully created CSV reader with UTF-8")
                except UnicodeDecodeError as e:
                    print(f"DEBUG: CSV UTF-8 decode failed, trying latin-1: {e}")
                    file.stream.seek(0)
                    csv_reader = csv.DictReader((line.decode('latin-1') for line in file), skipinitialspace=True)
                    print("DEBUG: Successfully created CSV reader with latin-1")
                for row in csv_reader:
                    title = row.get('title', '').strip()
                    description = row.get('description', '').strip()
                    threat_actor = row.get('threat_actor', '').strip()
                    platform = row.get('platform', '').strip()
                    raw_tid = row.get('technique_id', '').strip()
                    tech_name = row.get('technique_name', '').strip()
                    import_warnings = []
                    # Normalize to parent (e.g., T1055.001 -> T1055)
                    parent_tid = raw_tid.split('.')[0] if '.' in raw_tid else raw_tid
                    if parent_tid not in technique_to_tactics:
                        import_warnings.append(f"Invalid technique ID: {raw_tid}")
                        tactics_techniques = []
                    else:
                        tactics_techniques = []
                        for tactic in technique_to_tactics[parent_tid]:
                            tactics_techniques.append({
                                "tactic": tactic,
                                "techniques": [{"id": raw_tid, "name": tech_name}]
                            })
                    # Parse investigation points
                    investigation_points = []
                    for i in range(1, 4):
                        what_key = f'investigation_point_{i}_what'
                        query_key = f'investigation_point_{i}_query'
                        notes_key = f'investigation_point_{i}_notes'
                        what = row.get(what_key, '').strip()
                        query = row.get(query_key, '').strip()
                        notes = row.get(notes_key, '').strip()
                        if what or query or notes:
                            investigation_points.append({
                                "what": what,
                                "query": query,
                                "notes": notes
                            })
                    from datetime import datetime
                    now = datetime.utcnow().isoformat()
                    new_card = {
                        'title': title,
                        'description': description,
                        'threat_actor': threat_actor,
                        'platform': platform,
                        'tactics_techniques': tactics_techniques,
                        'investigation_points': investigation_points,
                        'created': now,
                        'updated': now
                    }
                    if import_warnings:
                        new_card['import_warnings'] = import_warnings
                    new_cards.append(new_card)
            
            # Load existing huntcards
            huntcards = []
            if os.path.exists(huntcards_file):
                with open(huntcards_file, 'r') as f:
                    try:
                        huntcards = json.load(f)
                    except Exception:
                        pass
            
            huntcards.extend(new_cards)
            with open(huntcards_file, 'w') as f:
                json.dump(huntcards, f, indent=2)
            
            file_type = "JSON" if is_json else "CSV"
            flash(f"Imported {len(new_cards)} hunt cards from {file_type} file successfully.", "success")
            
        except Exception as e:
            flash(f"Import failed: {e}", "error")
        
    except ValueError as e:
        flash(f"Invalid case ID: {str(e)}", "error")
        return redirect(url_for('home'))
    except Exception as e:
        flash("An error occurred during import. Please try again.", "error")
    
    return redirect(url_for('case_view', case_id=case_id))

@app.route("/case/<case_id>/suggest_investigation_points", methods=["POST"])
def suggest_investigation_points(case_id):
    """Suggest investigation points based on keywords from existing hunt cards"""
    try:
        case_folder = get_safe_case_path(case_id)
        
        # Validate JSON request
        if not request.is_json:
            return jsonify({"error": "Content-Type must be application/json"}), 400
        
        data = request.get_json()
        if not data:
            return jsonify({"error": "Invalid JSON data"}), 400
        
        keywords = data.get('keywords', '').strip()
        field_type = data.get('field_type', 'what')  # 'what' or 'query'
        
        if not keywords:
            return jsonify({'suggestions': []})
        
        # Get all hunt cards from all cases to search through
        all_suggestions = []
        
        if os.path.exists(app.config['DATA_DIR']):
            for case_folder_name in os.listdir(app.config['DATA_DIR']):
                try:
                    case_path = get_safe_case_path(case_folder_name)
                    if os.path.isdir(case_path):
                        huntcards_file = os.path.join(case_path, "huntcards.json")
                        if os.path.exists(huntcards_file):
                            try:
                                with open(huntcards_file, 'r') as f:
                                    huntcards = json.load(f)
                                    
                                for card in huntcards:
                                    investigation_points = card.get('investigation_points', [])
                                    for point in investigation_points:
                                        if field_type == 'what':
                                            text = point.get('what', '')
                                        else:  # query
                                            text = point.get('query', '')
                                        
                                        if text:
                                            # Calculate similarity score
                                            score = calculate_similarity_score(keywords, text)
                                            if score > 0:  # Only include if there's some similarity
                                                all_suggestions.append({
                                                    'text': text,
                                                    'score': score,
                                                    'case_id': case_folder_name,
                                                    'hunt_card_title': card.get('title', 'Unknown'),
                                                    'full_point': point
                                                })
                            except Exception as e:
                                continue  # Skip corrupted files
                except ValueError:
                    continue  # Skip invalid case folder names
        
        # Sort by score (highest first) and remove duplicates
        all_suggestions.sort(key=lambda x: x['score'], reverse=True)
        
        # Remove duplicates while keeping the highest score
        seen = set()
        unique_suggestions = []
        for suggestion in all_suggestions:
            text_key = suggestion['text'].lower().strip()
            if text_key not in seen:
                seen.add(text_key)
                unique_suggestions.append(suggestion)
        
        # Return top 10 suggestions
        return jsonify({'suggestions': unique_suggestions[:10]})
        
    except ValueError as e:
        return jsonify({"error": f"Invalid case ID: {str(e)}"}), 400
    except Exception as e:
        return jsonify({'error': 'An error occurred'}), 500

def calculate_similarity_score(keywords, text):
    """Calculate similarity score between keywords and text using improved keyword matching"""
    if not keywords or not text:
        return 0
    
    # Convert to lowercase for comparison
    keywords_lower = keywords.lower()
    text_lower = text.lower()
    
    # Split into words
    keyword_words = set(keywords_lower.split())
    text_words = set(text_lower.split())
    
    # Filter out common stop words
    stop_words = {
        'the', 'a', 'an', 'and', 'or', 'but', 'in', 'on', 'at', 'to', 'for', 'of', 'with', 'by',
        'is', 'are', 'was', 'were', 'be', 'been', 'being', 'have', 'has', 'had', 'do', 'does', 'did',
        'will', 'would', 'could', 'should', 'may', 'might', 'can', 'etc', 'etc.', 'and', 'or',
        'this', 'that', 'these', 'those', 'i', 'you', 'he', 'she', 'it', 'we', 'they',
        'me', 'him', 'her', 'us', 'them', 'my', 'your', 'his', 'her', 'its', 'our', 'their'
    }
    
    # Remove stop words from both sets
    keyword_words = keyword_words - stop_words
    text_words = text_words - stop_words
    
    if not keyword_words:
        return 0
    
    # Calculate exact word matches
    exact_matches = len(keyword_words.intersection(text_words))
    
    # Calculate partial matches (substring matching)
    partial_matches = 0
    for keyword in keyword_words:
        if len(keyword) > 2:  # Only consider keywords longer than 2 characters
            if any(keyword in word or word in keyword for word in text_words):
                partial_matches += 0.5  # Give partial credit for substring matches
    
    # Calculate phrase matching (exact phrase in text)
    phrase_bonus = 0
    if keywords_lower in text_lower:
        phrase_bonus = 2  # Bonus for exact phrase match
    
    # Calculate word order similarity
    order_bonus = 0
    keyword_list = [w for w in keywords_lower.split() if w not in stop_words]
    text_list = [w for w in text_lower.split() if w not in stop_words]
    
    if len(keyword_list) > 1 and len(text_list) > 1:
        # Check if keywords appear in similar order
        keyword_positions = []
        text_positions = []
        
        for i, word in enumerate(keyword_list):
            if word in text_list:
                keyword_positions.append(i)
                text_positions.append(text_list.index(word))
        
        if len(keyword_positions) > 1:
            # Calculate order similarity
            order_diff = sum(abs(kp - tp) for kp, tp in zip(keyword_positions, text_positions))
            max_possible_diff = len(keyword_positions) * len(text_list)
            if max_possible_diff > 0:
                order_bonus = 1 - (order_diff / max_possible_diff)
    
    # Calculate final score
    total_score = (exact_matches * 2) + partial_matches + phrase_bonus + order_bonus
    
    # Normalize score (0-10 scale)
    max_possible = len(keyword_words) * 2 + len(keyword_words) * 0.5 + 2 + 1
    normalized_score = min(10, (total_score / max_possible) * 10) if max_possible > 0 else 0
    
    return round(normalized_score, 2)

@app.route("/api/suggestions")
def api_suggestions():
    field_type = request.args.get('field_type', '')
    keywords = request.args.get('keywords', '').strip()
    
    if not keywords or len(keywords) < 2:
        return jsonify({'suggestions': []})
    
    suggestions = []
    
    # Search through all cases for similar content
    if os.path.exists(app.config['DATA_DIR']):
        for case_folder in os.listdir(app.config['DATA_DIR']):
            try:
                case_path = get_safe_case_path(case_folder)
                if os.path.isdir(case_path):
                    huntcards_file = os.path.join(case_path, "huntcards.json")
                    
                    if os.path.exists(huntcards_file):
                        try:
                            with open(huntcards_file, "r") as f:
                                huntcards = json.load(f)
                            
                            for card in huntcards:
                                for point in card.get("investigation_points", []):
                                    if field_type == 'what':
                                        # For "what" suggestions - search in the "what" field
                                        field_value = point.get("what", "")
                                        if field_value and keywords.lower() in field_value.lower():
                                            score = calculate_similarity_score(keywords, field_value)
                                            if score > 3:  # Only include relevant suggestions (score is 0-10)
                                                suggestions.append({
                                                    'text': field_value,
                                                    'score': score,
                                                    'source': f"{card.get('title', 'Untitled')} ({case_folder})"
                                                })
                                    elif field_type == 'query':
                                        # For "query" suggestions - search in the "what" field but return both "what" and "query"
                                        what_value = point.get("what", "")
                                        query_value = point.get("query", "")
                                        if what_value and keywords.lower() in what_value.lower() and query_value:
                                            score = calculate_similarity_score(keywords, what_value)
                                            if score > 3:  # Only include relevant suggestions (score is 0-10)
                                                suggestions.append({
                                                    'what': what_value,
                                                    'query': query_value,
                                                    'score': score,
                                                    'source': f"{card.get('title', 'Untitled')} ({case_folder})"
                                                })
                        except json.JSONDecodeError:
                            continue
            except ValueError:
                # Skip invalid case folder names
                continue
    
    # Sort by score (highest first) and limit to top 10
    suggestions.sort(key=lambda x: x['score'], reverse=True)
    suggestions = suggestions[:10]
    
    return jsonify({'suggestions': suggestions})

# Evidence Management Routes
@app.route("/case/<case_id>/evidence/toggle", methods=["POST"])
def toggle_evidence_management(case_id):
    """Toggle evidence management for a case"""
    try:
        data = request.get_json()
        enabled = data.get('enabled', False)
        
        case_folder = get_safe_case_path(case_id)
        evidence_config_file = os.path.join(case_folder, "evidence_config.json")
        
        config = {
            "enabled": enabled,
            "created": datetime.now().isoformat(),
            "folder_structure": "huntcard_evidence/point_"
        }
        
        with open(evidence_config_file, "w") as f:
            json.dump(config, f, indent=2)
        
        # Create evidence folder structure if enabled
        if enabled:
            evidence_root = os.path.join(case_folder, "evidence")
            if not os.path.exists(evidence_root):
                os.makedirs(evidence_root)
            
            # Create evidence mapping file
            evidence_mapping_file = os.path.join(case_folder, "evidence_mapping.json")
            if not os.path.exists(evidence_mapping_file):
                with open(evidence_mapping_file, "w") as f:
                    json.dump({}, f, indent=2)
        
        return jsonify({"success": True, "enabled": enabled})
    
    except Exception as e:
        return jsonify({"success": False, "error": str(e)})

@app.route("/case/<case_id>/evidence/status")
def get_evidence_status(case_id):
    """Get evidence management status for a case"""
    try:
        case_folder = get_safe_case_path(case_id)
        evidence_config_file = os.path.join(case_folder, "evidence_config.json")
        
        if os.path.exists(evidence_config_file):
            with open(evidence_config_file, "r") as f:
                config = json.load(f)
            return jsonify({"success": True, "enabled": config.get("enabled", False)})
        else:
            return jsonify({"success": True, "enabled": False})
    
    except Exception as e:
        return jsonify({"success": False, "error": str(e)})

@app.route("/case/<case_id>/evidence/open/<int:huntcard_idx>/<int:point_idx>")
def open_evidence_folder(case_id, huntcard_idx, point_idx):
    """Open evidence folder for a specific investigation point"""
    try:
        case_folder = get_safe_case_path(case_id)
        evidence_root = os.path.join(case_folder, "evidence")
        huntcard_folder = os.path.join(evidence_root, f"huntcard_{huntcard_idx:03d}_evidence")
        point_folder = os.path.join(huntcard_folder, f"point_{point_idx:03d}")
        
        # Create folders if they don't exist
        os.makedirs(point_folder, exist_ok=True)
        
        # Verify folder exists
        if not os.path.exists(point_folder):
            return jsonify({"success": False, "error": f"Evidence folder does not exist: {point_folder}"})
        
        # Open folder based on OS
        import platform
        import subprocess
        
        system = platform.system()
        if system == "Windows":
            # Use absolute path and handle errors better
            abs_path = os.path.abspath(point_folder)
            try:
                # On Windows, explorer returns immediately, so we don't need to check return code
                subprocess.Popen(["explorer", abs_path], shell=True)
                return jsonify({"success": True})
            except Exception as e:
                return jsonify({"success": False, "error": f"Failed to open folder: {str(e)}"})
        elif system == "Darwin":  # macOS
            result = subprocess.run(["open", point_folder], capture_output=True, text=True)
            if result.returncode != 0:
                return jsonify({"success": False, "error": f"Failed to open folder: {result.stderr}"})
        else:  # Linux
            result = subprocess.run(["xdg-open", point_folder], capture_output=True, text=True)
            if result.returncode != 0:
                return jsonify({"success": False, "error": f"Failed to open folder: {result.stderr}"})
        
        return jsonify({"success": True})
    
    except Exception as e:
        return jsonify({"success": False, "error": str(e)})

@app.route("/case/<case_id>/evidence/upload/<int:huntcard_idx>/<int:point_idx>", methods=["POST"])
def upload_evidence_files(case_id, huntcard_idx, point_idx):
    """Upload evidence files for a specific investigation point"""
    try:
        case_folder = get_safe_case_path(case_id)
        evidence_root = os.path.join(case_folder, "evidence")
        huntcard_folder = os.path.join(evidence_root, f"huntcard_{huntcard_idx:03d}_evidence")
        point_folder = os.path.join(huntcard_folder, f"point_{point_idx:03d}")
        
        # Create folders if they don't exist
        os.makedirs(point_folder, exist_ok=True)
        
        # Get uploaded files
        files = request.files.getlist('files')
        if not files:
            return jsonify({"success": False, "error": "No files uploaded"})
        
        uploaded_count = 0
        for file in files:
            if file and file.filename:
                # Validate file
                filename = file.filename
                if not filename or '..' in filename or '/' in filename or '\\' in filename:
                    continue
                
                # Check file size (50MB limit per file)
                file.seek(0, 2)
                file_size = file.tell()
                file.seek(0)
                
                if file_size > 50 * 1024 * 1024:  # 50MB
                    continue
                
                # Save file
                file_path = os.path.join(point_folder, filename)
                file.save(file_path)
                uploaded_count += 1
        
        # Update evidence mapping
        update_evidence_mapping(case_id, huntcard_idx, point_idx, uploaded_count)
        
        return jsonify({"success": True, "uploaded": uploaded_count})
    
    except Exception as e:
        return jsonify({"success": False, "error": str(e)})

@app.route("/case/<case_id>/evidence/count/<int:huntcard_idx>/<int:point_idx>")
def get_evidence_file_count(case_id, huntcard_idx, point_idx):
    """Get file count and names for a specific investigation point"""
    try:
        case_folder = get_safe_case_path(case_id)
        evidence_root = os.path.join(case_folder, "evidence")
        huntcard_folder = os.path.join(evidence_root, f"huntcard_{huntcard_idx:03d}_evidence")
        point_folder = os.path.join(huntcard_folder, f"point_{point_idx:03d}")
        
        if os.path.exists(point_folder):
            files = [f for f in os.listdir(point_folder) if os.path.isfile(os.path.join(point_folder, f))]
            count = len(files)
            # Sort files alphabetically
            files.sort()
        else:
            count = 0
            files = []
        
        return jsonify({"success": True, "count": count, "files": files})
    
    except Exception as e:
        return jsonify({"success": False, "error": str(e)})

def update_evidence_mapping(case_id, huntcard_idx, point_idx, file_count):
    """Update evidence mapping file with file count"""
    try:
        case_folder = get_safe_case_path(case_id)
        evidence_mapping_file = os.path.join(case_folder, "evidence_mapping.json")
        
        # Load existing mapping
        if os.path.exists(evidence_mapping_file):
            with open(evidence_mapping_file, "r") as f:
                mapping = json.load(f)
        else:
            mapping = {}
        
        # Update mapping
        huntcard_key = f"huntcard_{huntcard_idx:03d}"
        point_key = f"point_{point_idx:03d}"
        
        if huntcard_key not in mapping:
            mapping[huntcard_key] = {"points": {}}
        
        if point_key not in mapping[huntcard_key]["points"]:
            mapping[huntcard_key]["points"][point_key] = {
                "file_count": 0,
                "created": datetime.now().isoformat()
            }
        
        mapping[huntcard_key]["points"][point_key]["file_count"] = file_count
        mapping[huntcard_key]["points"][point_key]["updated"] = datetime.now().isoformat()
        
        # Save mapping
        with open(evidence_mapping_file, "w") as f:
            json.dump(mapping, f, indent=2)
    
    except Exception as e:
        print(f"Error updating evidence mapping: {e}")

@app.route("/case/<case_id>/export_advanced")
def export_case_advanced(case_id):
    """Advanced export with options for complete or huntcards-only export"""
    export_type = request.args.get("type", "complete")  # complete or huntcards_only
    
    case_folder = get_safe_case_path(case_id)
    if not os.path.exists(case_folder):
        flash(f"Case '{case_id}' does not exist.", "error")
        return redirect(url_for("case_view", case_id=case_id))
    
    try:
        # Create temporary export directory
        import tempfile
        import zipfile
        from datetime import datetime
        
        temp_dir = tempfile.mkdtemp()
        export_dir = os.path.join(temp_dir, f"case_export_{case_id}")
        os.makedirs(export_dir)
        
        # Copy huntcards.json
        huntcards_file = os.path.join(case_folder, "huntcards.json")
        if os.path.exists(huntcards_file):
            shutil.copy2(huntcards_file, export_dir)
        
        # Copy analysis files
        analysis_dir = os.path.join(export_dir, "analysis_files")
        os.makedirs(analysis_dir)
        
        for file in os.listdir(case_folder):
            if file.startswith("analysis_") and file.endswith(".json"):
                shutil.copy2(os.path.join(case_folder, file), analysis_dir)
        
        # Copy evidence files if complete export
        if export_type == "complete":
            evidence_source = os.path.join(case_folder, "evidence")
            if os.path.exists(evidence_source):
                evidence_dest = os.path.join(export_dir, "evidence")
                shutil.copytree(evidence_source, evidence_dest)
            
            # Copy evidence config files
            for config_file in ["evidence_config.json", "evidence_mapping.json"]:
                config_path = os.path.join(case_folder, config_file)
                if os.path.exists(config_path):
                    shutil.copy2(config_path, export_dir)
        
        # Create case info file
        case_info = {
            "case_id": case_id,
            "export_date": datetime.now().isoformat(),
            "export_type": export_type,
            "hcm_version": "1.0.0",
            "source_machine": os.environ.get("COMPUTERNAME", "Unknown")
        }
        
        with open(os.path.join(export_dir, "case_info.json"), "w") as f:
            json.dump(case_info, f, indent=2)
        
        # Create import instructions
        instructions = f"""Hunt Card Manager - Case Import Instructions

Case ID: {case_id}
Export Date: {case_info['export_date']}
Export Type: {export_type}

To import this case:

1. Extract this ZIP file to a temporary location
2. In HCM, go to the home page
3. Click "Import Case" and select the extracted folder
4. Choose import mode:
   - New Case: Creates new case with different ID
   - Overwrite: Replaces existing case completely
   - Merge: Combines hunt cards, preserves existing evidence

Note: {export_type} export {'includes' if export_type == 'complete' else 'excludes'} evidence files.
"""
        
        with open(os.path.join(export_dir, "import_instructions.txt"), "w") as f:
            f.write(instructions)
        
        # Create ZIP file
        timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        zip_filename = f"case_export_{case_id}_{export_type}_{timestamp}.zip"
        zip_path = os.path.join(temp_dir, zip_filename)
        
        with zipfile.ZipFile(zip_path, 'w', zipfile.ZIP_DEFLATED) as zipf:
            for root, dirs, files in os.walk(export_dir):
                for file in files:
                    file_path = os.path.join(root, file)
                    arcname = os.path.relpath(file_path, export_dir)
                    zipf.write(file_path, arcname)
        
        # Send file
        return send_file(
            zip_path,
            as_attachment=True,
            download_name=zip_filename,
            mimetype='application/zip'
        )
        
    except Exception as e:
        flash(f"Export failed: {str(e)}", "error")
        return redirect(url_for("case_view", case_id=case_id))

@app.route("/import_case", methods=["GET", "POST"])
def import_case():
    """Import case from exported ZIP file or individual CSV/JSON files"""
    print("DEBUG: import_case route called")
    if request.method == "GET":
        print("DEBUG: GET request, rendering import template")
        return render_template("import_case.html")
    
    print("DEBUG: POST request received")
    print(f"DEBUG: Files in request: {list(request.files.keys())}")
    
    if "case_zip" not in request.files:
        print("DEBUG: No case_zip file in request")
        flash("No file selected.", "error")
        return redirect(url_for("import_case"))
    
    file = request.files["case_zip"]
    print(f"DEBUG: Received file: {file.filename}")
    if file.filename == "":
        print("DEBUG: Empty filename")
        flash("No file selected.", "error")
        return redirect(url_for("import_case"))
    
    import_mode = request.form.get("import_mode", "new_case")
    new_case_id = request.form.get("new_case_id", "").strip()
    
    print(f"DEBUG: Import mode: {import_mode}")
    print(f"DEBUG: New case ID: {new_case_id}")
    
    try:
        # Determine file type and handle accordingly
        filename = file.filename.lower() if file.filename else ""
        print(f"DEBUG: File extension: {filename}")
        
        if filename.endswith('.zip'):
            print("DEBUG: Detected ZIP file, calling handle_zip_import")
            # Handle ZIP package import
            return handle_zip_import(file, import_mode, new_case_id)
        elif filename.endswith(('.json', '.csv')):
            print("DEBUG: Detected JSON/CSV file, calling handle_file_import")
            # Handle individual file import
            return handle_file_import(file, import_mode, new_case_id)
        else:
            print(f"DEBUG: Unsupported file type: {filename}")
            flash("Unsupported file type. Please select a ZIP, JSON, or CSV file.", "error")
            return redirect(url_for("import_case"))
        
    except Exception as e:
        print(f"DEBUG: Exception in import_case: {str(e)}")
        print(f"DEBUG: Exception type: {type(e)}")
        import traceback
        print(f"DEBUG: Traceback: {traceback.format_exc()}")
        flash(f"Import failed: {str(e)}", "error")
        return redirect(url_for("import_case"))

def handle_zip_import(file, import_mode, new_case_id):
    """Handle import of ZIP package files"""
    import tempfile
    import zipfile
    
    print(f"DEBUG: Starting ZIP import for file: {file.filename}")
    temp_dir = tempfile.mkdtemp()
    zip_path = os.path.join(temp_dir, "import.zip")
    file.save(zip_path)
    print(f"DEBUG: Saved ZIP to: {zip_path}")
    
    try:
        # Extract ZIP
        extract_dir = os.path.join(temp_dir, "extracted")
        os.makedirs(extract_dir)
        
        with zipfile.ZipFile(zip_path, 'r') as zipf:
            print(f"DEBUG: ZIP contains {len(zipf.infolist())} files")
            # Extract files with proper encoding handling
            for file_info in zipf.infolist():
                print(f"DEBUG: Extracting file: {file_info.filename}")
                try:
                    zipf.extract(file_info, extract_dir)
                    print(f"DEBUG: Successfully extracted: {file_info.filename}")
                except Exception as e:
                    # Log the error but continue with other files
                    print(f"Warning: Failed to extract {file_info.filename}: {str(e)}")
                    continue
        
        # Find case_info.json
        case_info_path = os.path.join(extract_dir, "case_info.json")
        print(f"DEBUG: Looking for case_info.json at: {case_info_path}")
        if not os.path.exists(case_info_path):
            print(f"DEBUG: case_info.json not found at: {case_info_path}")
            flash("Invalid export file: missing case_info.json", "error")
            return redirect(url_for("import_case"))
        print(f"DEBUG: Found case_info.json, attempting to load...")
        try:
            case_info = safe_load_json(case_info_path)
            print(f"DEBUG: Successfully loaded case_info.json")
        except Exception as e:
            print(f"DEBUG: Failed to load case_info.json: {str(e)}")
            flash(f"Failed to read case_info.json: {str(e)}", "error")
            return redirect(url_for("import_case"))
        
        original_case_id = case_info["case_id"]
        export_type = case_info.get("export_type", "complete")
        
        # Determine target case ID
        if import_mode == "new_case":
            if not new_case_id:
                flash("New case ID is required for new case import.", "error")
                return redirect(url_for("import_case"))
            target_case_id = new_case_id
        else:
            target_case_id = original_case_id
        
        # Check if case exists
        target_case_folder = get_safe_case_path(target_case_id)
        case_exists = os.path.exists(target_case_folder)
        
        if case_exists and import_mode == "new_case":
            flash(f"Case '{target_case_id}' already exists. Choose a different ID or use overwrite/merge mode.", "error")
            return redirect(url_for("import_case"))
        
        # Perform import based on mode
        if import_mode == "overwrite" or not case_exists:
            # Create new case or overwrite existing
            if case_exists:
                shutil.rmtree(target_case_folder)
            os.makedirs(target_case_folder)
            
            # Copy huntcards.json
            huntcards_source = os.path.join(extract_dir, "huntcards.json")
            print(f"DEBUG: Looking for huntcards.json at: {huntcards_source}")
            if os.path.exists(huntcards_source):
                print(f"DEBUG: Found huntcards.json, copying to: {target_case_folder}")
                shutil.copy2(huntcards_source, target_case_folder)
                print(f"DEBUG: Successfully copied huntcards.json")
            else:
                print(f"DEBUG: huntcards.json not found at: {huntcards_source}")
            
            # Copy analysis files
            analysis_source = os.path.join(extract_dir, "analysis_files")
            print(f"DEBUG: Looking for analysis_files directory at: {analysis_source}")
            if os.path.exists(analysis_source):
                print(f"DEBUG: Found analysis_files directory")
                for file in os.listdir(analysis_source):
                    if file.startswith("analysis_") and file.endswith(".json"):
                        print(f"DEBUG: Copying analysis file: {file}")
                        shutil.copy2(os.path.join(analysis_source, file), target_case_folder)
                        print(f"DEBUG: Successfully copied analysis file: {file}")
            else:
                print(f"DEBUG: analysis_files directory not found at: {analysis_source}")
            
            # Copy evidence files if complete export
            if export_type == "complete":
                print(f"DEBUG: Complete export detected, copying evidence files")
                evidence_source = os.path.join(extract_dir, "evidence")
                print(f"DEBUG: Looking for evidence directory at: {evidence_source}")
                if os.path.exists(evidence_source):
                    print(f"DEBUG: Found evidence directory, copying...")
                    evidence_dest = os.path.join(target_case_folder, "evidence")
                    if os.path.exists(evidence_dest):
                        print(f"DEBUG: Removing existing evidence directory")
                        shutil.rmtree(evidence_dest)
                    shutil.copytree(evidence_source, evidence_dest)
                    print(f"DEBUG: Successfully copied evidence directory")
                else:
                    print(f"DEBUG: Evidence directory not found at: {evidence_source}")
                
                # Copy evidence config files
                for config_file in ["evidence_config.json", "evidence_mapping.json"]:
                    config_source = os.path.join(extract_dir, config_file)
                    print(f"DEBUG: Looking for {config_file} at: {config_source}")
                    if os.path.exists(config_source):
                        print(f"DEBUG: Found {config_file}, copying...")
                        shutil.copy2(config_source, target_case_folder)
                        print(f"DEBUG: Successfully copied {config_file}")
                    else:
                        print(f"DEBUG: {config_file} not found at: {config_source}")
            else:
                print(f"DEBUG: Huntcards-only export, skipping evidence files")
            
            flash(f"Case '{target_case_id}' imported successfully!", "success")
            
        elif import_mode == "merge":
            print(f"DEBUG: Starting merge operation for case: {target_case_id}")
            # Merge hunt cards
            merge_hunt_cards(target_case_id, extract_dir, export_type)
            print(f"DEBUG: Merge operation completed")
            flash(f"Case '{target_case_id}' merged successfully!", "success")
        
        return redirect(url_for("case_view", case_id=target_case_id))
        
    finally:
        # Cleanup
        shutil.rmtree(temp_dir)

def handle_file_import(file, import_mode, new_case_id):
    """Handle import of individual CSV or JSON files"""
    filename = file.filename.lower()
    
    # Determine target case ID
    if import_mode == "new_case":
        if not new_case_id:
            flash("New case ID is required for new case import.", "error")
            return redirect(url_for("import_case"))
        target_case_id = new_case_id
    else:
        # For individual files, we need a case ID
        if not new_case_id:
            flash("Case ID is required for individual file import.", "error")
            return redirect(url_for("import_case"))
        target_case_id = new_case_id
    
    # Check if case exists
    target_case_folder = get_safe_case_path(target_case_id)
    case_exists = os.path.exists(target_case_folder)
    
    if case_exists and import_mode == "new_case":
        flash(f"Case '{target_case_id}' already exists. Choose a different ID or use overwrite/merge mode.", "error")
        return redirect(url_for("import_case"))
    
    try:
        # Create case folder if it doesn't exist
        if not case_exists:
            os.makedirs(target_case_folder)
        
        if filename.endswith('.json'):
            # Import JSON hunt cards
            try:
                # Read the uploaded file content
                file.seek(0)  # Reset file pointer
                content = file.read()
                try:
                    huntcards_data = json.loads(content.decode('utf-8'))
                except UnicodeDecodeError:
                    # Try with different encoding if UTF-8 fails
                    try:
                        huntcards_data = json.loads(content.decode('latin-1'))
                    except Exception as e:
                        flash(f"Failed to read JSON file: {str(e)}", "error")
                        return redirect(url_for("import_case"))
            except Exception as e:
                flash(f"Failed to read JSON file: {str(e)}", "error")
                return redirect(url_for("import_case"))
            
            if import_mode == "overwrite":
                # Overwrite existing hunt cards
                with open(os.path.join(target_case_folder, "huntcards.json"), "w") as f:
                    json.dump(huntcards_data, f, indent=2)
                flash(f"Hunt cards imported to case '{target_case_id}' successfully!", "success")
            elif import_mode == "merge":
                # Merge with existing hunt cards
                existing_huntcards = []
                existing_huntcards_file = os.path.join(target_case_folder, "huntcards.json")
                if os.path.exists(existing_huntcards_file):
                    try:
                        existing_huntcards = safe_load_json(existing_huntcards_file)
                    except Exception as e:
                        print(f"Warning: Failed to load existing huntcards.json: {e}")
                        existing_huntcards = []
                
                # Merge hunt cards
                merged_huntcards = existing_huntcards + huntcards_data
                
                with open(os.path.join(target_case_folder, "huntcards.json"), "w") as f:
                    json.dump(merged_huntcards, f, indent=2)
                flash(f"Hunt cards merged into case '{target_case_id}' successfully!", "success")
            else:
                # New case
                with open(os.path.join(target_case_folder, "huntcards.json"), "w") as f:
                    json.dump(huntcards_data, f, indent=2)
                flash(f"Case '{target_case_id}' created with imported hunt cards!", "success")
        
        elif filename.endswith('.csv'):
            # Import CSV hunt cards
            import csv
            import io
            
            # Read CSV content with encoding handling
            try:
                csv_content = file.read().decode('utf-8')
            except UnicodeDecodeError:
                # Try with different encoding if UTF-8 fails
                file.seek(0)  # Reset file pointer
                try:
                    csv_content = file.read().decode('latin-1')
                except Exception as e:
                    flash(f"Failed to read CSV file: {str(e)}", "error")
                    return redirect(url_for("import_case"))
            
            csv_reader = csv.DictReader(io.StringIO(csv_content))
            
            huntcards_data = []
            for row in csv_reader:
                # Convert CSV row to hunt card format
                hunt_card = {
                    "title": row.get("title", ""),
                    "description": row.get("description", ""),
                    "threat_actor": row.get("threat_actor", ""),
                    "platform": row.get("platform", ""),
                    "tactics_techniques": [],
                    "investigation_points": []
                }
                
                # Parse tactics and techniques
                if row.get("tactic"):
                    hunt_card["tactics_techniques"].append({
                        "tactic": row.get("tactic", ""),
                        "techniques": []
                    })
                    if row.get("technique_id") and row.get("technique_name"):
                        hunt_card["tactics_techniques"][0]["techniques"].append({
                            "id": row.get("technique_id", ""),
                            "name": row.get("technique_name", "")
                        })
                
                # Parse investigation points
                for i in range(1, 4):  # Support up to 3 investigation points
                    what = row.get(f"investigation_point_{i}_what", "")
                    query = row.get(f"investigation_point_{i}_query", "")
                    notes = row.get(f"investigation_point_{i}_notes", "")
                    
                    if what or query or notes:
                        hunt_card["investigation_points"].append({
                            "what": what,
                            "query": query,
                            "notes": notes
                        })
                
                huntcards_data.append(hunt_card)
            
            if import_mode == "overwrite":
                # Overwrite existing hunt cards
                with open(os.path.join(target_case_folder, "huntcards.json"), "w") as f:
                    json.dump(huntcards_data, f, indent=2)
                flash(f"Hunt cards imported to case '{target_case_id}' successfully!", "success")
            elif import_mode == "merge":
                # Merge with existing hunt cards
                existing_huntcards = []
                existing_huntcards_file = os.path.join(target_case_folder, "huntcards.json")
                if os.path.exists(existing_huntcards_file):
                    try:
                        existing_huntcards = safe_load_json(existing_huntcards_file)
                    except Exception as e:
                        print(f"Warning: Failed to load existing huntcards.json: {e}")
                        existing_huntcards = []
                
                # Merge hunt cards
                merged_huntcards = existing_huntcards + huntcards_data
                
                with open(os.path.join(target_case_folder, "huntcards.json"), "w") as f:
                    json.dump(merged_huntcards, f, indent=2)
                flash(f"Hunt cards merged into case '{target_case_id}' successfully!", "success")
            else:
                # New case
                with open(os.path.join(target_case_folder, "huntcards.json"), "w") as f:
                    json.dump(huntcards_data, f, indent=2)
                flash(f"Case '{target_case_id}' created with imported hunt cards!", "success")
        
        return redirect(url_for("case_view", case_id=target_case_id))
        
    except Exception as e:
        flash(f"File import failed: {str(e)}", "error")
        return redirect(url_for("import_case"))

def merge_hunt_cards(target_case_id, extract_dir, export_type):
    """Merge hunt cards with proper investigation point handling"""
    print(f"DEBUG: Starting merge_hunt_cards for case: {target_case_id}")
    target_case_folder = get_safe_case_path(target_case_id)
    print(f"DEBUG: Target case folder: {target_case_folder}")
    
    # Load existing hunt cards
    existing_huntcards = []
    existing_huntcards_file = os.path.join(target_case_folder, "huntcards.json")
    print(f"DEBUG: Looking for existing huntcards.json at: {existing_huntcards_file}")
    if os.path.exists(existing_huntcards_file):
        try:
            existing_huntcards = safe_load_json(existing_huntcards_file)
            print(f"DEBUG: Loaded {len(existing_huntcards)} existing hunt cards")
        except Exception as e:
            print(f"Warning: Failed to load existing huntcards.json: {e}")
            existing_huntcards = []
    else:
        print(f"DEBUG: No existing huntcards.json found")
    
    # Load imported hunt cards
    imported_huntcards = []
    imported_huntcards_file = os.path.join(extract_dir, "huntcards.json")
    print(f"DEBUG: Looking for imported huntcards.json at: {imported_huntcards_file}")
    if os.path.exists(imported_huntcards_file):
        try:
            imported_huntcards = safe_load_json(imported_huntcards_file)
            print(f"DEBUG: Loaded {len(imported_huntcards)} imported hunt cards")
        except Exception as e:
            print(f"Warning: Failed to load imported huntcards.json: {e}")
            imported_huntcards = []
    else:
        print(f"DEBUG: No imported huntcards.json found")
    
    # Merge hunt cards
    merged_huntcards = existing_huntcards.copy()
    
    for imported_card in imported_huntcards:
        # Create unique identifier for hunt card
        card_id = f"{imported_card.get('title', '')}_{imported_card.get('threat_actor', '')}_{imported_card.get('platform', '')}"
        
        # Check if hunt card already exists
        existing_index = None
        for i, existing_card in enumerate(existing_huntcards):
            existing_id = f"{existing_card.get('title', '')}_{existing_card.get('threat_actor', '')}_{existing_card.get('platform', '')}"
            if card_id == existing_id:
                existing_index = i
                break
        
        if existing_index is not None:
            # Merge existing hunt card
            existing_card = existing_huntcards[existing_index]
            merged_card = merge_single_hunt_card(existing_card, imported_card)
            merged_huntcards[existing_index] = merged_card
        else:
            # Add new hunt card
            merged_huntcards.append(imported_card)
    
    # Save merged hunt cards
    with open(os.path.join(target_case_folder, "huntcards.json"), "w") as f:
        json.dump(merged_huntcards, f, indent=2)
    
    # Merge analysis files if they exist
    merge_analysis_files(target_case_folder, extract_dir)
    
    # Merge evidence files if complete export
    if export_type == "complete":
        merge_evidence_files(target_case_folder, extract_dir)

def merge_single_hunt_card(existing_card, imported_card):
    """Merge two hunt cards with proper investigation point handling"""
    merged_card = existing_card.copy()
    
    # Merge basic fields (prefer imported if different)
    for field in ["title", "description", "threat_actor", "platform"]:
        if imported_card.get(field) and imported_card.get(field) != existing_card.get(field):
            merged_card[field] = imported_card[field]
    
    # Merge tactics and techniques
    existing_tactics = existing_card.get("tactics_techniques", [])
    imported_tactics = imported_card.get("tactics_techniques", [])
    merged_card["tactics_techniques"] = merge_tactics_techniques(existing_tactics, imported_tactics)
    
    # Merge investigation points with proper structure
    existing_points = existing_card.get("investigation_points", [])
    imported_points = imported_card.get("investigation_points", [])
    merged_card["investigation_points"] = merge_investigation_points(existing_points, imported_points)
    
    return merged_card

def merge_tactics_techniques(existing_tactics, imported_tactics):
    """Merge tactics and techniques arrays"""
    merged = existing_tactics.copy()
    
    for imported_tactic in imported_tactics:
        # Check if tactic already exists
        tactic_exists = False
        for existing_tactic in merged:
            if existing_tactic.get("tactic") == imported_tactic.get("tactic"):
                # Merge techniques
                existing_techniques = existing_tactic.get("techniques", [])
                imported_techniques = imported_tactic.get("techniques", [])
                
                # Add new techniques that don't exist
                for imported_tech in imported_techniques:
                    tech_exists = any(tech.get("id") == imported_tech.get("id") for tech in existing_techniques)
                    if not tech_exists:
                        existing_techniques.append(imported_tech)
                
                existing_tactic["techniques"] = existing_techniques
                tactic_exists = True
                break
        
        if not tactic_exists:
            merged.append(imported_tactic)
    
    return merged

def merge_investigation_points(existing_points, imported_points):
    """Merge investigation points with proper structure and indentation"""
    merged_points = existing_points.copy()
    
    for imported_point in imported_points:
        # Check if point already exists (by what field)
        point_exists = False
        for existing_point in merged_points:
            if existing_point.get("what") == imported_point.get("what"):
                # Merge the point
                merged_point = merge_single_investigation_point(existing_point, imported_point)
                # Replace existing point
                index = merged_points.index(existing_point)
                merged_points[index] = merged_point
                point_exists = True
                break
        
        if not point_exists:
            # Add new point
            merged_points.append(imported_point)
    
    return merged_points

def merge_single_investigation_point(existing_point, imported_point):
    """Merge two investigation points with proper formatting"""
    merged_point = existing_point.copy()
    
    # Merge what field
    if imported_point.get("what") and imported_point.get("what") != existing_point.get("what"):
        merged_point["what"] = imported_point["what"]
    
    # Merge query field
    if imported_point.get("query") and imported_point.get("query") != existing_point.get("query"):
        merged_point["query"] = imported_point["query"]
    
    # Merge notes with proper formatting
    existing_notes = existing_point.get("notes", "").strip()
    imported_notes = imported_point.get("notes", "").strip()
    
    if existing_notes and imported_notes:
        # Both have notes - combine with separator
        merged_point["notes"] = f"{existing_notes}\n\n---\n\n{imported_notes}"
    elif imported_notes:
        # Only imported has notes
        merged_point["notes"] = imported_notes
    # If only existing has notes, keep it as is
    
    return merged_point

def merge_analysis_files(target_case_folder, extract_dir):
    """Merge analysis files"""
    print(f"DEBUG: Starting merge_analysis_files")
    analysis_source = os.path.join(extract_dir, "analysis_files")
    print(f"DEBUG: Looking for analysis_files at: {analysis_source}")
    if not os.path.exists(analysis_source):
        print(f"DEBUG: analysis_files directory not found, skipping")
        return
    
    for file in os.listdir(analysis_source):
        if file.startswith("analysis_") and file.endswith(".json"):
            print(f"DEBUG: Processing analysis file: {file}")
            source_path = os.path.join(analysis_source, file)
            target_path = os.path.join(target_case_folder, file)
            
            # If target exists, merge the analysis data
            if os.path.exists(target_path):
                print(f"DEBUG: Target analysis file exists, attempting merge: {target_path}")
                try:
                    existing_analysis = safe_load_json(target_path)
                    imported_analysis = safe_load_json(source_path)
                    
                    # Merge analysis data (simple overwrite for now)
                    merged_analysis = {**existing_analysis, **imported_analysis}
                    
                    with open(target_path, "w") as f:
                        json.dump(merged_analysis, f, indent=2)
                except:
                    # If merge fails, overwrite
                    shutil.copy2(source_path, target_path)
            else:
                # Target doesn't exist, copy
                shutil.copy2(source_path, target_path)

def merge_evidence_files(target_case_folder, extract_dir):
    """Merge evidence files"""
    evidence_source = os.path.join(extract_dir, "evidence")
    if not os.path.exists(evidence_source):
        return
    
    evidence_target = os.path.join(target_case_folder, "evidence")
    if not os.path.exists(evidence_target):
        os.makedirs(evidence_target)
    
    # Copy evidence files (simple copy for now)
    for root, dirs, files in os.walk(evidence_source):
        # Create corresponding directory structure
        rel_path = os.path.relpath(root, evidence_source)
        target_dir = os.path.join(evidence_target, rel_path)
        os.makedirs(target_dir, exist_ok=True)
        
        # Copy files
        for file in files:
            source_file = os.path.join(root, file)
            target_file = os.path.join(target_dir, file)
            
            # If file exists, add timestamp to avoid conflicts
            if os.path.exists(target_file):
                name, ext = os.path.splitext(file)
                timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
                target_file = os.path.join(target_dir, f"{name}_{timestamp}{ext}")
            
            shutil.copy2(source_file, target_file)
    
    # Merge evidence config files
    for config_file in ["evidence_config.json", "evidence_mapping.json"]:
        source_config = os.path.join(extract_dir, config_file)
        target_config = os.path.join(target_case_folder, config_file)
        
        if os.path.exists(source_config):
            if os.path.exists(target_config):
                # Merge config files
                try:
                    with open(target_config, "r") as f:
                        existing_config = safe_load_json(target_config)
                    with open(source_config, "r") as f:
                        imported_config = safe_load_json(source_config)
                    
                    # Merge configs (prefer imported for conflicts)
                    merged_config = {**existing_config, **imported_config}
                    
                    with open(target_config, "w") as f:
                        json.dump(merged_config, f, indent=2)
                except:
                    # If merge fails, overwrite
                    shutil.copy2(source_config, target_config)
            else:
                # Target doesn't exist, copy
                shutil.copy2(source_config, target_config)

def safe_load_json(filepath):
    """Safely load a JSON file with encoding fallback and error logging."""
    print(f"DEBUG: Attempting to load JSON file: {filepath}")
    try:
        with open(filepath, 'r', encoding='utf-8') as f:
            result = json.load(f)
            print(f"DEBUG: Successfully loaded {filepath} with UTF-8 encoding")
            return result
    except UnicodeDecodeError as e:
        print(f"DEBUG: UTF-8 decode failed for {filepath}, trying latin-1: {e}")
        try:
            with open(filepath, 'r', encoding='latin-1') as f:
                result = json.load(f)
                print(f"DEBUG: Successfully loaded {filepath} with latin-1 encoding")
                return result
        except Exception as e:
            print(f"DEBUG: Failed to read JSON file {filepath} with latin-1: {e}")
            logging.error(f"Failed to read JSON file {filepath}: {e}")
            raise
    except Exception as e:
        print(f"DEBUG: Failed to read JSON file {filepath}: {e}")
        logging.error(f"Failed to read JSON file {filepath}: {e}")
        raise

@app.route("/case/<case_id>/report")
def report_case(case_id):
    case_folder = get_safe_case_path(case_id)
    huntcards_file = os.path.join(case_folder, "huntcards.json")

    huntcards = []
    if os.path.exists(huntcards_file):
        with open(huntcards_file, "r") as f:
            try:
                huntcards = json.load(f)
            except json.JSONDecodeError:
                flash("Corrupted huntcards.json.", "error")

    # Audit log JSON response
    if request.args.get('audit') == '1' and request.headers.get('X-Requested-With') == 'XMLHttpRequest':
        audit_data = []
        for card in huntcards:
            audit_data.append({
                'title': card.get('title', ''),
                'created': card.get('created', ''),
                'updated': card.get('updated', ''),
                'reported': card.get('reported', False),
                'reported_date': card.get('updated', '') if card.get('reported') else ''
            })
        return jsonify({'huntcards': audit_data})

    # Ensure every card has a 'reported' field (default False)
    for card in huntcards:
        if 'reported' not in card:
            card['reported'] = False

    # Gather all unique tactics, threat actors, and platforms
    all_tactics = set()
    all_threat_actors = set()
    all_platforms = set()
    for card in huntcards:
        # Extract tactic(s)
        tactic = ''
        tactics_techniques = card.get('tactics_techniques', [])
        if isinstance(tactics_techniques, dict) and tactics_techniques.get('tactic'):
            tactic = tactics_techniques['tactic']
        elif isinstance(tactics_techniques, list) and tactics_techniques:
            if isinstance(tactics_techniques[0], dict) and tactics_techniques[0].get('tactic'):
                tactic = tactics_techniques[0]['tactic']
        elif isinstance(tactics_techniques, str):
            tactic = tactics_techniques
        if tactic:
            all_tactics.add(tactic)
        # Threat actor
        threat_actor = card.get('threat_actor', '').strip()
        if threat_actor:
            all_threat_actors.add(threat_actor)
        # Platform
        platform = card.get('platform', '').strip()
        if platform:
            all_platforms.add(platform)

    all_tactics = sorted(list(all_tactics))
    all_threat_actors = sorted(list(all_threat_actors))
    all_platforms = sorted(list(all_platforms))

    # Filtering logic
    filter_type = request.args.get('filter')
    filter_value = request.args.get('value')
    filter_criteria = None
    active_filter = None
    filtered_huntcards = huntcards
    if filter_type and filter_value and filter_type in ['tactics', 'threat_actor', 'platform', 'reporting']:
        active_filter = filter_type
        filter_criteria = filter_value
        if filter_type == 'tactics':
            filtered_huntcards = [card for card in huntcards if (
                (isinstance(card.get('tactics_techniques', []), dict) and card['tactics_techniques'].get('tactic') == filter_value) or
                (isinstance(card.get('tactics_techniques', []), list) and card['tactics_techniques'] and isinstance(card['tactics_techniques'][0], dict) and card['tactics_techniques'][0].get('tactic') == filter_value) or
                (isinstance(card.get('tactics_techniques', ''), str) and card['tactics_techniques'] == filter_value)
            )]
        elif filter_type == 'threat_actor':
            filtered_huntcards = [card for card in huntcards if card.get('threat_actor', '').strip() == filter_value]
        elif filter_type == 'platform':
            filtered_huntcards = [card for card in huntcards if card.get('platform', '').strip() == filter_value]
        elif filter_type == 'reporting':
            if filter_value == 'reported':
                filtered_huntcards = [card for card in huntcards if card.get('reported')]
            elif filter_value == 'not_reported':
                filtered_huntcards = [card for card in huntcards if not card.get('reported')]
    else:
        filter_criteria = 'All'
        active_filter = None

    # Add .index to each card for table and JS
    for idx, card in enumerate(filtered_huntcards):
        card['index'] = idx
        # If not reported, set date to empty string
        if not card.get('reported'):
            card['updated'] = ''

    # Audit CSV download
    if request.args.get('audit_csv') == '1' and request.headers.get('X-Requested-With') == 'XMLHttpRequest':
        import io
        import csv
        from flask import send_file
        output = io.StringIO()
        writer = csv.writer(output)
        writer.writerow(['Title', 'Created', 'Updated', 'Reported', 'Reported Date'])
        for card in huntcards:
            writer.writerow([
                card.get('title', ''),
                card.get('created', ''),
                card.get('updated', ''),
                'Yes' if card.get('reported') else 'No',
                card.get('updated', '') if card.get('reported') else ''
            ])
        output.seek(0)
        return send_file(
            io.BytesIO(output.getvalue().encode('utf-8')),
            mimetype='text/csv',
            as_attachment=True,
            download_name=f"hunt_audits_{case_id}.csv"
        )

    return render_template(
        "report.html",
        case_id=case_id,
        all_tactics=all_tactics,
        all_threat_actors=all_threat_actors,
        all_platforms=all_platforms,
        active_filter=active_filter,
        filter_criteria=filter_criteria,
        huntcards=filtered_huntcards
    )

@app.route("/case/<case_id>/report/toggle_reported_status", methods=["POST"], endpoint="toggle_reported_status")
def toggle_reported_status(case_id):
    case_folder = get_safe_case_path(case_id)
    huntcards_file = os.path.join(case_folder, "huntcards.json")
    try:
        data = request.get_json()
        idx = int(data.get('index'))
        reported = bool(data.get('reported'))
        # Load huntcards
        huntcards = []
        if os.path.exists(huntcards_file):
            with open(huntcards_file, "r") as f:
                huntcards = json.load(f)
        # Update reported status
        if 0 <= idx < len(huntcards):
            huntcards[idx]['reported'] = reported
            with open(huntcards_file, "w") as f:
                json.dump(huntcards, f, indent=2)
            return jsonify(success=True)
        else:
            return jsonify(success=False, error="Invalid index")
    except Exception as e:
        return jsonify(success=False, error=str(e))

@app.route('/case/<case_id>/report/summary_csv', methods=['POST'])
def report_summary_csv(case_id):
    import io
    import csv
    from flask import send_file, request, jsonify
    case_folder = get_safe_case_path(case_id)
    huntcards_file = os.path.join(case_folder, "huntcards.json")
    huntcards = []
    if os.path.exists(huntcards_file):
        with open(huntcards_file, "r") as f:
            try:
                huntcards = json.load(f)
            except json.JSONDecodeError:
                return jsonify({'success': False, 'error': 'Corrupted huntcards.json.'}), 400

    # Get indices from POST (selected cards), else use all
    data = request.get_json() or {}
    indices = data.get('indices')
    if indices is not None:
        selected_cards = [huntcards[i] for i in indices if 0 <= i < len(huntcards)]
    else:
        selected_cards = huntcards

    output = io.StringIO()
    writer = csv.writer(output)
    # Header (match import template, plus notes)
    writer.writerow([
        'Title', 'Threat Actor', 'Platform', 'Tactic', 'Technique ID', 'Technique Name',
        'Investigative Vector', 'Query', 'Notes'
    ])
    for card in selected_cards:
        title = card.get('title', '')
        threat_actor = card.get('threat_actor', '')
        platform = card.get('platform', '')
        # Tactic/Technique
        tactics_techniques = card.get('tactics_techniques', [])
        if isinstance(tactics_techniques, dict):
            tactic = tactics_techniques.get('tactic', '')
            techniques = tactics_techniques.get('techniques', [])
        elif isinstance(tactics_techniques, list) and tactics_techniques:
            tactic = tactics_techniques[0].get('tactic', '')
            techniques = tactics_techniques[0].get('techniques', [])
        else:
            tactic = ''
            techniques = []
        # If no techniques, still write a row
        if not techniques:
            techniques = [{}]
        # Investigation points
        inv_points = card.get('investigation_points', [])
        inv_vector = '\n'.join([p.get('what', '') for p in inv_points if p.get('what')])
        inv_query = '\n'.join([p.get('query', '') for p in inv_points if p.get('query')])
        notes = card.get('description', '')
        for tech in techniques:
            tech_id = tech.get('id', '')
            tech_name = tech.get('name', '')
            writer.writerow([
                title, threat_actor, platform, tactic, tech_id, tech_name, inv_vector, inv_query, notes
            ])
    output.seek(0)
    return send_file(
        io.BytesIO(output.getvalue().encode('utf-8')),
        mimetype='text/csv',
        as_attachment=True,
        download_name=f"summary_report_{case_id}.csv"
    )

@app.route('/case/<case_id>/report/detailed_csv', methods=['POST'])
def report_detailed_csv(case_id):
    import io
    import csv
    from flask import send_file, request, jsonify
    case_folder = get_safe_case_path(case_id)
    huntcards_file = os.path.join(case_folder, "huntcards.json")
    huntcards = []
    if os.path.exists(huntcards_file):
        with open(huntcards_file, "r") as f:
            try:
                huntcards = json.load(f)
            except json.JSONDecodeError:
                return jsonify({'success': False, 'error': 'Corrupted huntcards.json.'}), 400

    data = request.get_json() or {}
    indices = data.get('indices')
    if indices is not None:
        selected_cards = [huntcards[i] for i in indices if 0 <= i < len(huntcards)]
    else:
        selected_cards = huntcards

    output = io.StringIO()
    writer = csv.writer(output)
    writer.writerow(['Title', 'Threat Actor', 'Platform', 'Tactic', 'Technique ID', 'Technique Name', 'Hunt Status', 'Investigation What', 'Query', 'Notes', 'Analysis Summary'])
    for card in selected_cards:
        title = card.get('title', '')
        threat_actor = card.get('threat_actor', '')
        platform = card.get('platform', '')
        status = card.get('status', '')
        tactics_techniques = card.get('tactics_techniques', [])
        if isinstance(tactics_techniques, dict):
            tactic = tactics_techniques.get('tactic', '')
            techniques = tactics_techniques.get('techniques', [])
        elif isinstance(tactics_techniques, list) and tactics_techniques:
            tactic = tactics_techniques[0].get('tactic', '')
            techniques = tactics_techniques[0].get('techniques', [])
        else:
            tactic = ''
            techniques = []
        if not techniques:
            techniques = [{}]
        inv_points = card.get('investigation_points', [])
        notes = card.get('description', '')
        analysis_summary = card.get('analysis_summary', '')
        for tech in techniques:
            tech_id = tech.get('id', '')
            tech_name = tech.get('name', '')
            # Each investigation point as a row
            if inv_points:
                for p in inv_points:
                    what = p.get('what', '')
                    query = p.get('query', '')
                    point_notes = p.get('notes', '')
                    writer.writerow([
                        title, threat_actor, platform, tactic, tech_id, tech_name, status, what, query, point_notes, analysis_summary
                    ])
            else:
                writer.writerow([
                    title, threat_actor, platform, tactic, tech_id, tech_name, status, '', '', '', analysis_summary
                ])
    output.seek(0)
    return send_file(
        io.BytesIO(output.getvalue().encode('utf-8')),
        mimetype='text/csv',
        as_attachment=True,
        download_name=f'detailed_report_{case_id}.csv'
    )

@app.route('/case/<case_id>/report/detailed_text', methods=['POST'])
def report_detailed_text(case_id):
    import io
    from flask import send_file, request, jsonify
    case_folder = get_safe_case_path(case_id)
    huntcards_file = os.path.join(case_folder, "huntcards.json")
    huntcards = []
    if os.path.exists(huntcards_file):
        with open(huntcards_file, "r") as f:
            try:
                huntcards = json.load(f)
            except json.JSONDecodeError:
                return jsonify({'success': False, 'error': 'Corrupted huntcards.json.'}), 400

    data = request.get_json() or {}
    indices = data.get('indices')
    if indices is not None:
        selected_cards = [huntcards[i] for i in indices if 0 <= i < len(huntcards)]
    else:
        selected_cards = huntcards

    output = io.StringIO()
    for card in selected_cards:
        title = card.get('title', '')
        threat_actor = card.get('threat_actor', '')
        platform = card.get('platform', '')
        status = card.get('status', '')
        tactics_techniques = card.get('tactics_techniques', [])
        if isinstance(tactics_techniques, dict):
            tactic = tactics_techniques.get('tactic', '')
            techniques = tactics_techniques.get('techniques', [])
        elif isinstance(tactics_techniques, list) and tactics_techniques:
            tactic = tactics_techniques[0].get('tactic', '')
            techniques = tactics_techniques[0].get('techniques', [])
        else:
            tactic = ''
            techniques = []
        tech_str = ', '.join([f"{t.get('id','')} ({t.get('name','')})" for t in techniques if t.get('id') or t.get('name')])
        output.write('==================================================\n')
        output.write(f"HUNT CARD: {title}\n")
        output.write('==================================================\n')
        output.write(f"Threat Actor   : {threat_actor}\n")
        output.write(f"Platform       : {platform}\n")
        output.write(f"Tactic         : {tactic}\n")
        output.write(f"Technique      : {tech_str}\n")
        output.write(f"Hunt Status    : {status}\n\n")
        output.write('---------------- Investigation Points ----------------\n')
        inv_points = card.get('investigation_points', [])
        for idx, p in enumerate(inv_points, 1):
            what = p.get('what', '')
            query = p.get('query', '')
            point_notes = p.get('notes', '')
            output.write(f"[{idx}] INVESTIGATIVE POINT\n    {what}\n\n    QUERY:\n      {query}\n\n    NOTES:\n      {point_notes if point_notes else 'None'}\n\n")
        output.write('----------------- Analysis Summary ------------------\n')
        analysis_summary = card.get('analysis_summary', '')
        output.write(f"{analysis_summary}\n\n")
        output.write('--------------------------------------------------\n\n')
    output.seek(0)
    return send_file(
        io.BytesIO(output.getvalue().encode('utf-8')),
        mimetype='text/plain',
        as_attachment=True,
        download_name=f'detailed_report_{case_id}.txt'
    )

if __name__ == "__main__":
    app.run(debug=True)