#!/usr/bin/env python3
"""
HCM (Hunt Card Manager) - Command Line Interface
"""

import argparse
import sys
import os
from pathlib import Path
from . import app, __version__, __description__

def main():
    """Main CLI entry point"""
    parser = argparse.ArgumentParser(
        description=__description__,
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
Examples:
  hcm                    # Start HCM with default settings
  hcm --host 0.0.0.0    # Start HCM accessible from network
  hcm --port 8080       # Start HCM on port 8080
  hcm --debug           # Start HCM in debug mode
  hcm --version         # Show version information
        """
    )
    
    parser.add_argument(
        '--host',
        default='127.0.0.1',
        help='Host to bind to (default: 127.0.0.1)'
    )
    
    parser.add_argument(
        '--port',
        type=int,
        default=5000,
        help='Port to bind to (default: 5000)'
    )
    
    parser.add_argument(
        '--debug',
        action='store_true',
        help='Enable debug mode'
    )
    
    parser.add_argument(
        '--version',
        action='version',
        version=f'HCM {__version__}'
    )
    
    parser.add_argument(
        '--data-dir',
        help='Data directory for storing cases (default: current working directory)'
    )
    
    args = parser.parse_args()
    
    # Set data directory if specified
    if args.data_dir:
        os.environ['HCM_DATA_DIR'] = args.data_dir
    
    print(f"🚀 Starting HCM (Hunt Card Manager) v{__version__}")
    print(f"   Application will be available at: http://{args.host}:{args.port}")
    print(f"   Data directory: {os.environ.get('HCM_DATA_DIR', 'Current working directory')}")
    print(f"   Debug mode: {'Enabled' if args.debug else 'Disabled'}")
    print("   Press Ctrl+C to stop the application")
    print()
    
    try:
        app.run(
            host=args.host,
            port=args.port,
            debug=args.debug
        )
    except KeyboardInterrupt:
        print("\n👋 HCM application stopped")
    except Exception as e:
        print(f"❌ Error starting HCM: {e}")
        sys.exit(1)

if __name__ == "__main__":
    main() 