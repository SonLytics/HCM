"""
HCM (Hunt Card Manager)
Digital Forensics and Incident Response tool with MITRE ATT&CK framework integration
"""

__version__ = "1.0.0"
__author__ = "HCM Development Team"
__email__ = "hcm@example.com"
__description__ = "Digital Forensics and Incident Response tool with MITRE ATT&CK framework integration"

from .app import app
from .config import get_data_dir, ensure_data_dir

__all__ = [
    'app',
    'get_data_dir',
    'ensure_data_dir',
    '__version__',
    '__author__',
    '__email__',
    '__description__',
] 