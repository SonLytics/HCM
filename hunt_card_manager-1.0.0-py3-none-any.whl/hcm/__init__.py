"""
Hunt Card Manager (HCM)
A professional DFIR tool for managing hunt cards and investigation cases.

This package provides a web-based interface for creating, managing, and analyzing
hunt cards with MITRE ATT&CK framework integration.
"""

__version__ = "1.0.0"
__author__ = "Sonmati Maurya"
__email__ = ""

from .app import create_app
from .config import Config

__all__ = ["create_app", "Config"] 