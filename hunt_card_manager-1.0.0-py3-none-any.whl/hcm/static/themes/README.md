# HCM Modular Theme System

This directory contains a modular theme system for the Hunt Card Manager (HCM) application. The system allows you to mix and match different theme components for headers, buttons, forms, cards, navigation, and more.

## Theme Overview

### Available Themes
- **Mandiant Dark**: Dark theme using Mandiant brand colors (Orange/Red palette)
- **Google Light**: Light theme using Google brand colors (Blue/Green palette)

### Theme Components
Each theme consists of separate CSS files for different UI components:

1. **Headers** (`headers.css`) - Page headers and titles
2. **Buttons** (`buttons.css`) - Primary, secondary, success, warning, danger buttons
3. **Button Sets** (`button-sets.css`) - Edit, Delete, Analyze button groups
4. **Dropdowns** (`dropdowns.css`) - Dropdown menus and selectors
5. **Forms** (`forms.css`) - Input fields, textareas, checkboxes, radio buttons
6. **Cards** (`cards.css`) - Content cards and containers
7. **Navigation** (`navigation.css`) - Navbars, sidebars, breadcrumbs

## Usage Instructions

### 1. Basic Setup

Include the theme loader in your HTML:
```html
<script src="/static/themes/theme-loader.js"></script>
```

### 2. Applying Themes to Pages

#### For Entire Pages
Add the theme class to the `<body>` element:
```html
<body class="theme-mandiant-dark">
    <!-- Your content -->
</body>
```

#### For Specific Components
Apply theme classes to specific elements:
```html
<!-- Header with Mandiant Dark theme -->
<div class="header theme-mandiant-dark">
    <h1>Page Title</h1>
</div>

<!-- Buttons with Google Light theme -->
<div class="theme-google-light">
    <button class="btn btn-primary">Primary Button</button>
    <button class="btn btn-secondary">Secondary Button</button>
</div>
```

### 3. Component-Specific Usage

#### Headers
```html
<div class="header">
    <div class="header-content">
        <h1>Main Title</h1>
        <p class="subtitle">Subtitle text</p>
    </div>
</div>
```

#### Buttons
```html
<!-- Primary buttons -->
<button class="btn btn-primary">Primary</button>
<button class="btn btn-secondary">Secondary</button>
<button class="btn btn-success">Success</button>
<button class="btn btn-warning">Warning</button>
<button class="btn btn-danger">Danger</button>

<!-- Button sizes -->
<button class="btn btn-primary btn-sm">Small</button>
<button class="btn btn-primary btn-lg">Large</button>

<!-- Outline buttons -->
<button class="btn btn-outline">Outline</button>
```

#### Button Sets (Edit, Delete, Analyze)
```html
<div class="button-set">
    <button class="btn btn-edit">Edit</button>
    <button class="btn btn-delete">Delete</button>
    <button class="btn btn-analyze">Analyze</button>
</div>

<!-- Compact button set -->
<div class="button-set-compact">
    <button class="btn btn-edit">Edit</button>
    <button class="btn btn-delete">Delete</button>
</div>

<!-- Icon button set -->
<div class="button-set-icon">
    <button class="btn btn-edit"><i class="fas fa-edit"></i></button>
    <button class="btn btn-delete"><i class="fas fa-trash"></i></button>
</div>
```

#### Dropdowns
```html
<div class="dropdown">
    <div class="dropdown-toggle">
        Select Option
    </div>
    <div class="dropdown-menu">
        <div class="dropdown-item">Option 1</div>
        <div class="dropdown-item">Option 2</div>
        <div class="dropdown-divider"></div>
        <div class="dropdown-item">Option 3</div>
    </div>
</div>

<!-- Search dropdown -->
<div class="dropdown">
    <div class="dropdown-toggle">Search</div>
    <div class="dropdown-menu">
        <div class="dropdown-search">
            <input type="text" placeholder="Search...">
        </div>
        <div class="dropdown-item">Result 1</div>
        <div class="dropdown-item">Result 2</div>
    </div>
</div>
```

#### Forms
```html
<form class="form">
    <div class="form-group">
        <label class="form-label">Name</label>
        <input type="text" class="form-input" placeholder="Enter name">
        <div class="form-help">Enter your full name</div>
    </div>
    
    <div class="form-group">
        <label class="form-label">Description</label>
        <textarea class="form-textarea" placeholder="Enter description"></textarea>
    </div>
    
    <div class="form-group">
        <label class="form-label">Category</label>
        <select class="form-select">
            <option>Select category</option>
            <option>Category 1</option>
            <option>Category 2</option>
        </select>
    </div>
    
    <div class="form-checkbox">
        <input type="checkbox" id="agree">
        <label for="agree">I agree to terms</label>
    </div>
    
    <div class="form-actions">
        <button type="submit" class="btn btn-primary">Submit</button>
        <button type="button" class="btn btn-secondary">Cancel</button>
    </div>
</form>
```

#### Cards
```html
<div class="card">
    <div class="card-header">
        <h3 class="card-title">Card Title</h3>
        <p class="card-subtitle">Card subtitle</p>
    </div>
    <div class="card-content">
        <p>Card content goes here...</p>
    </div>
    <div class="card-footer">
        <button class="btn btn-primary">Action</button>
    </div>
</div>

<!-- Elevated card -->
<div class="card card-elevated">
    <div class="card-content">Elevated card content</div>
</div>

<!-- Interactive card -->
<div class="card card-interactive">
    <div class="card-content">Clickable card</div>
</div>

<!-- Card grid -->
<div class="card-grid card-grid-3">
    <div class="card">Card 1</div>
    <div class="card">Card 2</div>
    <div class="card">Card 3</div>
</div>
```

#### Navigation
```html
<!-- Navbar -->
<nav class="navbar">
    <a href="#" class="navbar-brand">HCM</a>
    <ul class="navbar-nav">
        <li class="nav-item">
            <a href="#" class="nav-link active">Home</a>
        </li>
        <li class="nav-item">
            <a href="#" class="nav-link">Cases</a>
        </li>
    </ul>
</nav>

<!-- Sidebar -->
<div class="sidebar">
    <div class="sidebar-header">
        <h3>Navigation</h3>
    </div>
    <nav class="sidebar-nav">
        <div class="sidebar-nav-item">
            <a href="#" class="sidebar-nav-link active">
                <i class="fas fa-home"></i>
                Dashboard
            </a>
        </div>
        <div class="sidebar-nav-item">
            <a href="#" class="sidebar-nav-link">
                <i class="fas fa-folder"></i>
                Cases
            </a>
        </div>
    </nav>
</div>

<!-- Breadcrumb -->
<div class="breadcrumb">
    <div class="breadcrumb-item">
        <a href="#" class="breadcrumb-link">Home</a>
    </div>
    <div class="breadcrumb-separator">/</div>
    <div class="breadcrumb-item">
        <a href="#" class="breadcrumb-link">Cases</a>
    </div>
    <div class="breadcrumb-separator">/</div>
    <div class="breadcrumb-item">Current Page</div>
</div>
```

### 4. Theme Switching

The theme system includes a built-in theme switcher that appears in the top-right corner. Users can click it to switch between themes.

To programmatically switch themes:
```javascript
// Switch to Mandiant Dark theme
window.themeManager.setTheme('mandiant-dark');

// Switch to Google Light theme
window.themeManager.setTheme('google-light');

// Get current theme
const currentTheme = window.themeManager.getCurrentTheme();
```

### 5. Customizing Themes

#### Adding New Themes
1. Update `theme-config.json` with your new theme
2. Create CSS files for each component with your theme classes
3. Follow the naming convention: `theme-your-theme-name`

#### Modifying Existing Themes
Edit the corresponding CSS files in the themes directory. Each file contains both Mandiant Dark and Google Light variants.

## Color Palettes

### Mandiant Dark Theme
- Primary: `#FF4D00` (Orange)
- Secondary: `#FF6B35` (Light Orange)
- Background: `#0A0A0A` (Very Dark)
- Surface: `#1A1A1A` (Dark)
- Card: `#2A2A2A` (Medium Dark)
- Text: `#FFFFFF` (White)
- Text Secondary: `#B0B0B0` (Light Gray)

### Google Light Theme
- Primary: `#4285F4` (Blue)
- Secondary: `#34A853` (Green)
- Accent: `#EA4335` (Red)
- Background: `#FFFFFF` (White)
- Surface: `#F8F9FA` (Light Gray)
- Card: `#FFFFFF` (White)
- Text: `#202124` (Dark Gray)
- Text Secondary: `#5F6368` (Medium Gray)

## Browser Support

The theme system supports all modern browsers with CSS Grid, Flexbox, and CSS Custom Properties support:
- Chrome 60+
- Firefox 55+
- Safari 12+
- Edge 79+

## Performance Notes

- Theme CSS files are loaded on-demand
- Theme preferences are saved in localStorage
- The system uses CSS custom properties for efficient theme switching
- All animations are hardware-accelerated where possible 