// Theme Loader and Manager
class ThemeManager {
    constructor() {
        this.currentTheme = 'mandiant-dark';
        this.loadedComponents = new Set();
        this.themeConfig = null;
        this.init();
    }

    async init() {
        await this.loadThemeConfig();
        this.loadSavedTheme();
        this.setupThemeSwitcher();
    }

    async loadThemeConfig() {
        try {
            const response = await fetch('/static/themes/theme-config.json');
            this.themeConfig = await response.json();
        } catch (error) {
            console.error('Failed to load theme config:', error);
            // Fallback config
            this.themeConfig = {
                themes: {
                    'mandiant-dark': { name: 'Mandiant Dark' },
                    'google-light': { name: 'Google Light' }
                },
                components: {
                    'headers': ['mandiant-dark', 'google-light'],
                    'buttons': ['mandiant-dark', 'google-light'],
                    'button-sets': ['mandiant-dark', 'google-light'],
                    'dropdowns': ['mandiant-dark', 'google-light'],
                    'forms': ['mandiant-dark', 'google-light'],
                    'cards': ['mandiant-dark', 'google-light'],
                    'navigation': ['mandiant-dark', 'google-light']
                }
            };
        }
    }

    loadSavedTheme() {
        const savedTheme = localStorage.getItem('hcm-theme');
        if (savedTheme && this.themeConfig.themes[savedTheme]) {
            this.setTheme(savedTheme);
        }
    }

    setupThemeSwitcher() {
        // Create theme switcher if it doesn't exist
        if (!document.getElementById('theme-switcher')) {
            this.createThemeSwitcher();
        }
    }

    createThemeSwitcher() {
        const switcher = document.createElement('div');
        switcher.id = 'theme-switcher';
        switcher.className = 'theme-switcher';
        switcher.innerHTML = `
            <div class="theme-switcher-toggle">
                <span class="theme-icon">🎨</span>
                <span class="theme-label">Theme</span>
            </div>
            <div class="theme-switcher-menu">
                <div class="theme-option" data-theme="mandiant-dark">
                    <span class="theme-preview mandiant-preview"></span>
                    <span class="theme-name">Mandiant Dark</span>
                </div>
                <div class="theme-option" data-theme="google-light">
                    <span class="theme-preview google-preview"></span>
                    <span class="theme-name">Google Light</span>
                </div>
            </div>
        `;

        // Add styles
        const style = document.createElement('style');
        style.textContent = `
            .theme-switcher {
                position: fixed;
                top: 20px;
                right: 20px;
                z-index: 10000;
                font-family: 'JetBrains Mono', monospace;
            }

            .theme-switcher-toggle {
                display: flex;
                align-items: center;
                gap: 8px;
                padding: 12px 16px;
                background: rgba(255, 255, 255, 0.1);
                backdrop-filter: blur(10px);
                border-radius: 8px;
                cursor: pointer;
                transition: all 0.2s ease;
                border: 1px solid rgba(255, 255, 255, 0.2);
            }

            .theme-switcher-toggle:hover {
                background: rgba(255, 255, 255, 0.2);
                transform: translateY(-1px);
            }

            .theme-icon {
                font-size: 1.2rem;
            }

            .theme-label {
                font-size: 0.9rem;
                font-weight: 600;
                color: #FFFFFF;
            }

            .theme-switcher-menu {
                position: absolute;
                top: 100%;
                right: 0;
                margin-top: 8px;
                background: rgba(0, 0, 0, 0.9);
                backdrop-filter: blur(10px);
                border-radius: 8px;
                padding: 8px;
                min-width: 200px;
                opacity: 0;
                visibility: hidden;
                transform: translateY(-10px);
                transition: all 0.2s ease;
                border: 1px solid rgba(255, 255, 255, 0.2);
            }

            .theme-switcher.open .theme-switcher-menu {
                opacity: 1;
                visibility: visible;
                transform: translateY(0);
            }

            .theme-option {
                display: flex;
                align-items: center;
                gap: 12px;
                padding: 12px;
                cursor: pointer;
                border-radius: 6px;
                transition: all 0.2s ease;
            }

            .theme-option:hover {
                background: rgba(255, 255, 255, 0.1);
            }

            .theme-preview {
                width: 24px;
                height: 24px;
                border-radius: 4px;
                border: 2px solid rgba(255, 255, 255, 0.3);
            }

            .mandiant-preview {
                background: linear-gradient(135deg, #FF4D00, #FF6B35);
            }

            .google-preview {
                background: linear-gradient(135deg, #4285F4, #34A853);
            }

            .theme-name {
                color: #FFFFFF;
                font-size: 0.9rem;
                font-weight: 500;
            }

            .theme-option.active .theme-preview {
                border-color: #FF4D00;
            }
        `;

        document.head.appendChild(style);
        document.body.appendChild(switcher);

        // Add event listeners
        const toggle = switcher.querySelector('.theme-switcher-toggle');
        const options = switcher.querySelectorAll('.theme-option');

        toggle.addEventListener('click', () => {
            switcher.classList.toggle('open');
        });

        options.forEach(option => {
            option.addEventListener('click', () => {
                const theme = option.dataset.theme;
                this.setTheme(theme);
                switcher.classList.remove('open');
                
                // Update active state
                options.forEach(opt => opt.classList.remove('active'));
                option.classList.add('active');
            });
        });

        // Close when clicking outside
        document.addEventListener('click', (e) => {
            if (!switcher.contains(e.target)) {
                switcher.classList.remove('open');
            }
        });
    }

    async setTheme(themeName) {
        if (!this.themeConfig.themes[themeName]) {
            console.error(`Theme "${themeName}" not found`);
            return;
        }

        this.currentTheme = themeName;
        localStorage.setItem('hcm-theme', themeName);

        // Update body class
        document.body.className = document.body.className.replace(/theme-\w+/g, '');
        document.body.classList.add(`theme-${themeName}`);

        // Load theme components
        await this.loadThemeComponents(themeName);

        // Dispatch theme change event
        document.dispatchEvent(new CustomEvent('themeChanged', { 
            detail: { theme: themeName } 
        }));
    }

    async loadThemeComponents(themeName) {
        const components = ['headers', 'buttons', 'button-sets', 'dropdowns', 'forms', 'cards', 'navigation'];
        
        for (const component of components) {
            if (!this.loadedComponents.has(component)) {
                await this.loadComponentCSS(component);
                this.loadedComponents.add(component);
            }
        }
    }

    async loadComponentCSS(component) {
        const linkId = `theme-${component}`;
        
        // Remove existing link if present
        const existingLink = document.getElementById(linkId);
        if (existingLink) {
            existingLink.remove();
        }

        // Create new link
        const link = document.createElement('link');
        link.id = linkId;
        link.rel = 'stylesheet';
        link.href = `/static/themes/${component}.css`;
        
        // Add to head
        document.head.appendChild(link);

        // Return promise that resolves when CSS is loaded
        return new Promise((resolve) => {
            link.onload = resolve;
            link.onerror = resolve; // Resolve even on error to not block
        });
    }

    // Utility methods for applying themes to specific elements
    applyComponentTheme(element, component, theme = null) {
        const targetTheme = theme || this.currentTheme;
        element.className = element.className.replace(/theme-\w+/g, '');
        element.classList.add(`theme-${targetTheme}`);
        element.classList.add(component);
    }

    // Get current theme
    getCurrentTheme() {
        return this.currentTheme;
    }

    // Get available themes
    getAvailableThemes() {
        return Object.keys(this.themeConfig.themes);
    }

    // Get theme info
    getThemeInfo(themeName) {
        return this.themeConfig.themes[themeName];
    }
}

// Initialize theme manager when DOM is loaded
document.addEventListener('DOMContentLoaded', () => {
    window.themeManager = new ThemeManager();
});

// Export for use in other scripts
if (typeof module !== 'undefined' && module.exports) {
    module.exports = ThemeManager;
} 