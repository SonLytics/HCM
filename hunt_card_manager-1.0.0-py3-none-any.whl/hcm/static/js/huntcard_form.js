let mitreData = [];
let selectedPairs = [];
let selectedTechniques = []; // Track selected techniques for current tactic

// Global variable to track sidebar state
let suggestionSidebarOpen = false;
let currentSuggestions = [];
let currentInput = null;

// Popup notification function
function showPopup(message, duration = 2000) {
    // Remove existing popup if any
    const existingPopup = document.querySelector('.popup-notification');
    if (existingPopup) {
        existingPopup.remove();
    }
    
    const popup = document.createElement('div');
    popup.className = 'popup-notification';
    popup.textContent = message;
    document.body.appendChild(popup);
    
    // Show popup
    setTimeout(() => popup.classList.add('show'), 100);
    
    // Hide and remove popup
    setTimeout(() => {
        popup.classList.remove('show');
        setTimeout(() => popup.remove(), 300);
    }, duration);
}

// Load MITRE tactics and fill tactic dropdown
document.addEventListener("DOMContentLoaded", function() {
    console.log("DOM Content Loaded - Loading MITRE data...");
    fetch("/static/data/mitre_attack.json")
        .then(response => {
            console.log("MITRE JSON response status:", response.status);
            return response.json();
        })
        .then(data => {
            console.log("MITRE data loaded:", data);
            console.log("Number of tactics:", data.length);
            mitreData = data;
            const tacticSelect = document.getElementById("tactic-select");
            console.log("Tactic select element found:", !!tacticSelect);
            
            if (tacticSelect) {
                mitreData.forEach(item => {
                    console.log("Adding tactic:", item.tactic, "with", item.techniques.length, "techniques");
                    const option = document.createElement("option");
                    option.value = item.tactic;
                    option.textContent = item.tactic;
                    tacticSelect.appendChild(option);
                });
                console.log("Total tactics added to dropdown:", tacticSelect.options.length);
            } else {
                console.error("Tactic select element not found!");
            }
        })
        .catch(error => {
            console.error("Error loading MITRE data:", error);
        });

    // Add event listener for platform selection
    const platformSelect = document.getElementById("platform");
    if (platformSelect) {
        platformSelect.addEventListener("change", handlePlatformChange);
    }
    
    // Hide the "Selected Tactics & Techniques" heading on page load
    const heading = document.querySelector('.mitre-section h4');
    if (heading) {
        heading.style.display = 'none';
    }
    
    // Ensure tactic change event listener is attached
    setTimeout(() => {
        const tacticSelect = document.getElementById("tactic-select");
        if (tacticSelect) {
            console.log("Attaching tactic change event listener...");
            tacticSelect.addEventListener("change", function() {
                const selectedTactic = this.value;
                const techniqueSelect = document.getElementById("technique-select");
                const addBtn = document.querySelector(".mitre-add-btn");
                
                console.log("Tactic changed to:", selectedTactic);
                console.log("Technique select element found:", !!techniqueSelect);
                console.log("Add button found:", !!addBtn);
                console.log("Current mitreData:", mitreData);
                
                techniqueSelect.innerHTML = "";
                addBtn.disabled = true;
                selectedTechniques = []; // Reset selected techniques
                updateTechniqueDisplay(); // Update label immediately

                if (!selectedTactic) {
                    console.log("No tactic selected");
                    techniqueSelect.disabled = true; // Disable technique select
                    const option = document.createElement("option");
                    option.value = "";
                    option.textContent = "Select a tactic first";
                    techniqueSelect.appendChild(option);
                    return;
                }

                const tacticData = mitreData.find(t => t.tactic === selectedTactic);
                console.log("Found tactic data:", tacticData);
                
                if (tacticData) {
                    console.log("Loading", tacticData.techniques.length, "techniques for tactic:", selectedTactic);
                    // Enable technique select
                    techniqueSelect.disabled = false;
                    
                    // Add empty first option
                    const emptyOption = document.createElement("option");
                    emptyOption.value = "";
                    emptyOption.textContent = "-- Select Technique --";
                    techniqueSelect.appendChild(emptyOption);
                    
                    tacticData.techniques.forEach(tech => {
                        console.log("Adding technique:", tech.id, "-", tech.name);
                        const option = document.createElement("option");
                        option.value = tech.id;
                        option.textContent = `${tech.id} - ${tech.name}`;
                        techniqueSelect.appendChild(option);
                    });
                    
                    console.log("Total techniques added:", techniqueSelect.options.length);
                    // Enable the add button when techniques are loaded
                    addBtn.disabled = false;
                } else {
                    console.error("No tactic data found for:", selectedTactic);
                    techniqueSelect.disabled = true; // Disable technique select
                    const option = document.createElement("option");
                    option.value = "";
                    option.textContent = "No techniques found for this tactic";
                    techniqueSelect.appendChild(option);
                }
            });
        }
    }, 1000);

    var form = document.querySelector('form');
    if (form) {
        form.addEventListener('submit', function(e) {
            var tacticsInput = document.getElementById('tactics_techniques');
            if (tacticsInput) {
                tacticsInput.value = JSON.stringify(selectedPairs);
            }
        });
    }
});

// Handle technique selection
document.getElementById("technique-select").addEventListener("change", function() {
    const selectedValue = this.value;
    if (!selectedValue || selectedValue === "") return;
    
    const selectedText = this.options[this.selectedIndex].text;
    if (selectedText === "Select a tactic first" || selectedText === "No techniques found for this tactic" || selectedText === "-- Select Technique --") return;
    
    const [id, ...nameParts] = selectedText.split(" - ");
    const technique = { id: id.trim(), name: nameParts.join(" - ").trim() };
    
    // Check if technique is already selected
    if (!selectedTechniques.find(t => t.id === technique.id)) {
        selectedTechniques.push(technique);
        updateTechniqueDisplay();
        
        // Disable the selected option in the dropdown
        this.options[this.selectedIndex].disabled = true;
        this.options[this.selectedIndex].style.color = "#999";
        this.options[this.selectedIndex].style.fontStyle = "italic";
    }
    
    // Reset selection to first option (which should be empty)
    this.selectedIndex = 0;
});

function updateTechniqueDisplay() {
    const techniqueSelect = document.getElementById("technique-select");
    const parent = techniqueSelect.parentNode;
    
    // Update the label text to show count
    const label = parent.querySelector('label');
    if (label) {
        if (selectedTechniques.length === 0) {
            label.textContent = "Techniques (Multi-select)";
        } else {
            label.textContent = `Techniques (${selectedTechniques.length})`;
        }
    }
    
    // Don't show the selected techniques display - keep it hidden until + button is clicked
}

// Add selected tactic & techniques to list
function addTacticTechnique() {
    const tactic = document.getElementById("tactic-select").value;

    if (!tactic) {
        alert("Please select a tactic first.");
        return;
    }
    
    if (selectedTechniques.length === 0) {
        alert("Please select at least one technique.");
        return;
    }

    // Check if this tactic is already selected
    const existingPairIndex = selectedPairs.findIndex(pair => pair.tactic === tactic);
    if (existingPairIndex !== -1) {
        // Merge techniques with existing ones
        const existingTechniques = selectedPairs[existingPairIndex].techniques;
        selectedTechniques.forEach(newTech => {
            if (!existingTechniques.find(existing => existing.id === newTech.id)) {
                existingTechniques.push(newTech);
            }
        });
    } else {
        selectedPairs.push({ tactic, techniques: [...selectedTechniques] });
    }
    
    updateSelectedList();
    
    // Clear selections
    selectedTechniques = [];
    updateTechniqueDisplay();
    
    // Show success feedback
    showPopup("✅ Tactic and techniques added successfully!", 2000);
}

function updateSelectedList() {
    const list = document.getElementById("selected-list");
    const heading = document.querySelector('.mitre-section h4');
    
    list.innerHTML = "";

    if (selectedPairs.length === 0) {
        // Hide the heading when no tactics are selected
        if (heading) {
            heading.style.display = 'none';
        }
        
        const emptyItem = document.createElement("li");
        emptyItem.textContent = "No tactics and techniques selected yet";
        emptyItem.style.color = "#64748b";
        emptyItem.style.fontStyle = "italic";
        list.appendChild(emptyItem);
        return;
    }

    // Show the heading when tactics are selected
    if (heading) {
        heading.style.display = 'block';
    }

    selectedPairs.forEach((pair, idx) => {
        const item = document.createElement("li");
        
        const textSpan = document.createElement("span");
        textSpan.innerHTML = `<strong style="color: #1e293b;">${pair.tactic} </strong><span style="color: #475569;">| ${pair.techniques.map(t => t.name).join(", ")}</span>`;
        
        item.appendChild(textSpan);

        const removeBtn = document.createElement("button");
        removeBtn.textContent = "✖";
        removeBtn.title = "Remove this tactic and its techniques";
        removeBtn.onclick = () => {
            selectedPairs.splice(idx, 1);
            updateSelectedList();
        };

        item.appendChild(removeBtn);
        list.appendChild(item);
    });

    document.getElementById("tactics-techniques-data").value = JSON.stringify(selectedPairs);
}

// ---------- Investigation Point Add Logic ----------

function showInvestigationAddForm() {
    document.getElementById('investigation-add-form').classList.remove('hidden');
    document.getElementById('show-add-btn').classList.add('hidden');
}

function hideInvestigationAddForm() {
    document.getElementById('investigation-add-form').classList.add('hidden');
    document.getElementById('show-add-btn').classList.remove('hidden');
    document.getElementById('add-what').value = '';
    document.getElementById('add-query').value = '';
}

function addInvestigationPointInline() {
    const what = document.getElementById('add-what').value.trim();
    const query = document.getElementById('add-query').value.trim();
    if (!what || !query) {
        alert("Please fill out both fields.");
        return;
    }
    
    // Get the investigation-add-form element to insert after it
    const addForm = document.getElementById('investigation-add-form');
    const index = document.querySelectorAll('.investigation-point').length;
    
    const div = document.createElement('div');
    div.className = 'investigation-point';
    div.innerHTML = `
        <label>What to Investigate:</label>
        <div class="input-container">
            <textarea class="input-box" rows="2" name="point_what_${index}">${what.replace(/"/g, '&quot;')}</textarea>
            <button type="button" onclick="suggest('what', ${index})" class="suggest-btn" aria-label="Get suggestions for investigation point">★</button>
        </div>

        <label>Query:</label>
        <div class="input-container">
            <textarea class="input-box" rows="2" name="point_query_${index}">${query.replace(/"/g, '&quot;')}</textarea>
            <button type="button" onclick="suggest('query', ${index})" class="suggest-btn" aria-label="Get suggestions for query">★</button>
        </div>
    `;
    
    // Insert the new point after the investigation-add-form
    addForm.parentNode.insertBefore(div, addForm.nextSibling);
    
    // Scroll to the newly added point
    div.scrollIntoView({ behavior: 'smooth', block: 'nearest' });
    
    hideInvestigationAddForm();
}


// ---------- Suggestion Functionality ----------

function suggest(type, idx) {
    if (type === 'what') {
        const inputSelector = `textarea[name="point_what_${idx}"]`;
        const input = document.querySelector(inputSelector);
        const keywords = encodeURIComponent(input.value.trim());

        if (!keywords || keywords.length < 2) {
            alert("Type at least 2 characters to get suggestions.");
            return;
        }

        // Use global suggestions from all cases
        fetch(`/suggest/global/${type}?keywords=${keywords}`)
            .then(resp => resp.json())
            .then(data => {
                console.log(`Suggestions for ${type}:`, data);
                showSuggestionPanel(input, data);
            })
            .catch(err => console.error("Suggestion error", err));
    } else if (type === 'query') {
        const queryInputSelector = `textarea[name="point_query_${idx}"]`;
        const whatInputSelector = `textarea[name="point_what_${idx}"]`;
        const queryInput = document.querySelector(queryInputSelector);
        const whatInput = document.querySelector(whatInputSelector);
        const keywords = encodeURIComponent(whatInput.value.trim());

        if (!keywords || keywords.length < 2) {
            alert("Type at least 2 characters in 'What to Investigate' field to get query suggestions.");
            return;
        }

        // Use global suggestions from all cases, but search based on "what" field
        fetch(`/suggest/global/${type}?keywords=${keywords}`)
            .then(resp => resp.json())
            .then(data => {
                console.log(`Suggestions for ${type}:`, data);
                showSuggestionPanel(queryInput, data);
            })
            .catch(err => console.error("Suggestion error", err));
    }
}

function suggestInline(type) {
    if (type === 'what') {
        const input = document.getElementById("add-what");
        const keywords = encodeURIComponent(input.value.trim());

        if (!keywords || keywords.length < 2) {
            alert("Type at least 2 characters to get suggestions.");
            return;
        }

        // Use global suggestions from all cases
        fetch(`/suggest/global/${type}?keywords=${keywords}`)
            .then(resp => resp.json())
            .then(data => {
                console.log(`Inline suggestions for ${type}:`, data);
                showSuggestionPanel(input, data);
            })
            .catch(err => console.error("Suggestion error", err));
    } else if (type === 'query') {
        const queryInput = document.getElementById("add-query");
        const whatInput = document.getElementById("add-what");
        const keywords = encodeURIComponent(whatInput.value.trim());

        if (!keywords || keywords.length < 2) {
            alert("Type at least 2 characters in 'What to Investigate' field to get query suggestions.");
            return;
        }

        // Use global suggestions from all cases, but search based on "what" field
        fetch(`/suggest/global/${type}?keywords=${keywords}`)
            .then(resp => resp.json())
            .then(data => {
                console.log(`Inline suggestions for ${type}:`, data);
                showSuggestionPanel(queryInput, data);
            })
            .catch(err => console.error("Suggestion error", err));
    }
}

function showSuggestionPanel(anchorInput, suggestions) {
    currentSuggestions = suggestions;
    currentInput = anchorInput;
    
    // Create sidebar if it doesn't exist
    let sidebar = document.getElementById('suggestion-sidebar');
    if (!sidebar) {
        createSuggestionSidebar();
        sidebar = document.getElementById('suggestion-sidebar');
    }
    
    updateSuggestionSidebarContent(suggestions, anchorInput);
    openSuggestionSidebar();
}

function createSuggestionSidebar() {
    const sidebar = document.createElement('div');
    sidebar.id = 'suggestion-sidebar';
    sidebar.style = `
        position: fixed;
        top: 0;
        right: -400px;
        width: 400px;
        height: 100vh;
        background: white;
        border-left: 2px solid #42be65;
        box-shadow: -4px 0 12px rgba(0,0,0,0.15);
        z-index: 10000;
        transition: right 0.3s ease;
        display: flex;
        flex-direction: column;
        font-family: 'Segoe UI', 'Roboto', Arial, sans-serif;
    `;
    
    // Header
    const header = document.createElement('div');
    header.style = `
        padding: 16px 20px;
        background: #f0f4f8;
        border-bottom: 1px solid #e3e8ee;
        display: flex;
        justify-content: space-between;
        align-items: center;
        font-weight: 600;
        color: #274060;
    `;
    
    const title = document.createElement('div');
    title.id = 'sidebar-title';
    title.textContent = 'Suggestions';
    
    const closeBtn = document.createElement('button');
    closeBtn.innerHTML = '✕';
    closeBtn.style = `
        background: none;
        border: none;
        font-size: 18px;
        cursor: pointer;
        color: #666;
        padding: 4px 8px;
        border-radius: 4px;
    `;
    closeBtn.onclick = closeSuggestionSidebar;
    
    header.appendChild(title);
    header.appendChild(closeBtn);
    
    // Content area
    const content = document.createElement('div');
    content.id = 'sidebar-content';
    content.style = `
        flex: 1;
        overflow-y: auto;
        padding: 20px;
    `;
    
    sidebar.appendChild(header);
    sidebar.appendChild(content);
    document.body.appendChild(sidebar);
    
    // Create toggle button
    createSidebarToggleButton();
}

function createSidebarToggleButton() {
    let toggleBtn = document.getElementById('sidebar-toggle-btn');
    if (toggleBtn) toggleBtn.remove();
    
    toggleBtn = document.createElement('button');
    toggleBtn.id = 'sidebar-toggle-btn';
    toggleBtn.innerHTML = '💡';
    toggleBtn.style = `
        position: fixed;
        top: 50%;
        right: 20px;
        transform: translateY(-50%);
        width: 50px;
        height: 50px;
        background: #42be65;
        color: white;
        border: none;
        border-radius: 50%;
        cursor: pointer;
        font-size: 20px;
        box-shadow: 0 4px 12px rgba(66,190,101,0.3);
        z-index: 9999;
        transition: all 0.3s ease;
    `;
    
    toggleBtn.onclick = toggleSuggestionSidebar;
    document.body.appendChild(toggleBtn);
}

function updateSuggestionSidebarContent(suggestions, anchorInput) {
    const content = document.getElementById('sidebar-content');
    const title = document.getElementById('sidebar-title');
    
    const isQueryField = anchorInput.id === 'add-query' || anchorInput.name?.includes('point_query');
    
    if (isQueryField && suggestions.length > 0 && typeof suggestions[0] === 'object') {
        title.textContent = `Query Suggestions (${suggestions.length})`;
    } else {
        title.textContent = `Suggestions (${suggestions.length})`;
    }
    
    if (suggestions.length === 0) {
        content.innerHTML = '<div style="text-align: center; padding: 40px; color: #666;">No suggestions found.</div>';
        return;
    }
    
    let html = '';
    suggestions.forEach((s, index) => {
        if (isQueryField && typeof s === 'object' && s.what && s.query) {
            html += `
                <div class="suggestion-item" data-index="${index}" style="
                    padding: 16px;
                    margin-bottom: 12px;
                    background: #f7fafc;
                    border: 1px solid #e3e8ee;
                    border-radius: 8px;
                    cursor: pointer;
                ">
                    <div style="font-weight: 600; color: #274060; margin-bottom: 8px;">
                        <strong>What:</strong> ${s.what}
                    </div>
                    <div style="color: #42be65; font-family: monospace; font-size: 13px;">
                        <strong>Query:</strong> ${s.query}
                    </div>
                </div>
            `;
        } else if (typeof s === 'string') {
            html += `
                <div class="suggestion-item" data-index="${index}" style="
                    padding: 16px;
                    margin-bottom: 12px;
                    background: #f7fafc;
                    border: 1px solid #e3e8ee;
                    border-radius: 8px;
                    cursor: pointer;
                ">
                    ${s}
                </div>
            `;
        }
    });
    
    content.innerHTML = html;
    
    // Add click handlers
    const items = content.querySelectorAll('.suggestion-item');
    items.forEach((item, index) => {
        item.onclick = () => selectSuggestion(index);
        item.onmouseenter = () => {
            item.style.background = '#e8f4fd';
            item.style.borderColor = '#42be65';
        };
        item.onmouseleave = () => {
            item.style.background = '#f7fafc';
            item.style.borderColor = '#e3e8ee';
        };
    });
}

function selectSuggestion(index) {
    if (!currentInput || !currentSuggestions[index]) return;
    
    const suggestion = currentSuggestions[index];
    const isQueryField = currentInput.id === 'add-query' || currentInput.name?.includes('point_query');
    
    if (isQueryField && typeof suggestion === 'object' && suggestion.what && suggestion.query) {
        currentInput.value = suggestion.query;
    } else if (typeof suggestion === 'string') {
        currentInput.value = suggestion;
    }
    
    currentInput.dispatchEvent(new Event('input', { bubbles: true }));
    closeSuggestionSidebar();
}

function openSuggestionSidebar() {
    const sidebar = document.getElementById('suggestion-sidebar');
    if (sidebar) {
        sidebar.style.right = '0';
        suggestionSidebarOpen = true;
    }
}

function closeSuggestionSidebar() {
    const sidebar = document.getElementById('suggestion-sidebar');
    if (sidebar) {
        sidebar.style.right = '-400px';
        suggestionSidebarOpen = false;
    }
}

function toggleSuggestionSidebar() {
    if (suggestionSidebarOpen) {
        closeSuggestionSidebar();
    } else {
        openSuggestionSidebar();
    }
}

// ---------- Platform Selection Logic ----------

function handlePlatformChange() {
    const platformSelect = document.getElementById("platform");
    const customContainer = document.getElementById("custom-platform-container");
    customContainer.style.display = platformSelect.value === "Other" ? "block" : "none";
}
