// Hunt Card List Page JavaScript
const themeToggle = document.getElementById('theme-toggle');
const toggleKnob = document.getElementById('toggle-knob');

function setTheme(theme) {
  document.body.setAttribute('data-theme', theme);
  localStorage.setItem('theme', theme);
  if (theme === 'black-dark') {
    themeToggle.checked = true;
    toggleKnob.style.left = '2px';
  } else {
    themeToggle.checked = false;
    toggleKnob.style.left = '18px';
  }
}

function toggleExportDropdown() {
  const dropdown = document.getElementById('exportOptions');
  dropdown.classList.toggle('show');
}



// Close dropdown when clicking outside
document.addEventListener('click', function(event) {
  const dropdown = document.getElementById('exportOptions');
  const exportButton = event.target.closest('.export-dropdown');
  
  if (!exportButton) {
    dropdown.classList.remove('show');
  }
});

// Theme toggle event listener
if (themeToggle) {
  themeToggle.addEventListener('change', function() {
    setTheme(this.checked ? 'black-dark' : 'white-light');
  });
}

// Initialize theme on page load
document.addEventListener('DOMContentLoaded', function() {
  const savedTheme = localStorage.getItem('theme') || 'white-light';
  setTheme(savedTheme);
  
  // Import panel functionality
  var openBtn = document.getElementById('open-import-panel');
  var closeBtn = document.getElementById('close-import-panel');
  var panel = document.getElementById('import-panel');
  
  if (openBtn && closeBtn && panel) {
    openBtn.onclick = function() { panel.classList.add('open'); };
    closeBtn.onclick = function() { panel.classList.remove('open'); };
    
    // Close panel when clicking outside
    document.addEventListener('mousedown', function(e) {
      if (panel.classList.contains('open') && !panel.contains(e.target) && e.target !== openBtn) {
        panel.classList.remove('open');
      }
    });
  }
  
  // File upload functionality
  const fileInput = document.getElementById('file-input');
  const fileLabel = document.querySelector('.file-upload-label');
  const fileInfo = document.getElementById('file-info');
  const fileName = document.querySelector('.file-name');
  
  if (fileInput && fileLabel) {
    // Handle file selection
    fileInput.addEventListener('change', function(e) {
      const file = e.target.files[0];
      if (file) {
        showFileInfo(file.name);
      }
    });
    
    // Handle drag and drop
    fileLabel.addEventListener('dragover', function(e) {
      e.preventDefault();
      fileLabel.classList.add('dragover');
    });
    
    fileLabel.addEventListener('dragleave', function(e) {
      e.preventDefault();
      fileLabel.classList.remove('dragover');
    });
    
    fileLabel.addEventListener('drop', function(e) {
      e.preventDefault();
      fileLabel.classList.remove('dragover');
      
      const files = e.dataTransfer.files;
      if (files.length > 0) {
        const file = files[0];
        if (file.type === 'text/csv' || file.name.endsWith('.json') || file.name.endsWith('.csv')) {
          fileInput.files = files;
          showFileInfo(file.name);
        } else {
          alert('Please select a CSV or JSON file.');
        }
      }
    });
  }
});

function showFileInfo(name) {
  const fileInfo = document.getElementById('file-info');
  const fileName = document.querySelector('.file-name');
  if (fileInfo && fileName) {
    fileName.textContent = name;
    fileInfo.style.display = 'flex';
  }
}

function clearFile() {
  const fileInput = document.getElementById('file-input');
  const fileInfo = document.getElementById('file-info');
  if (fileInput && fileInfo) {
    fileInput.value = '';
    fileInfo.style.display = 'none';
  }
} 