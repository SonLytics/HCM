// Tree View Page JavaScript
const themeToggle = document.getElementById('theme-toggle');
const toggleKnob = document.getElementById('toggle-knob');

function setTheme(theme) {
  document.body.setAttribute('data-theme', theme);
  localStorage.setItem('theme', theme);
  if (theme === 'black-dark') {
    themeToggle.checked = true;
    toggleKnob.style.left = '2px';
  } else {
    themeToggle.checked = false;
    toggleKnob.style.left = '18px';
  }
}

// Theme toggle event listener
if (themeToggle) {
  themeToggle.addEventListener('change', function() {
    setTheme(this.checked ? 'black-dark' : 'white-light');
  });
}

// Initialize on page load
document.addEventListener('DOMContentLoaded', function() {
  const savedTheme = localStorage.getItem('theme') || 'white-light';
  setTheme(savedTheme);
  
  // Initialize mind map
  initializeMindMap();
});

function initializeMindMap() {
  const mindMapData = window.mindMapData; // Will be set from template
  
  if (!mindMapData) {
    console.error('Mind map data not available');
    return;
  }
  
  // Set up dimensions
  const container = document.getElementById('mind-map');
  const width = container.clientWidth;
  const height = container.clientHeight;
  
  // Create SVG
  const svg = d3.select('#mind-map')
    .append('svg')
    .attr('width', width)
    .attr('height', height);
  
  // Create zoom behavior
  const zoom = d3.zoom()
    .scaleExtent([0.1, 3])
    .on('zoom', (event) => {
      svg.select('g').attr('transform', event.transform);
    });
  
  svg.call(zoom);
  
  // Create main group
  const g = svg.append('g');
  
  // Create force simulation
  const simulation = d3.forceSimulation(mindMapData.nodes)
    .force('link', d3.forceLink(mindMapData.links).id(d => d.id).distance(100))
    .force('charge', d3.forceManyBody().strength(-150))
    .force('center', d3.forceCenter(width / 2, height / 2))
    .force('collision', d3.forceCollide().radius(35))
    .force('x', d3.forceX().x(d => {
      // Fixed X positioning by layer
      switch(d.type) {
        case 'case': return width * 0.1;
        case 'threat_actor': return width * 0.25;
        case 'platform': return width * 0.4;
        case 'tactic': return width * 0.55;
        case 'technique': return width * 0.7;
        case 'huntcard': return width * 0.85;
        default: return width * 0.5;
      }
    }).strength(0.7))
    .force('y', d3.forceY().y(d => {
      // Fixed Y positioning by layer
      switch(d.type) {
        case 'case': return height * 0.1;
        case 'threat_actor': return height * 0.3;
        case 'platform': return height * 0.5;
        case 'tactic': return height * 0.7;
        case 'technique': return height * 0.85;
        case 'huntcard': return height * 0.95;
        default: return height * 0.5;
      }
    }).strength(0.5));
  
  // Create links
  const links = g.append('g')
    .selectAll('line')
    .data(mindMapData.links)
    .enter()
    .append('line')
    .attr('class', 'link');
  
  // Create nodes
  const nodes = g.append('g')
    .selectAll('g')
    .data(mindMapData.nodes)
    .enter()
    .append('g')
    .attr('class', 'node')
    .call(d3.drag()
      .on('start', dragstarted)
      .on('drag', dragged)
      .on('end', dragended));
  
  // Add circles to nodes
  nodes.append('circle')
    .attr('r', d => {
      switch(d.type) {
        case 'case': return 25;
        case 'threat_actor': return 20;
        case 'platform': return 18;
        case 'tactic': return 16;
        case 'technique': return 14;
        case 'huntcard': return 12;
        default: return 15;
      }
    })
    .attr('fill', d => {
      switch(d.type) {
        case 'case': return '#3b82f6';
        case 'threat_actor': return '#ef4444';
        case 'platform': return '#f59e0b';
        case 'tactic': return '#10b981';
        case 'technique': return '#8b5cf6';
        case 'huntcard': return '#64748b';
        default: return '#6b7280';
      }
    })
    .attr('stroke', 'var(--border)')
    .attr('stroke-width', 2);
  
  // Add text labels
  nodes.append('text')
    .attr('class', 'node-text')
    .attr('dy', d => {
      switch(d.type) {
        case 'case': return 0;
        case 'threat_actor': return 0;
        case 'platform': return 0;
        case 'tactic': return 0;
        case 'technique': return 0;
        case 'huntcard': return 0;
        default: return 0;
      }
    })
    .text(d => {
      // Truncate long labels
      const maxLength = d.type === 'huntcard' ? 15 : 20;
      return d.label.length > maxLength ? d.label.substring(0, maxLength) + '...' : d.label;
    });
  
  // Add click handlers for hunt card nodes
  nodes.filter(d => d.type === 'huntcard')
    .on('click', function(event, d) {
      window.open(`/case/${d.case_id}/analyze/${d.huntcard_idx}`, '_blank');
    });
  
  // Update positions on simulation tick
  simulation.on('tick', () => {
    links
      .attr('x1', d => d.source.x)
      .attr('y1', d => d.source.y)
      .attr('x2', d => d.target.x)
      .attr('y2', d => d.target.y);
    
    nodes
      .attr('transform', d => `translate(${d.x},${d.y})`);
  });
  
  // Drag functions
  function dragstarted(event, d) {
    if (!event.active) simulation.alphaTarget(0.1).restart();
    d.fx = d.x;
    d.fy = d.y;
  }
  
  function dragged(event, d) {
    d.fx = event.x;
    d.fy = event.y;
  }
  
  function dragended(event, d) {
    if (!event.active) simulation.alphaTarget(0);
    d.fx = null;
    d.fy = null;
  }
  
  // Handle window resize
  window.addEventListener('resize', () => {
    const newWidth = container.clientWidth;
    const newHeight = container.clientHeight;
    
    svg.attr('width', newWidth).attr('height', newHeight);
    simulation.force('center', d3.forceCenter(newWidth / 2, newHeight / 2));
    simulation.force('x', d3.forceX().x(d => {
      switch(d.type) {
        case 'case': return newWidth * 0.1;
        case 'threat_actor': return newWidth * 0.25;
        case 'platform': return newWidth * 0.4;
        case 'tactic': return newWidth * 0.55;
        case 'technique': return newWidth * 0.7;
        case 'huntcard': return newWidth * 0.85;
        default: return newWidth * 0.5;
      }
    }).strength(0.7));
    simulation.force('y', d3.forceY().y(d => {
      switch(d.type) {
        case 'case': return newHeight * 0.1;
        case 'threat_actor': return newHeight * 0.3;
        case 'platform': return newHeight * 0.5;
        case 'tactic': return newHeight * 0.7;
        case 'technique': return newHeight * 0.85;
        case 'huntcard': return newHeight * 0.95;
        default: return newHeight * 0.5;
      }
    }).strength(0.5));
    simulation.alpha(0.1).restart();
  });
} 