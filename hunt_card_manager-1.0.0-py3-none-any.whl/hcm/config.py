"""
Configuration settings for Hunt Card Manager
"""

import os
from pathlib import Path


class Config:
    """Base configuration class"""
    
    # Flask configuration
    SECRET_KEY = os.environ.get('HCM_SECRET_KEY') or 'your-secret-key-change-in-production'
    DEBUG = False
    TESTING = False
    
    # Data directory configuration
    DEFAULT_DATA_DIR = os.path.join(os.path.expanduser("~"), "HCM_Data")
    DATA_DIR = os.environ.get('HCM_DATA_DIR') or DEFAULT_DATA_DIR
    
    # Ensure data directory exists
    @classmethod
    def init_app(cls, app):
        """Initialize the application with this config"""
        # Create data directory if it doesn't exist
        data_path = Path(cls.DATA_DIR)
        data_path.mkdir(parents=True, exist_ok=True)
        
        # Set the data directory in the app config
        app.config['DATA_DIR'] = str(data_path)
        
        # Create subdirectories
        (data_path / "cases").mkdir(exist_ok=True)
        (data_path / "exports").mkdir(exist_ok=True)
        (data_path / "logs").mkdir(exist_ok=True)


class DevelopmentConfig(Config):
    """Development configuration"""
    DEBUG = True
    SECRET_KEY = 'dev-secret-key'


class ProductionConfig(Config):
    """Production configuration"""
    DEBUG = False
    
    @classmethod
    def init_app(cls, app):
        Config.init_app(app)
        
        # Production-specific settings
        if os.environ.get('HCM_SECRET_KEY'):
            cls.SECRET_KEY = os.environ.get('HCM_SECRET_KEY')


class TestingConfig(Config):
    """Testing configuration"""
    TESTING = True
    DATA_DIR = os.path.join(os.path.dirname(__file__), '..', 'tests', 'test_data')


# Configuration dictionary
config = {
    'development': DevelopmentConfig,
    'production': ProductionConfig,
    'testing': TestingConfig,
    'default': DevelopmentConfig
} 