#!/usr/bin/env python3
"""
Configuration file for Hunt Card Manager (HCM)
Users can modify this file to customize their HCM installation.
"""

import os
from pathlib import Path

# Data Directory Configuration
# ===========================
# Set your preferred data directory path here.
# This is where all your investigation cases and evidence will be stored.
#
# Current Setting: Uses current working directory (where hcmrun is initiated)
# This means case data will be stored in the same folder where you run the application.
# Previous data in other locations will NOT be deleted - they remain accessible.
#
# Examples:
# - Current working directory: "." (recommended for portable use)
# - Windows: "C:\\HCM_Data" or "D:\\Investigations\\HCM"
# - Linux/Mac: "/home/user/HCM_Data" or "/opt/hcm/data"
# - Relative: "data" (relative to the application directory)

# Option 1: Use current working directory (recommended for portable use)
# This will store data in the directory where hcmrun is initiated
DATA_DIR = "."

# Option 2: Use environment variable (for production deployments)
# Set DATA_DIR = None to use environment variable HCM_DATA_DIR
# DATA_DIR = None

# Option 3: Set a specific path (uncomment and modify as needed)
# DATA_DIR = "C:\\HCM_Data"  # Windows example
# DATA_DIR = "/home/user/HCM_Data"  # Linux/Mac example
# DATA_DIR = "data"  # Relative to application directory

# Server Configuration
# ====================
DEFAULT_HOST = "127.0.0.1"
DEFAULT_PORT = 7997

# Debug Configuration
# ===================
DEBUG = False

# Security Configuration
# =====================
SECRET_KEY = "super_secret_key"  # Change this in production!

# File Upload Configuration
# ========================
MAX_FILE_SIZE = 10 * 1024 * 1024  # 10MB
ALLOWED_EXTENSIONS = {'.csv', '.json', '.zip'}

# Evidence Management Configuration
# ================================
EVIDENCE_ENABLED_BY_DEFAULT = True
MAX_EVIDENCE_FILE_SIZE = 50 * 1024 * 1024  # 50MB per evidence file

def get_data_dir():
    """
    Get the configured data directory path.
    Priority order:
    1. DATA_DIR from this config file (if not None)
    2. HCM_DATA_DIR environment variable
    3. Default 'data' directory
    
    If DATA_DIR is set to ".", uses current working directory.
    """
    if DATA_DIR is not None:
        if DATA_DIR == ".":
            # Use current working directory
            return os.getcwd()
        return DATA_DIR
    
    env_data_dir = os.environ.get('HCM_DATA_DIR')
    if env_data_dir:
        return env_data_dir
    
    return 'data'

def ensure_data_dir():
    """
    Ensure the data directory exists and is writable.
    Returns the absolute path to the data directory.
    """
    data_dir = get_data_dir()
    data_path = Path(data_dir)
    
    # For current working directory, just ensure it's writable
    if data_dir == os.getcwd():
        if not os.access(data_path, os.W_OK):
            raise PermissionError(f"Current working directory is not writable: {data_path.absolute()}")
        print(f"Using current working directory for data: {data_path.absolute()}")
        return str(data_path.absolute())
    
    # Create directory if it doesn't exist (for other paths)
    if not data_path.exists():
        data_path.mkdir(parents=True, exist_ok=True)
        print(f"Created data directory: {data_path.absolute()}")
    
    # Ensure it's writable
    if not os.access(data_path, os.W_OK):
        raise PermissionError(f"Data directory is not writable: {data_path.absolute()}")
    
    return str(data_path.absolute())

if __name__ == "__main__":
    # Test configuration
    print("HCM Configuration Test")
    print("=" * 30)
    print(f"Data Directory: {get_data_dir()}")
    print(f"Absolute Path: {ensure_data_dir()}")
    print(f"Default Host: {DEFAULT_HOST}")
    print(f"Default Port: {DEFAULT_PORT}")
    print(f"Debug Mode: {DEBUG}") 