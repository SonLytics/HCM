"""
Hunt Card Manager Flask Application
"""

import os
import json
import re
from datetime import datetime
from pathlib import Path
from flask import Flask, render_template, request, redirect, url_for, flash, jsonify, send_file
from werkzeug.utils import secure_filename
from .config import config


def create_app(config_name='default'):
    """Application factory function"""
    app = Flask(__name__)
    
    # Load configuration
    app.config.from_object(config[config_name])
    config[config_name].init_app(app)
    
    # Register routes
    register_routes(app)
    
    return app


def register_routes(app):
    """Register all application routes"""
    
    def get_safe_case_path(case_id):
        """Get safe case path with validation"""
        if not validate_case_id(case_id):
            raise ValueError("Invalid case ID")
        
        data_dir = app.config['DATA_DIR']
        case_folder = os.path.join(data_dir, "cases", case_id)
        
        # Ensure the path is within the data directory
        case_path = Path(case_folder).resolve()
        data_path = Path(data_dir).resolve()
        
        if not str(case_path).startswith(str(data_path)):
            raise ValueError("Path traversal attempt detected")
        
        return case_folder
    
    def validate_case_id(case_id):
        """Validate case ID format"""
        if not case_id or not isinstance(case_id, str):
            return False
        # Allow alphanumeric, hyphens, underscores, and dots
        return bool(re.match(r'^[a-zA-Z0-9._-]+$', case_id))
    
    def validate_file_upload(file):
        """Validate uploaded file"""
        if not file or file.filename == '':
            return False, "No file selected"
        
        # Check file size (10MB limit)
        if file.content_length and file.content_length > 10 * 1024 * 1024:
            return False, "File too large (max 10MB)"
        
        # Check file extension
        allowed_extensions = {'.csv', '.json'}
        file_ext = Path(file.filename).suffix.lower()
        if file_ext not in allowed_extensions:
            return False, f"Invalid file type. Allowed: {', '.join(allowed_extensions)}"
        
        return True, "File is valid"
    
    @app.route("/", methods=["GET", "POST"])
    def home():
        """Home page with case management"""
        data_dir = app.config['DATA_DIR']
        cases_dir = os.path.join(data_dir, "cases")
        
        if not os.path.exists(cases_dir):
            os.makedirs(cases_dir)
        
        cases = []
        for case_id in os.listdir(cases_dir):
            case_path = os.path.join(cases_dir, case_id)
            if os.path.isdir(case_path):
                huntcards_file = os.path.join(case_path, "huntcards.json")
                last_updated = None
                
                if os.path.exists(huntcards_file):
                    try:
                        with open(huntcards_file, "r") as f:
                            huntcards = json.load(f)
                            if huntcards:
                                # Get the most recent update
                                updates = [card.get("updated") for card in huntcards if card.get("updated")]
                                if updates:
                                    last_updated = max(updates)
                                    last_updated = datetime.fromisoformat(last_updated.replace('Z', '+00:00'))
                    except (json.JSONDecodeError, ValueError):
                        pass
                
                cases.append({
                    "case_id": case_id,
                    "last_updated": last_updated
                })
        
        # Sort cases by last updated (newest first)
        cases.sort(key=lambda x: x["last_updated"] or datetime.min, reverse=True)
        
        if request.method == "POST":
            case_id = request.form.get("case_id", "").strip()
            
            if not case_id:
                flash("Case ID cannot be empty.", "error")
                return redirect(request.url)
            
            case_folder = get_safe_case_path(case_id)
            
            if os.path.exists(case_folder):
                flash(f"Case '{case_id}' already exists!", "error")
                return redirect(request.url)
            
            try:
                os.makedirs(case_folder)
                with open(os.path.join(case_folder, "huntcards.json"), "w") as f:
                    f.write("[]")
                flash(f"Case '{case_id}' created successfully!", "success")
                return redirect(url_for("home"))
            except Exception as e:
                flash(f"Error creating case: {e}", "error")
                return redirect(request.url)
        
        return render_template("home.html", cases=cases)
    
    @app.route("/case/<case_id>")
    def case_view(case_id):
        """View hunt cards for a specific case"""
        case_folder = get_safe_case_path(case_id)
        huntcards_file = os.path.join(case_folder, "huntcards.json")
        
        huntcards = []
        if os.path.exists(huntcards_file):
            with open(huntcards_file, "r") as f:
                try:
                    huntcards = json.load(f)
                except json.JSONDecodeError:
                    flash("Corrupted huntcards.json.", "error")
        
        # Pagination
        page = request.args.get("page", 1, type=int)
        per_page = 10
        total = len(huntcards)
        total_pages = (total + per_page - 1) // per_page
        start_idx = (page - 1) * per_page
        end_idx = start_idx + per_page
        paginated_huntcards = huntcards[start_idx:end_idx]
        
        return render_template(
            "huntcard_list.html",
            case_id=case_id,
            huntcards=paginated_huntcards,
            page=page,
            total_pages=total_pages,
            per_page=per_page
        )
    
    # Add other routes here...
    # (I'll add the essential routes, but you can copy the rest from the original app.py)
    
    @app.route("/case/<case_id>/huntcard/new", methods=["GET", "POST"])
    def new_huntcard(case_id):
        """Create a new hunt card"""
        case_folder = get_safe_case_path(case_id)
        
        if request.method == "POST":
            # Process hunt card creation
            title = request.form.get("title", "").strip()
            if not title:
                flash("Title is required.", "error")
                return redirect(request.url)
            
            # Load existing hunt cards
            huntcards_file = os.path.join(case_folder, "huntcards.json")
            huntcards = []
            if os.path.exists(huntcards_file):
                with open(huntcards_file, "r") as f:
                    try:
                        huntcards = json.load(f)
                    except json.JSONDecodeError:
                        huntcards = []
            
            # Create new hunt card
            new_card = {
                "title": title,
                "description": request.form.get("description", ""),
                "platform": request.form.get("platform", "Unknown"),
                "threat_actor": request.form.get("threat_actor", "Unknown"),
                "tactics_techniques": [],  # Will be populated from form
                "investigation_points": [],
                "created": datetime.now().isoformat(),
                "updated": datetime.now().isoformat()
            }
            
            huntcards.append(new_card)
            
            # Save hunt cards
            with open(huntcards_file, "w") as f:
                json.dump(huntcards, f, indent=2)
            
            flash(f"Hunt Card '{title}' created successfully!", "success")
            return redirect(url_for("case_view", case_id=case_id))
        
        return render_template("huntcard_form.html", case_id=case_id)
    
    @app.route("/case/<case_id>/huntcard/<int:huntcard_idx>/edit", methods=["GET", "POST"])
    def edit_huntcard(case_id, huntcard_idx):
        """Edit an existing hunt card"""
        case_folder = get_safe_case_path(case_id)
        huntcards_file = os.path.join(case_folder, "huntcards.json")
        
        if not os.path.exists(huntcards_file):
            flash("Hunt cards file not found.", "error")
            return redirect(url_for("case_view", case_id=case_id))
        
        with open(huntcards_file, "r") as f:
            try:
                huntcards = json.load(f)
            except json.JSONDecodeError:
                flash("Corrupted huntcards.json.", "error")
                return redirect(url_for("case_view", case_id=case_id))
        
        if huntcard_idx >= len(huntcards):
            flash("Hunt card not found.", "error")
            return redirect(url_for("case_view", case_id=case_id))
        
        huntcard = huntcards[huntcard_idx]
        
        if request.method == "POST":
            title = request.form.get("title", "").strip()
            if not title:
                flash("Title is required.", "error")
                return redirect(request.url)
            
            # Update hunt card
            huntcard.update({
                "title": title,
                "description": request.form.get("description", ""),
                "platform": request.form.get("platform", "Unknown"),
                "threat_actor": request.form.get("threat_actor", "Unknown"),
                "updated": datetime.now().isoformat()
            })
            
            # Save hunt cards
            with open(huntcards_file, "w") as f:
                json.dump(huntcards, f, indent=2)
            
            flash(f"Hunt Card '{title}' updated successfully!", "success")
            return redirect(url_for("case_view", case_id=case_id))
        
        return render_template("huntcard_form.html", case_id=case_id, huntcard=huntcard, huntcard_idx=huntcard_idx)
    
    @app.route("/case/<case_id>/huntcard/<int:huntcard_idx>/delete")
    def delete_huntcard(case_id, huntcard_idx):
        """Delete a hunt card"""
        case_folder = get_safe_case_path(case_id)
        huntcards_file = os.path.join(case_folder, "huntcards.json")
        
        if not os.path.exists(huntcards_file):
            flash("Hunt cards file not found.", "error")
            return redirect(url_for("case_view", case_id=case_id))
        
        with open(huntcards_file, "r") as f:
            try:
                huntcards = json.load(f)
            except json.JSONDecodeError:
                flash("Corrupted huntcards.json.", "error")
                return redirect(url_for("case_view", case_id=case_id))
        
        if huntcard_idx >= len(huntcards):
            flash("Hunt card not found.", "error")
            return redirect(url_for("case_view", case_id=case_id))
        
        deleted_title = huntcards[huntcard_idx]["title"]
        del huntcards[huntcard_idx]
        
        with open(huntcards_file, "w") as f:
            json.dump(huntcards, f, indent=2)
        
        flash(f"Hunt Card '{deleted_title}' deleted successfully!", "success")
        return redirect(url_for("case_view", case_id=case_id))
    
    # Add more routes as needed...
    # You can copy the remaining routes from the original app.py file 